#!/usr/bin/env bash
# Verify actual RDP edge and AI PCM RAM corruption using the real built core.
set -Eeuo pipefail
if [[ $# != 2 ]]; then
  printf 'Usage: %s CORE_SO OUTPUT_DIRECTORY\n' "$0" >&2
  exit 2
fi
BN_TARGET_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_TARGET_CORE="$(realpath -- "$1")"
mkdir -p -- "$2"
BN_TARGET_OUTPUT="$(cd -- "$2" && pwd)"
BN_TARGET_BUILD="$(mktemp -d "${TMPDIR:-/tmp}/badn64-target.XXXXXX")"
trap 'rm -rf -- "$BN_TARGET_BUILD"' EXIT
BN_TARGET_ROM="$BN_TARGET_ROOT/tests/fixtures/triangle-audio/TriangleAudio.N64"
python3 - "$BN_TARGET_ROOT/tests/fixtures/triangle-audio" <<'PY'
from pathlib import Path
import hashlib, sys
fixture = Path(sys.argv[1])
for line in (fixture/'SHA256SUMS').read_text().splitlines():
    expected, relative = line.split('  ', 1)
    path = fixture/relative
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Triangle/audio fixture verification failed: {relative}')
PY
"${CXX:-c++}" -std=c++17 -O2 -Wall -Wextra -Werror \
  -I "$BN_TARGET_ROOT/tests/include" -I "$BN_TARGET_ROOT/app/src/main/cpp" \
  "$BN_TARGET_ROOT/tests/native/target-corruption-real.cpp" \
  "$BN_TARGET_ROOT/app/src/main/cpp/rtc_engine.cpp" \
  -ldl -o "$BN_TARGET_BUILD/target-corruption-real"
timeout --kill-after=5s 120s "$BN_TARGET_BUILD/target-corruption-real" \
  "$BN_TARGET_CORE" "$BN_TARGET_ROM" "$BN_TARGET_OUTPUT/target-corruption-report.json" \
  2>&1 | tee "$BN_TARGET_OUTPUT/target-corruption-validation.log"
