#!/usr/bin/env bash
# Offline ContentSession ordering checks; does not execute Android Activity/JNI.
set -Eeuo pipefail
BN_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_BUILD="$BN_ROOT/build/ui-host/classes"
BN_RESULTS="$BN_ROOT/test-results"
command -v java >/dev/null || { printf 'Missing UI test command: java\n' >&2; exit 1; }
mkdir -p "$BN_BUILD" "$BN_RESULTS"
BN_SOURCES=("$BN_ROOT/app/src/main/java/com/badn64/app/ContentSession.java"
            "$BN_ROOT/tests/java/ContentSessionTest.java")
if command -v javac >/dev/null; then
  javac --release 17 -proc:none -d "$BN_BUILD" "${BN_SOURCES[@]}"
else
  java -m jdk.compiler/com.sun.tools.javac.Main -source 17 -target 17 -proc:none \
    -d "$BN_BUILD" "${BN_SOURCES[@]}"
fi
java -cp "$BN_BUILD" com.badn64.app.ContentSessionTest \
  | tee "$BN_RESULTS/ui-session-validation.log"
