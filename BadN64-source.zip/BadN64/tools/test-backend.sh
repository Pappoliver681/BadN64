#!/usr/bin/env bash
# Contract test for the Android/native frontend using a mock libretro core.
set -Eeuo pipefail
BN_BACKEND_TEST_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_BACKEND_TEST_BUILD="$(mktemp -d "${TMPDIR:-/tmp}/badn64-backend-test.XXXXXX")"
trap 'rm -rf -- "$BN_BACKEND_TEST_BUILD"' EXIT
"${CXX:-c++}" -std=c++17 -O1 -pthread \
  -I "$BN_BACKEND_TEST_ROOT/tests/include" \
  "$BN_BACKEND_TEST_ROOT/tests/native/backend-smoke.cpp" \
  "$BN_BACKEND_TEST_ROOT/app/src/main/cpp/native_backend.cpp" \
  "$BN_BACKEND_TEST_ROOT/app/src/main/cpp/rtc_engine.cpp" \
  -lz -o "$BN_BACKEND_TEST_BUILD/backend-smoke"
"$BN_BACKEND_TEST_BUILD/backend-smoke" "$BN_BACKEND_TEST_BUILD/app-data"
