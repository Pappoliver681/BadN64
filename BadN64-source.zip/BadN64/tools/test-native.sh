#!/usr/bin/env bash
# Standalone host validation of BadN64 live-memory RTC. No SDK or network needed.
set -Eeuo pipefail
BN_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_BUILD="$BN_ROOT/build/native-host"
BN_RESULTS="$BN_ROOT/test-results"
mkdir -p "$BN_BUILD" "$BN_RESULTS"
for BN_COMMAND in g++ python3; do
  command -v "$BN_COMMAND" >/dev/null || { printf 'Missing native test command: %s\n' "$BN_COMMAND" >&2; exit 1; }
done
g++ -std=c++17 -Wall -Wextra -Werror -pedantic -O2 -I "$BN_ROOT/app/src/main/cpp" \
  "$BN_ROOT/app/src/main/cpp/rtc_engine.cpp" "$BN_ROOT/tests/native/rtc_engine_test.cpp" \
  -o "$BN_BUILD/rtc_engine_test"
"$BN_BUILD/rtc_engine_test" | tee "$BN_RESULTS/native-rtc-validation.log"
g++ -std=c++17 -Wall -Wextra -Werror -pedantic -O2 -I "$BN_ROOT/app/src/main/cpp" \
  "$BN_ROOT/app/src/main/cpp/rtc_engine.cpp" "$BN_ROOT/tests/native/rtc-targets.cpp" \
  -o "$BN_BUILD/rtc_targets_test"
"$BN_BUILD/rtc_targets_test" | tee "$BN_RESULTS/native-rtc-targets-validation.log"
bash "$BN_ROOT/tools/test-ui.sh"
python3 - "$BN_ROOT" <<'PY'
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
checks = [line[5:] for line in (root/'test-results/native-rtc-validation.log').read_text().splitlines()
          if line.startswith('PASS ')]
if len(checks) != 12:
    raise RuntimeError('Native RTC validation report is incomplete')
sources = ('app/src/main/cpp/rtc_engine.cpp', 'app/src/main/cpp/rtc_engine.h',
           'app/src/main/cpp/rtc_target_ranges.h', 'tests/native/rtc_engine_test.cpp',
           'tests/native/rtc-targets.cpp')
report = {'component': 'BadN64 live-memory RTC', 'passed_checks': len(checks), 'checks': checks,
          'targeted_checks_passed': True,
          'host_source_sha256': {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sources},
          'core_emulation_tested': False, 'physical_android_tested': False}
(root/'test-results/native-rtc-report.json').write_text(json.dumps(report, indent=2)+'\n')
PY
