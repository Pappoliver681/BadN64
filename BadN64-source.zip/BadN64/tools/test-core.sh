#!/usr/bin/env bash
# Real headless N64 integration check, using an Unlicense homebrew demo.
set -Eeuo pipefail
BN_SMOKE_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_SMOKE_BUILD="$BN_SMOKE_ROOT/build/core-smoke"
BN_SMOKE_RESULTS="$BN_SMOKE_ROOT/test-results"
BN_SMOKE_ORIGINAL="$BN_SMOKE_BUILD/InputRDP.N64"
BN_SMOKE_ROM="$BN_SMOKE_BUILD/InputRDP-timing-fixed.N64"
mkdir -p "$BN_SMOKE_BUILD" "$BN_SMOKE_RESULTS"
python3 "$BN_SMOKE_ROOT/tools/fetch-core.py"
# Keep verified complete source in the always-uploaded diagnostics even
# when a later native compile or emulator smoke check fails.
python3 "$BN_SMOKE_ROOT/tools/package-source.py" \
  --output "$BN_SMOKE_RESULTS/BadN64-core-source.zip"
# Upstream's software GLSM stub includes glsm.h, which still declares GL
# types. The Linux build needs headers even though it links no GL renderer.
if ! printf '#include <GL/gl.h>\n' | "${CC:-cc}" -x c -E - >/dev/null 2>&1; then
  if [[ "${GITHUB_ACTIONS:-false}" == true ]]; then
    sudo apt-get update
    sudo apt-get install --yes --no-install-recommends libgl-dev
  else
    printf 'The Linux core smoke build requires OpenGL headers (Debian/Ubuntu: libgl-dev).\n' >&2
    exit 1
  fi
fi
if [[ ! -f "$BN_SMOKE_ORIGINAL" ]]; then
  if [[ -f "$BN_SMOKE_ROOT/tests/fixtures/input-rdp/InputRDP.N64" ]]; then
    cp "$BN_SMOKE_ROOT/tests/fixtures/input-rdp/InputRDP.N64" "$BN_SMOKE_ORIGINAL"
  else
    curl --fail --location --retry 3 --connect-timeout 30 --max-time 120 \
      --output "$BN_SMOKE_ORIGINAL.part" \
      'https://raw.githubusercontent.com/PeterLemon/N64/7085543e4a19d8c539fc9e0a4d2869e788b4ed4b/Input/RDP/InputRDP.N64'
    mv "$BN_SMOKE_ORIGINAL.part" "$BN_SMOKE_ORIGINAL"
  fi
fi
# The original demo starts controller DMA while N64_INIT's direct PIF I/O
# is still busy. Its public-domain derivative waits for SI to become idle.
# Keep both pinned images, and retain the actual controller movement check.
cp "$BN_SMOKE_ROOT/tests/fixtures/input-rdp/InputRDP-timing-fixed.N64" "$BN_SMOKE_ROM"
python3 - "$BN_SMOKE_ORIGINAL" "$BN_SMOKE_ROM" "$BN_SMOKE_ROOT/vendor/parallel-n64" "$BN_SMOKE_BUILD/core-source" <<'PY'
import hashlib, pathlib, shutil, sys
original, rom, source, build = map(pathlib.Path, sys.argv[1:])
for image, expected in (
    (original, '7a152859f5326c23307ad785395ae763951f950a'),
    (rom, '8dc0cdf6d7f3dbc66bf0424948774a6ef5f64677'),
):
    data = image.read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if len(data) != 1052672 or blob != expected:
        raise RuntimeError(f'Public-domain homebrew ROM verification failed: {image.name}')
    shutil.copyfile(image, image.parents[2]/'test-results'/image.name)
# Build outside the vendor directory so corresponding source stays clean.
if build.exists(): shutil.rmtree(build)
shutil.copytree(source, build, ignore=shutil.ignore_patterns('.git'))
PY
python3 "$BN_SMOKE_ROOT/tools/patch-core.py" "$BN_SMOKE_BUILD/core-source"
cp "$BN_SMOKE_BUILD/core-source/badn64-core-fixes.json" "$BN_SMOKE_RESULTS/core-fixes.json"
python3 "$BN_SMOKE_ROOT/tests/native/test-core-aliases.py" \
  --source "$BN_SMOKE_BUILD/core-source" --output "$BN_SMOKE_RESULTS/core-aliases"
make -C "$BN_SMOKE_BUILD/core-source" -j"${BADN64_JOBS:-2}" \
  platform=unix ARCH=x86_64 CC="${CC:-cc}" CXX="${CXX:-c++}" \
  TARGET="$BN_SMOKE_BUILD/libretro.so" HAVE_OPENGL=0 GLES=0 \
  HAVE_PARALLEL=0 HAVE_PARALLEL_RSP=0 HAVE_THR_AL=1 WITH_DYNAREC=bogus GIT_VERSION=862071a8
"${CXX:-c++}" -std=c++17 -O2 -Wall -Wextra -Werror \
  -I"$BN_SMOKE_ROOT/tests/include" "$BN_SMOKE_ROOT/tests/native/core-smoke.cpp" \
  -ldl -o "$BN_SMOKE_BUILD/core-smoke"
timeout 240 "$BN_SMOKE_BUILD/core-smoke" "$BN_SMOKE_BUILD/libretro.so" \
  "$BN_SMOKE_ROM" "$BN_SMOKE_RESULTS/core-smoke-report.json" \
  2>&1 | tee "$BN_SMOKE_RESULTS/core-smoke-validation.log"
timeout 240 "$BN_SMOKE_BUILD/core-smoke" "$BN_SMOKE_BUILD/libretro.so" \
  "$BN_SMOKE_ROM" "$BN_SMOKE_RESULTS/core-smoke-pure-report.json" pure_interpreter \
  2>&1 | tee "$BN_SMOKE_RESULTS/core-smoke-pure-validation.log"
bash "$BN_SMOKE_ROOT/tools/test-core-stop.sh" \
  "$BN_SMOKE_BUILD/libretro.so" "$BN_SMOKE_ROM" "$BN_SMOKE_RESULTS"
bash "$BN_SMOKE_ROOT/tools/test-real-backend.sh" \
  "$BN_SMOKE_BUILD/libretro.so" "$BN_SMOKE_ROM" "$BN_SMOKE_RESULTS"
bash "$BN_SMOKE_ROOT/tools/test-target-corruption.sh" \
  "$BN_SMOKE_BUILD/libretro.so" "$BN_SMOKE_RESULTS"
