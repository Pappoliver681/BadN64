#!/usr/bin/env bash
# Build the pinned software-only N64 libretro core for Android.
set -Eeuo pipefail
if [[ $# != 3 ]]; then
  printf 'Usage: %s ANDROID_NDK_DIRECTORY ABI OUTPUT_BUILD_DIRECTORY\n' "$0" >&2
  exit 2
fi
BN_CORE_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_CORE_NDK="$(cd -- "$1" && pwd)"
BN_CORE_ABI="$2"
case "$BN_CORE_ABI" in
  arm64-v8a|armeabi-v7a|x86|x86_64) ;;
  *) printf 'Unsupported Android ABI: %s\n' "$BN_CORE_ABI" >&2; exit 2 ;;
esac
if [[ ! -x "$BN_CORE_NDK/ndk-build" ]]; then
  printf 'The selected Android NDK has no executable ndk-build.\n' >&2
  exit 1
fi
mkdir -p -- "$3"
BN_CORE_BUILD="$(cd -- "$3" && pwd)"
BN_CORE_SOURCE="$BN_CORE_ROOT/vendor/parallel-n64"
python3 "$BN_CORE_ROOT/tools/fetch-core.py"

# Keep upstream source intact. The generated build file adds explicit
# 16 KB ELF segment alignment and drops the unused GLES link dependency.
python3 - "$BN_CORE_SOURCE" "$BN_CORE_BUILD" <<'PY'
import pathlib, sys
source, build = map(pathlib.Path, sys.argv[1:])
makefile = (source/'jni/Android.mk').read_text()
old = 'ROOT_DIR      := $(LOCAL_PATH)/..'
if old not in makefile:
    raise RuntimeError('Pinned Android.mk root declaration changed')
escaped = str(source).replace('\\', '\\\\').replace(' ', '\\ ').replace('#', '\\#').replace('$', '$$')
makefile = makefile.replace(old, 'ROOT_DIR := '+escaped, 1)
# glsm.h is included by upstream's software stub to declare its enum. The
# NDK supplies GLES2 headers, not desktop GL/gl.h. This header-only macro
# selects those types without enabling HAVE_OPENGLES or any GPU renderer.
old = 'COREFLAGS := -ffast-math'
if old not in makefile:
    raise RuntimeError('Pinned Android.mk compiler declaration changed')
makefile = makefile.replace(old, 'COREFLAGS := -DHAVE_OPENGLES2 -ffast-math', 1)
old = 'LOCAL_LDFLAGS      := -Wl,-version-script=$(LIBRETRO_DIR)/link.T'
if old not in makefile:
    raise RuntimeError('Pinned Android.mk linker declaration changed')
makefile = makefile.replace(old, old+' -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384 -Wl,--no-undefined', 1)
old = 'LOCAL_LDLIBS       := -lGLESv2 -llog'
if old not in makefile:
    raise RuntimeError('Pinned Android.mk libraries declaration changed')
makefile = makefile.replace(old, 'LOCAL_LDLIBS := -llog -lm', 1)
(build/'Android.mk').write_text(makefile)
PY
"$BN_CORE_NDK/ndk-build" -C "$BN_CORE_SOURCE" \
  NDK_PROJECT_PATH="$BN_CORE_SOURCE" \
  APP_BUILD_SCRIPT="$BN_CORE_BUILD/Android.mk" \
  NDK_APPLICATION_MK="$BN_CORE_SOURCE/jni/Application.mk" \
  NDK_OUT="$BN_CORE_BUILD/obj" NDK_LIBS_OUT="$BN_CORE_BUILD/libs" \
  APP_ABI="$BN_CORE_ABI" APP_PLATFORM=android-26 APP_STL=c++_static \
  APP_OPTIM=release NDK_DEBUG=0 HAVE_OPENGL=0 GLES=0 \
  HAVE_PARALLEL=0 HAVE_PARALLEL_RSP=0 HAVE_THR_AL=1 \
  WITH_DYNAREC=bogus HAVE_GLIDE64=0 HAVE_GLIDEN64=0 HAVE_GLN64=0 HAVE_RICE=0 GIT_VERSION=862071a8 \
  -j"${BADN64_JOBS:-2}"
test -s "$BN_CORE_BUILD/libs/$BN_CORE_ABI/libretro.so"
printf 'Built software N64 core: %s\n' "$BN_CORE_BUILD/libs/$BN_CORE_ABI/libretro.so"
