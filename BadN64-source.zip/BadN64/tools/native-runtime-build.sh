#!/usr/bin/env bash
# Build the native Android host/core in the cloud. No WebView or JS runtime.
set -Eeuo pipefail
trap 'printf "Native build failed at line %s\n" "$LINENO" >&2' ERR
BN_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_TOOLS="${BADN64_TOOLCHAIN:-$BN_ROOT/toolchain}"
BN_BUILD="$BN_ROOT/build/native-cloud"
BN_DIST="$BN_ROOT/dist"
BN_VENDOR="$BN_ROOT/vendor/parallel-n64"
BN_COMMIT=862071a8b786224905a763e8b15bdcaf75739341
BN_NDK_VERSION=28.2.13676358
BN_VERSION_CODE=1
BN_VERSION_NAME=0.1.0
BN_KEY="$BN_ROOT/signing/badn64-development.keystore"
BN_ABIS=(arm64-v8a)
mkdir -p "$BN_TOOLS/downloads" "$BN_BUILD" "$BN_DIST" "$BN_ROOT/signing"

for BN_COMMAND in java keytool curl python3 cmake; do
  command -v "$BN_COMMAND" >/dev/null || { printf 'Required cloud command is missing: %s\n' "$BN_COMMAND" >&2; exit 1; }
done
if command -v javac >/dev/null; then
  BN_JAVAC=(javac)
elif java --list-modules | python3 -c 'import sys; sys.exit(not any(line.startswith("jdk.compiler@") for line in sys.stdin))'; then
  BN_JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main)
else
  printf 'The cloud JDK must include its Java compiler.\n' >&2
  exit 1
fi

# BadN64 has its own application and signing identity. Cache this key to
# retain the ability to install subsequent BadN64 builds as updates.
if [[ ! -f "$BN_KEY" ]]; then
  keytool -genkeypair -keystore "$BN_KEY" -storepass badn64-development \
    -keypass badn64-development -alias badn64 -keyalg RSA -keysize 3072 \
    -validity 10000 -dname "CN=BadN64 Development" -noprompt
fi
keytool -exportcert -keystore "$BN_KEY" -storepass badn64-development \
  -alias badn64 -file "$BN_BUILD/signing-certificate.der" >/dev/null
BN_SIGNER_SHA256="$(python3 - "$BN_BUILD/signing-certificate.der" <<'PYCODE'
import hashlib,pathlib,sys
print(hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest())
PYCODE
)"
python3 "$BN_ROOT/tools/fetch-core.py"

python3 - "$BN_TOOLS" "$BN_BUILD" "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" \
  "${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}" "$BN_NDK_VERSION" <<'PY'
import hashlib, os, pathlib, stat, subprocess, sys, xml.etree.ElementTree as ET, zipfile
root, build = map(pathlib.Path, sys.argv[1:3])
cache = root/'downloads'
installed_sdk = pathlib.Path(sys.argv[3]) if sys.argv[3] else None
explicit_ndk = pathlib.Path(sys.argv[4]) if sys.argv[4] else None
ndk_version = sys.argv[5]
tree = None
def fetch(url, path):
    if path.is_file() and path.stat().st_size: return
    temporary = path.with_suffix(path.suffix+'.part')
    print('Downloading '+url, flush=True)
    subprocess.run(['curl', '--fail', '--location', '--retry', '3', '--connect-timeout', '30',
                    '--max-time', '900', '--output', str(temporary), url], check=True)
    temporary.replace(path)
def tag(element): return element.tag.rsplit('}', 1)[-1]
def child(element, name): return next((c for c in element if tag(c) == name), None)
def text(element, name):
    item = child(element, name)
    return item.text if item is not None else None
def extract(archive, destination):
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    with zipfile.ZipFile(archive) as handle:
        for member in handle.infolist():
            target = destination/member.filename
            if not target.resolve().is_relative_to(base): raise RuntimeError('Unsafe SDK archive member')
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode):
                link = handle.read(member).decode('utf-8')
                if os.path.isabs(link) or not (target.parent/link).resolve().is_relative_to(base):
                    raise RuntimeError('Unsafe SDK archive symlink')
                target.parent.mkdir(parents=True, exist_ok=True)
                target.unlink(missing_ok=True)
                target.symlink_to(link)
            else:
                handle.extract(member, destination)
                if mode: target.chmod(mode & 0o777)
def install(package, marker, destination, required_files=()):
    global tree
    candidates = sorted(destination.rglob(marker)) if destination.exists() else []
    if candidates and all((candidates[0].parent/name).is_file() for name in required_files): return candidates[0]
    if tree is None:
        metadata = cache/'repository2-3.xml'
        fetch('https://dl.google.com/android/repository/repository2-3.xml', metadata)
        tree = ET.parse(metadata)
    package_entry = next((e for e in tree.iter() if tag(e) == 'remotePackage' and e.get('path') == package), None)
    if package_entry is None: raise RuntimeError('The official SDK repository lacks '+package)
    archive = next((a for a in child(package_entry, 'archives')
                    if text(a, 'host-os') in (None, 'linux') and child(a, 'complete') is not None), None)
    if archive is None: raise RuntimeError('No Linux SDK archive for '+package)
    complete = child(archive, 'complete')
    relative = text(complete, 'url')
    url = relative if relative.startswith('https://') else 'https://dl.google.com/android/repository/'+relative
    download = cache/pathlib.Path(relative).name
    fetch(url, download)
    checksum = child(complete, 'checksum')
    if checksum is None: raise RuntimeError('The SDK archive has no published checksum.')
    digest = hashlib.new(checksum.get('type', 'sha1'))
    with download.open('rb') as input_file:
        for chunk in iter(lambda: input_file.read(4*1024*1024), b''): digest.update(chunk)
    digest = digest.hexdigest()
    if digest.lower() != checksum.text.strip().lower():
        download.unlink(missing_ok=True)
        raise RuntimeError('SDK archive checksum mismatch: '+package)
    if text(complete, 'size') and download.stat().st_size != int(text(complete, 'size')):
        raise RuntimeError('Incomplete SDK archive: '+package)
    extract(download, destination)
    candidates = sorted(destination.rglob(marker))
    if len(candidates) != 1: raise RuntimeError('Expected one '+marker+' in '+package)
    if not all((candidates[0].parent/name).is_file() for name in required_files):
        raise RuntimeError('The official archive is missing a required component: '+package)
    return candidates[0]
sdk = root/'sdk'
platform = installed_sdk/'platforms/android-36/android.jar' if installed_sdk else None
if platform is None or not platform.is_file():
    platform = install('platforms;android-36', 'android.jar', sdk/'platform-36')
tools = installed_sdk/'build-tools/36.0.0' if installed_sdk else None
required = ('aapt2', 'd8', 'apksigner', 'zipalign')
if tools is None or not all((tools/name).is_file() for name in required):
    tools = install('build-tools;36.0.0', 'aapt2', sdk/'build-tools-36', required).parent
def valid_ndk(path):
    return path is not None and (path/'build/cmake/android.toolchain.cmake').is_file() \
        and (path/'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip').is_file()
ndk = explicit_ndk if valid_ndk(explicit_ndk) else None
if ndk is None and installed_sdk and (installed_sdk/'ndk').is_dir():
    def version(path):
        try: return tuple(int(part) for part in path.name.split('.'))
        except ValueError: return (0,)
    choices = sorted((p for p in (installed_sdk/'ndk').iterdir() if valid_ndk(p) and version(p)[0] >= 28),
                     key=version, reverse=True)
    if choices: ndk = choices[0]
if ndk is None:
    ndk = install('ndk;'+ndk_version, 'source.properties', sdk/('ndk-'+ndk_version),
                  ('build/cmake/android.toolchain.cmake',
                   'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip',
                   'toolchains/llvm/prebuilt/linux-x86_64/bin/clang')).parent
if not valid_ndk(ndk): raise RuntimeError('The selected Android NDK is incomplete.')
if not all((tools/name).is_file() for name in required): raise RuntimeError('The SDK build tools are incomplete.')
(build/'sdk-paths.txt').write_text(str(platform)+'\n'+str(tools)+'\n'+str(ndk)+'\n')
print('Android NDK: '+str(ndk), flush=True)
PY

mapfile -t BN_SDK_PATHS < "$BN_BUILD/sdk-paths.txt"
BN_ANDROID_JAR="${BN_SDK_PATHS[0]}"
BN_SDK_BIN="${BN_SDK_PATHS[1]}"
BN_NDK="${BN_SDK_PATHS[2]}"
BN_STRIP="$BN_NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
BN_GENERATOR='Unix Makefiles'
if command -v ninja >/dev/null; then BN_GENERATOR=Ninja; fi
mkdir -p "$BN_BUILD/jni"
for BN_ABI in "${BN_ABIS[@]}"; do
  printf 'Compiling the native N64 RTC backend for %s\n' "$BN_ABI"
  bash "$BN_ROOT/tools/build-core.sh" "$BN_NDK" "$BN_ABI" "$BN_BUILD/core-$BN_ABI"
  cmake -S "$BN_ROOT/app/src/main/cpp" -B "$BN_BUILD/$BN_ABI" -G "$BN_GENERATOR" \
    -DCMAKE_TOOLCHAIN_FILE="$BN_NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$BN_ABI" -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static \
    -DCMAKE_BUILD_TYPE=Release -DPARALLEL_SOURCE_DIR="$BN_VENDOR" \
    -DPARALLEL_CORE_LIBRARY="$BN_BUILD/core-$BN_ABI/libs/$BN_ABI/libretro.so"
  cmake --build "$BN_BUILD/$BN_ABI" --parallel "${BADN64_JOBS:-2}" --target badn64
  mkdir -p "$BN_BUILD/jni/$BN_ABI"
  cp "$BN_BUILD/$BN_ABI/libbadn64.so" "$BN_BUILD/jni/$BN_ABI/libbadn64.so"
  cp "$BN_BUILD/core-$BN_ABI/libs/$BN_ABI/libretro.so" "$BN_BUILD/jni/$BN_ABI/libretro.so"
  "$BN_STRIP" --strip-unneeded "$BN_BUILD/jni/$BN_ABI/"*.so
done

python3 - "$BN_ROOT" "$BN_BUILD" "$BN_COMMIT" <<'PY'
import json, pathlib, shutil, struct, sys, xml.etree.ElementTree as ET
root, build = map(pathlib.Path, sys.argv[1:3])
commit = sys.argv[3]
report = []
for library in sorted((build/'jni').rglob('*.so')):
    data = library.read_bytes()
    if data[:4] != b'\x7fELF' or data[5] != 1: raise RuntimeError('Invalid native ELF: '+str(library))
    if data[4] == 2:
        offset = struct.unpack_from('<Q', data, 32)[0]
        stride, count = struct.unpack_from('<HH', data, 54)
        entry = '<IIQQQQQQ'
    elif data[4] == 1:
        offset = struct.unpack_from('<I', data, 28)[0]
        stride, count = struct.unpack_from('<HH', data, 42)
        entry = '<IIIIIIII'
    else: raise RuntimeError('Unsupported ELF class')
    alignments = []
    for index in range(count):
        values = struct.unpack_from(entry, data, offset+index*stride)
        if values[0] == 1:
            alignment = values[-1]
            if alignment < 16384 or alignment & (alignment-1):
                raise RuntimeError('The native library lacks 16 KB load-segment alignment: '+str(library))
            file_offset, address = (values[2], values[3]) if data[4] == 2 else (values[1], values[2])
            if file_offset % 16384 != address % 16384:
                raise RuntimeError('The native ELF load segments cannot map on 16 KB pages.')
            alignments.append(alignment)
    if not alignments: raise RuntimeError('The native ELF has no loadable segments.')
    report.append({'abi': library.parent.name, 'library': library.name,
                   'bytes': len(data), 'load_segment_alignment': alignments})
    print('Verified 16 KB native alignment: '+library.parent.name, flush=True)
(root/'dist/native-libraries.json').write_text(json.dumps({'parallel_n64_commit': commit, 'libraries': report}, indent=2)+'\n')
# Stage source and license notices for the native APK.
assets = build/'assets'
if assets.exists(): shutil.rmtree(assets)
licenses = assets/'licenses'
licenses.mkdir(parents=True)
shutil.copyfile(root/'vendor/parallel-n64/mupen64plus-core/LICENSES', licenses/'Parallel-N64.txt')
shutil.copyfile(root/'vendor/parallel-n64/mupen64plus-rsp-cxd4/COPYING', licenses/'RSP-CXD4-COPYING.txt')
shutil.copyfile(root/'vendor/parallel-n64/mupen64plus-rsp-hle/LICENSES', licenses/'RSP-HLE-LICENSES.txt')
notice = root/'app/src/main/assets/licenses/THIRD_PARTY_NOTICES.txt'
if not notice.is_file(): raise RuntimeError('The native third-party/source notices are missing.')
shutil.copyfile(notice, licenses/'THIRD_PARTY_NOTICES.txt')
for license_file in (root/'app/src/main/assets/licenses').iterdir():
    if license_file.is_file() and license_file.name not in {'Parallel-N64.txt', 'THIRD_PARTY_NOTICES.txt'}:
        shutil.copyfile(license_file, licenses/license_file.name)
ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
tree = ET.parse(root/'app/src/main/AndroidManifest.xml')
tree.getroot().set('package', 'com.badn64.app')
application = tree.getroot().find('application')
if application is None: raise RuntimeError('The app manifest has no application.')
application.set('{http://schemas.android.com/apk/res/android}extractNativeLibs', 'true')
tree.write(build/'AndroidManifest.xml', encoding='utf-8', xml_declaration=True)
PY

rm -rf "$BN_BUILD/classes" "$BN_BUILD/generated" "$BN_BUILD/dex"
mkdir -p "$BN_BUILD/classes" "$BN_BUILD/generated" "$BN_BUILD/dex"
printf 'Compiling Android 16 native interface resources\n'
"$BN_SDK_BIN/aapt2" compile --dir "$BN_ROOT/app/src/main/res" -o "$BN_BUILD/resources.zip"
"$BN_SDK_BIN/aapt2" link -o "$BN_BUILD/resources.apk" -I "$BN_ANDROID_JAR" \
  --manifest "$BN_BUILD/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 36 \
  --version-code "$BN_VERSION_CODE" --version-name "$BN_VERSION_NAME" --java "$BN_BUILD/generated" \
  -A "$BN_BUILD/assets" "$BN_BUILD/resources.zip"
python3 - "$BN_ROOT" "$BN_BUILD" <<'PY'
import pathlib, sys
root, build = map(pathlib.Path, sys.argv[1:])
sources = sorted((root/'app/src/main/java').rglob('*.java'))+sorted((build/'generated').rglob('*.java'))
(build/'sources.txt').write_text('\n'.join('"'+str(p)+'"' for p in sources)+'\n')
PY
printf 'Compiling the native Android Java interface\n'
# The modular-JDK fallback uses -Xmx directly instead of javac's -J launcher flag.
if [[ "${BN_JAVAC[0]}" == javac ]]; then
  "${BN_JAVAC[@]}" -J-Xmx1024m --release 17 -proc:none -classpath "$BN_ANDROID_JAR" \
    -d "$BN_BUILD/classes" @"$BN_BUILD/sources.txt"
else
  java -Xmx1024m -m jdk.compiler/com.sun.tools.javac.Main -source 17 -target 17 -proc:none \
    -classpath "$BN_ANDROID_JAR" -d "$BN_BUILD/classes" @"$BN_BUILD/sources.txt"
fi
python3 - "$BN_BUILD" <<'PY'
import pathlib, sys, zipfile
build = pathlib.Path(sys.argv[1])
with zipfile.ZipFile(build/'classes.jar', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((build/'classes').rglob('*.class')): archive.write(path, path.relative_to(build/'classes'))
PY
"$BN_SDK_BIN/d8" --release --min-api 26 --lib "$BN_ANDROID_JAR" \
  --output "$BN_BUILD/dex" "$BN_BUILD/classes.jar"
python3 - "$BN_BUILD" <<'PY'
import pathlib, shutil, sys, zipfile
build = pathlib.Path(sys.argv[1])
apk = build/'unaligned.apk'
shutil.copyfile(build/'resources.apk', apk)
with zipfile.ZipFile(apk, 'a', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((build/'dex').glob('*.dex')): archive.write(path, path.name)
    for path in sorted((build/'jni').rglob('*.so')): archive.write(path, pathlib.Path('lib')/path.relative_to(build/'jni'))
with zipfile.ZipFile(apk) as archive:
    forbidden = [path for path in archive.namelist() if path.startswith('assets/') and not path.startswith('assets/licenses/')]
    if forbidden: raise RuntimeError('Unexpected executable/runtime APK assets: '+str(forbidden))
PY
"$BN_SDK_BIN/zipalign" -P 16 -f 4 "$BN_BUILD/unaligned.apk" "$BN_BUILD/aligned.apk"
printf 'Signing and verifying the native test APK\n'
"$BN_SDK_BIN/apksigner" sign --ks "$BN_KEY" --ks-key-alias badn64 \
  --ks-pass pass:badn64-development --key-pass pass:badn64-development \
  --min-sdk-version 26 --out "$BN_DIST/BadN64-Native-Android16.apk" "$BN_BUILD/aligned.apk"
"$BN_SDK_BIN/apksigner" verify --verbose --print-certs "$BN_DIST/BadN64-Native-Android16.apk" \
  | tee "$BN_BUILD/apk-signature-verification.txt"
"$BN_SDK_BIN/zipalign" -c -P 16 4 "$BN_DIST/BadN64-Native-Android16.apk"
"$BN_SDK_BIN/aapt2" dump badging "$BN_DIST/BadN64-Native-Android16.apk" > "$BN_DIST/apk-badging.txt"
python3 - "$BN_DIST/BadN64-Native-Android16.apk" "$BN_BUILD" "$BN_VERSION_CODE" "$BN_VERSION_NAME" "$BN_SIGNER_SHA256" <<'PY'
import hashlib, json, pathlib, re, sys, zipfile
apk = pathlib.Path(sys.argv[1])
build = pathlib.Path(sys.argv[2])
version_code, version_name, expected_signer = sys.argv[3:6]
certificates = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]+)$',
                        (build/'apk-signature-verification.txt').read_text(), re.MULTILINE)
if [certificate.lower() for certificate in certificates] != [expected_signer]:
    raise RuntimeError('The final APK signing certificate differs from the installed native APK.')
with zipfile.ZipFile(apk) as archive:
    libraries = sorted(path for path in archive.namelist() if path.startswith('lib/') and path.endswith('.so'))
    expected = ['lib/arm64-v8a/'+name for name in ('libbadn64.so', 'libretro.so')]
    if libraries != sorted(expected): raise RuntimeError('The APK is missing a required native ABI.')
    runtime_assets = [path for path in archive.namelist() if path.startswith('assets/') and not path.startswith('assets/licenses/')]
    if runtime_assets: raise RuntimeError('The APK unexpectedly includes executable/runtime assets.')
    for path in archive.namelist():
        if path.endswith('.dex'):
            data = archive.read(path)
            if b'Landroid/webkit/' in data or b'Lcom/eclipsesource/v8/' in data:
                raise RuntimeError('The APK bytecode still refers to a WebView or embedded JavaScript runtime.')
badging = (apk.parent/'apk-badging.txt').read_text()
if "targetSdkVersion:'36'" not in badging or "versionCode='"+version_code+"'" not in badging or "versionName='"+version_name+"'" not in badging:
    raise RuntimeError('The APK version or Android target differs from the native build configuration.')
proof = json.loads((apk.parent/'native-libraries.json').read_text())
proof.update({'artifact': apk.name, 'sha256': hashlib.sha256(apk.read_bytes()).hexdigest(),
              'bytes': apk.stat().st_size, 'target_android_api': 36, 'version_code': int(version_code),
              'version_name': version_name, 'signing_certificate_sha256': expected_signer,
              'signature_verified': True, 'apk_alignment_verified': True,
              'webview_class_references': False, 'javascript_runtime_class_references': False,
              'executable_assets': runtime_assets, 'packaged_native_libraries': libraries})
(apk.parent/'apk-native-verification.json').write_text(json.dumps(proof, indent=2)+'\n')
print('Built native APK: '+str(apk))
print('APK bytes: '+str(apk.stat().st_size))
print('SHA-256: '+hashlib.sha256(apk.read_bytes()).hexdigest())
PY
