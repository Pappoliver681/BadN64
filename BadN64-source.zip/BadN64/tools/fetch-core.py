#!/usr/bin/env python3
"""Fetch and verify the immutable ParaLLEl N64 source used by BadN64."""
import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile

CORE_REPOSITORY = "https://github.com/libretro/parallel-n64.git"
CORE_COMMIT = "862071a8b786224905a763e8b15bdcaf75739341"
CORE_TREE = "b9ad8f8f6d00277e84f2ba63228712e0d7e9bf9d"
PROJECT = pathlib.Path(__file__).resolve().parents[1]


def git(directory, *arguments):
    return subprocess.check_output(
        ["git", "-C", str(directory), *arguments], text=True
    ).strip()


def object_hash(kind, content):
    return hashlib.sha1(kind.encode() + b" " + str(len(content)).encode()
                        + b"\0" + content).hexdigest()


def tree_hash(files):
    root = {}
    for entry in files:
        path = pathlib.PurePosixPath(entry["path"])
        if path.is_absolute() or ".." in path.parts or not path.parts:
            raise RuntimeError("Unsafe source manifest path")
        if entry["mode"] not in ("100644", "100755"):
            raise RuntimeError("Unexpected source manifest file mode")
        current = root
        for component in path.parts[:-1]:
            current = current.setdefault(component, {})
            if not isinstance(current, dict):
                raise RuntimeError("Conflicting source manifest path")
        if path.name in current:
            raise RuntimeError("Duplicate source manifest path")
        current[path.name] = (entry["mode"], entry["blob_sha"])

    def digest(directory):
        rows = []
        for name, entry in directory.items():
            is_directory = isinstance(entry, dict)
            mode, sha = ("40000", digest(entry)) if is_directory else entry
            rows.append((name.encode() + (b"/" if is_directory else b""),
                         mode.encode() + b" " + name.encode() + b"\0"
                         + bytes.fromhex(sha)))
        return object_hash("tree", b"".join(row[1] for row in sorted(rows)))
    return digest(root)


def upstream_file(directory):
    return directory.parent / "parallel-n64.UPSTREAM.json"


def manifest_from_git(directory):
    listing = subprocess.check_output(
        ["git", "-C", str(directory), "ls-tree", "-r", "--full-tree", "-z", "HEAD"]
    )
    files = []
    for row in listing.rstrip(b"\0").split(b"\0"):
        metadata, path = row.split(b"\t", 1)
        mode, kind, sha = metadata.decode().split()
        if kind != "blob":
            raise RuntimeError("Unexpected submodule in pinned source")
        files.append({"mode": mode, "path": path.decode(), "blob_sha": sha})
    return {"repository": CORE_REPOSITORY, "commit": CORE_COMMIT,
            "tree": CORE_TREE, "files_count": len(files), "files": files}


def verify(directory):
    if (directory / ".git").exists():
        if git(directory, "rev-parse", "HEAD") != CORE_COMMIT:
            raise RuntimeError("ParaLLEl N64 checkout is not the pinned BadN64 commit")
        if git(directory, "rev-parse", "HEAD^{tree}") != CORE_TREE:
            raise RuntimeError("ParaLLEl N64 tree does not match the verified source")
        if git(directory, "status", "--porcelain", "--untracked-files=no"):
            raise RuntimeError("Pinned core source has local changes; keep core build patches in the build directory")
        manifest = manifest_from_git(directory)
    else:
        manifest = json.loads(upstream_file(directory).read_text())
        if manifest.get("commit") != CORE_COMMIT or manifest.get("tree") != CORE_TREE:
            raise RuntimeError("Archived core source is not the pinned revision")
    files = manifest["files"]
    if manifest.get("files_count") != len(files) or tree_hash(files) != CORE_TREE:
        raise RuntimeError("Source manifest does not reconstruct the pinned Git tree")
    for entry in files:
        content = (directory / entry["path"]).read_bytes()
        if object_hash("blob", content) != entry["blob_sha"]:
            raise RuntimeError("Pinned core file differs: " + entry["path"])
    required = (
        "jni/Android.mk", "jni/Application.mk", "Makefile.common",
        "libretro/libretro.c", "libretro-common/include/libretro.h",
        "mupen64plus-core/LICENSES", "mupen64plus-rsp-cxd4/COPYING",
        "mupen64plus-rsp-hle/LICENSES",
    )
    for relative in required:
        if not (directory / relative).is_file():
            raise RuntimeError("Incomplete pinned core: " + relative)
    # This commit vendors libretro-common and all plugin sources. No
    # recursively fetched or independently moving submodules are needed.
    if (directory / ".gitmodules").read_text().strip():
        raise RuntimeError("Unexpected submodule dependencies in pinned core")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=pathlib.Path,
                        default=PROJECT / "vendor" / "parallel-n64")
    args = parser.parse_args()
    destination = args.destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        temporary = pathlib.Path(tempfile.mkdtemp(
            prefix="parallel-n64-fetch-", dir=destination.parent))
        try:
            subprocess.run(["git", "init", str(temporary)], check=True)
            subprocess.run(["git", "-C", str(temporary), "remote", "add",
                            "origin", CORE_REPOSITORY], check=True)
            subprocess.run(["git", "-C", str(temporary), "fetch", "--depth=1",
                            "origin", CORE_COMMIT], check=True)
            subprocess.run(["git", "-C", str(temporary), "checkout", "--detach",
                            CORE_COMMIT], check=True)
            verify(temporary)
            temporary.rename(destination)
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
    manifest = verify(destination)
    upstream_file(destination).write_text(json.dumps(manifest, indent=2) + "\n")
    provenance = {
        "repository": CORE_REPOSITORY, "commit": CORE_COMMIT,
        "tree": CORE_TREE, "submodules": [],
        "ram_api": "RETRO_MEMORY_SYSTEM_RAM", "ram_bytes": 0x800000,
        "renderer": "angrylion", "rsp": "cxd4", "cpu": "cached_interpreter",
    }
    (destination.parent / "parallel-n64.revision.json").write_text(
        json.dumps(provenance, indent=2) + "\n")
    print("Verified pinned ParaLLEl N64 " + CORE_COMMIT, flush=True)


if __name__ == "__main__":
    main()
