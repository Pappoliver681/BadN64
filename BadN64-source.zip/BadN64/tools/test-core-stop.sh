#!/usr/bin/env bash
# Stop actual CPU/RSP guest loops that cannot reach a VI frame boundary.
set -Eeuo pipefail
if [[ $# != 3 ]]; then
  printf 'Usage: %s CORE_SO INPUT_RDP_ROM OUTPUT_DIRECTORY\n' "$0" >&2
  exit 2
fi
BN_STOP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_STOP_CORE="$(realpath -- "$1")"
BN_STOP_ROM="$(realpath -- "$2")"
python3 - "$BN_STOP_ROM" <<'PY'
from pathlib import Path
import hashlib, sys
data = Path(sys.argv[1]).read_bytes()
expected = '3053429905540e7f552e5d587ed30adb6c1a4b63e2f7c3a1551ea880625d8e6f'
if hashlib.sha256(data).hexdigest() != expected:
    raise RuntimeError('Stop regression requires the verified Unlicense InputRDP fixture')
PY
mkdir -p -- "$3"
BN_STOP_OUTPUT="$(cd -- "$3" && pwd)"
BN_STOP_BUILD="$(mktemp -d "${TMPDIR:-/tmp}/badn64-stop.XXXXXX")"
trap 'rm -rf -- "$BN_STOP_BUILD"' EXIT
"${CXX:-c++}" -std=c++17 -O2 -Wall -Wextra -Werror \
  -I "$BN_STOP_ROOT/tests/include" "$BN_STOP_ROOT/tests/native/core-stop.cpp" \
  -ldl -pthread -o "$BN_STOP_BUILD/core-stop"
for BN_STOP_CPU in cached_interpreter pure_interpreter; do
  timeout --kill-after=5s 30s "$BN_STOP_BUILD/core-stop" \
    "$BN_STOP_CORE" "$BN_STOP_ROM" "$BN_STOP_OUTPUT/core-stop-$BN_STOP_CPU-report.json" \
    "$BN_STOP_CPU" 2>&1 | tee "$BN_STOP_OUTPUT/core-stop-$BN_STOP_CPU-validation.log"
done
