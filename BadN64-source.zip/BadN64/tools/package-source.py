#!/usr/bin/env python3
"""Create a deterministic BadN64 source ZIP, including only verified core source."""
import argparse
import hashlib
import json
import pathlib
import runpy
import stat
import subprocess
import zipfile

PROJECT = pathlib.Path(__file__).resolve().parents[1]
EXCLUDED_ROOTS = {'build', 'dist', 'signing', 'toolchain', 'test-results', '.git', '.gradle'}
EXCLUDED_PARTS = {'.git', '__pycache__'}
EXCLUDED_SUFFIXES = {'.apk', '.keystore', '.jks', '.class', '.dex', '.o', '.so', '.pyc', '.zip'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=pathlib.Path, default=PROJECT/'dist/BadN64-source.zip')
    args = parser.parse_args()
    helpers = runpy.run_path(str(PROJECT/'tools/fetch-core.py'))
    vendor = PROJECT/'vendor/parallel-n64'
    manifest = None
    if vendor.exists():
        try:
            manifest = helpers['verify'](vendor)
        except (OSError, ValueError, RuntimeError, KeyError, subprocess.CalledProcessError) as error:
            print('Omitting incomplete or altered core source: ' + str(error))
    source = {}
    for path in sorted(PROJECT.rglob('*')):
        relative = path.relative_to(PROJECT)
        if (relative.parts[0] in EXCLUDED_ROOTS
                or any(part in EXCLUDED_PARTS for part in relative.parts)
                or path.suffix.lower() in EXCLUDED_SUFFIXES):
            continue
        if relative.parts[0] == 'vendor':
            continue  # Verified upstream entries are selected below.
        if path.is_symlink():
            raise RuntimeError('Unexpected project symlink: ' + str(relative))
        if path.is_file():
            mode = 0o755 if path.suffix in {'.sh', '.py'} else 0o644
            source[relative.as_posix()] = (path.read_bytes(), mode)
    if manifest:
        for entry in manifest['files']:
            path = vendor/entry['path']
            if path.is_symlink():
                raise RuntimeError('Unexpected pinned core symlink: ' + entry['path'])
            source['vendor/parallel-n64/'+entry['path']] = (
                path.read_bytes(), 0o755 if entry['mode'] == '100755' else 0o644)
        source['vendor/parallel-n64.UPSTREAM.json'] = (
            (json.dumps(manifest, indent=2)+'\n').encode(), 0o644)
        revision = PROJECT/'vendor/parallel-n64.revision.json'
        if revision.is_file():
            source['vendor/parallel-n64.revision.json'] = (revision.read_bytes(), 0o644)
    required = ('README.md', 'tools/fetch-core.py', 'tools/build-core.sh',
                'tools/native-runtime-build.sh', 'app/src/main/cpp/rtc_engine.cpp')
    for name in required:
        if name not in source:
            raise RuntimeError('Source package is missing ' + name)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (content, mode) in sorted(source.items()):
            entry = zipfile.ZipInfo('BadN64/'+name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = (stat.S_IFREG | mode) << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix+'.sha256').write_text(digest+'  '+output.name+'\n')
    print(('Complete corresponding source' if manifest else 'Source with pinned core fetch recipe')
          + ': ' + str(output) + ' (' + str(len(source)) + ' files)')
    print('SHA-256: ' + digest)


if __name__ == '__main__':
    main()
