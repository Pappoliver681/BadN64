#!/usr/bin/env python3
"""Apply reviewed compatibility fixes to a build copy of the pinned core."""
import argparse
import hashlib
import json
from pathlib import Path

CORE_COMMIT = '862071a8b786224905a763e8b15bdcaf75739341'
HEADER_PATH = 'mupen64plus-core/src/device/r4300/r4300.h'
ORIGINAL_SHA256 = '2d22c057f0e08c6ba9ae4849ca3e133c9a035770d8e3c7201a5e8743e4a0df96'
ORIGINAL_SELECTOR = b'#if !defined(__arm64__) && !defined(__aarch64__)'
FIXED_SELECTOR = b'#if (!defined(__arm64__) && !defined(__aarch64__)) || !defined(NEW_DYNAREC)'
FIX_ID = 'arm64-interpreter-state-v1'


def patch(source: Path) -> dict:
    # The corresponding upstream tree stays pristine for source verification.
    if source.resolve().parent.name == 'vendor':
        raise RuntimeError('Apply core fixes to a build copy, not the verified vendor tree')
    header = source / HEADER_PATH
    original = header.read_bytes()
    digest = hashlib.sha256(original).hexdigest()
    if digest != ORIGINAL_SHA256 or original.count(ORIGINAL_SELECTOR) != 1:
        raise RuntimeError('The pinned r4300.h differs; review this fix before applying it')
    # ARM64's hot aliases belong to the Ari64 JIT. Interpreter-only builds
    # must share the base register/stop fields used by r4300_* accessors.
    # Otherwise the first VI leaves a hot stop flag set, and the next slice
    # cannot yield. First retro_run already executes both of those slices.
    fixed = original.replace(ORIGINAL_SELECTOR, FIXED_SELECTOR, 1)
    header.write_bytes(fixed)
    provenance = {
        'core_commit': CORE_COMMIT,
        'fix_id': FIX_ID,
        'file': HEADER_PATH,
        'original_sha256': digest,
        'patched_sha256': hashlib.sha256(fixed).hexdigest(),
        'change': 'Use base CPU state on ARM64 when NEW_DYNAREC is absent',
    }
    (source / 'badn64-core-fixes.json').write_text(
        json.dumps(provenance, indent=2) + '\n', encoding='utf-8')
    return provenance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Fresh build copy of the pinned core')
    args = parser.parse_args()
    result = patch(args.source)
    print(f"Applied {result['fix_id']}: {result['file']}")


if __name__ == '__main__':
    main()
