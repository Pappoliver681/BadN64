#!/usr/bin/env python3
"""Apply reviewed compatibility fixes to a build copy of the pinned core."""
import argparse
import hashlib
import json
from pathlib import Path

CORE_COMMIT = '862071a8b786224905a763e8b15bdcaf75739341'
HEADER_PATH = 'mupen64plus-core/src/device/r4300/r4300.h'
ORIGINAL_SHA256 = '2d22c057f0e08c6ba9ae4849ca3e133c9a035770d8e3c7201a5e8743e4a0df96'
ORIGINAL_SELECTOR = b'#if !defined(__arm64__) && !defined(__aarch64__)'
FIXED_SELECTOR = b'#if (!defined(__arm64__) && !defined(__aarch64__)) || !defined(NEW_DYNAREC)'
FIX_ID = 'badn64-lifecycle-cached-v3'
PINNED_FILES = {
    HEADER_PATH: ORIGINAL_SHA256,
    'libretro/libretro.c': '39a4ca8be8f5c3bfab7a9312f4fe1568cfb3717bb922872a024b49d28627f30e',
    'libretro/link.T': 'ed90ace7dd712bc7670bd58c5c05523f4b6d0d9ec47e4b3ec0123fb7dc476865',
    'mupen64plus-core/src/main/main.c': '348fa92c845b07a241f754db977ecb442092c610ebdf66993370714582496607',
    'mupen64plus-core/src/device/r4300/r4300_core.c': 'aab5d7e3f66f2b380d5389303548e9c6ae9c085721ab4265b119bcd5ab3c7734',
    'mupen64plus-core/src/device/r4300/pure_interp.c': '3398326e14d999907c3c5b09f8270488e2a10bbc04b3cf7de6547ec2d21bff49',
    'mupen64plus-core/src/device/r4300/cached_interp.c': 'de6239cadc5461ae50da953a1d21a7a8010e912f67fb1f8123511c08e06cb107',
    'mupen64plus-rsp-cxd4/su.c': '21c78d4b9f6acad699b3a4a6df3f36171c1d580face18ebbe74c900fe3d0d3a3',
    'mupen64plus-video-angrylion/interface.c': 'f561992a10099576a78c8fe68f907d1d27e0bfbf47190cfee19dc3b55b5048bd',
    'mupen64plus-video-angrylion/n64video.c': 'c82f895857f415540a2acec099f68a2dcccf1cfba3aa271c5ab091828d0c19d8',
    'mupen64plus-core/src/device/rcp/ai/ai_controller.c': '5897d9f106fb2e287db7b95bc75dd6ef5bbfafe7576fcb6da5edd4380bf3b1f1',
}


def replace_once(text: str, before: str, after: str) -> str:
    if text.count(before) != 1:
        raise RuntimeError(f'Expected one reviewed patch location: {before[:80]!r}')
    return text.replace(before, after, 1)


def patch(source: Path) -> dict:
    # The corresponding upstream tree stays pristine for source verification.
    if source.resolve().parent.name == 'vendor':
        raise RuntimeError('Apply core fixes to a build copy, not the verified vendor tree')
    originals = {}
    for name, expected in PINNED_FILES.items():
        data = (source / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise RuntimeError(f'The pinned {name} differs; review these fixes before applying them')
        originals[name] = data
    texts = {name: data.decode('utf-8') for name, data in originals.items()}
    # ARM64's hot aliases belong to the Ari64 JIT. Interpreter-only builds
    # must share the base register/stop fields used by r4300_* accessors.
    # Otherwise the first VI leaves a hot stop flag set, and the next slice
    # cannot yield. First retro_run already executes both of those slices.
    texts[HEADER_PATH] = replace_once(texts[HEADER_PATH], ORIGINAL_SELECTOR.decode(), FIXED_SELECTOR.decode())

    main_name = 'mupen64plus-core/src/main/main.c'
    main = texts[main_name]
    main = replace_once(main, '    if (l_setup_done) {', '''    if (l_setup_done) {
        /* Closing a paused frame must tear down the CPU and plugins rather
         * than clearing its stop flag and executing another guest frame. */
        if (g_real_stop) {
            *r4300_stop(&g_dev.r4300) = 1;
            run_device(&g_dev);
            goto stop_cleanup;
        }''')
    main = replace_once(main, 'extern int frame_break;', 'extern int g_real_stop;\nextern int frame_break;')
    main = replace_once(main, '    /* Genuine stop: allow the one-time setup',
                        'stop_cleanup:\n    /* Genuine stop: allow the one-time setup')
    texts[main_name] = main

    cpu_name = 'mupen64plus-core/src/device/r4300/r4300_core.c'
    cpu = texts[cpu_name]
    cpu = replace_once(cpu, 'void run_r4300(struct r4300_core* r4300)',
                       'extern int g_real_stop;\nvoid run_r4300(struct r4300_core* r4300)')
    # A genuine stop traverses existing cache teardown, executing no opcodes.
    cpu = replace_once(cpu, '    *r4300_stop(r4300) = 0;',
                       '    *r4300_stop(r4300) = g_real_stop ? 1 : 0;')
    texts[cpu_name] = cpu
    pure_name = 'mupen64plus-core/src/device/r4300/pure_interp.c'
    pure = replace_once(texts[pure_name], 'extern int frame_break;',
                        'extern int g_real_stop;\nextern int frame_break;')
    if pure.count('      *r4300_stop(r4300) = 0;') != 2:
        raise RuntimeError('The reviewed pure interpreter entry changed')
    pure = pure.replace('      *r4300_stop(r4300) = 0;',
                        '      *r4300_stop(r4300) = g_real_stop ? 1 : 0;')
    pure = replace_once(pure, 'void run_pure_interpreter(struct r4300_core* r4300)',
                        'extern int badn64_rtc_poll_stop(void);\nvoid run_pure_interpreter(struct r4300_core* r4300)')
    pure = replace_once(pure, '   static int l_pi_started = 0;',
                        '   unsigned int stop_poll = 0;\n   static int l_pi_started = 0;')
    pure = replace_once(pure, '#endif\n     InterpretOpcode(r4300);',
                        '#endif\n     if ((++stop_poll & 0x3ff) == 0 && badn64_rtc_poll_stop()) break;\n     InterpretOpcode(r4300);')
    texts[pure_name] = pure
    cached_name = 'mupen64plus-core/src/device/r4300/cached_interp.c'
    cached = replace_once(texts[cached_name],
                         'void run_cached_interpreter(struct r4300_core* r4300)\n{',
                         'extern int badn64_rtc_poll_stop(void);\nvoid run_cached_interpreter(struct r4300_core* r4300)\n{\n    unsigned int stop_poll = 0;')
    cached = replace_once(cached, '#endif\n        (*r4300_pc_struct(r4300))->ops();',
                          '#endif\n        if ((++stop_poll & 0x3ff) == 0 && badn64_rtc_poll_stop()) break;\n        (*r4300_pc_struct(r4300))->ops();')
    texts[cached_name] = cached
    rsp_name = 'mupen64plus-rsp-cxd4/su.c'
    rsp = replace_once(texts[rsp_name], 'NOINLINE void run_task(void)',
                       'extern int badn64_rtc_poll_stop(void);\nNOINLINE void run_task(void)')
    # The EX label is also reached by branch-delay dispatch, bypassing the
    # ordinary for-loop header; check here so even that guest loop yields.
    rsp = replace_once(rsp, 'EX:\n#endif\n#ifdef SP_EXECUTE_LOG',
                       'EX:\n#endif\n        if ((++halt_poll & 0x3ff) == 0 && badn64_rtc_poll_stop())\n            goto RSP_halted_CPU_exit_point;\n#ifdef SP_EXECUTE_LOG')
    texts[rsp_name] = rsp

    retro_name = 'libretro/libretro.c'
    retro = texts[retro_name]
    retro = replace_once(retro, 'static bool initializing            = true;',
        '''static bool initializing            = true;
static unsigned int rtc_stop_requested;
static void (*rtc_buffer_callback)(unsigned, unsigned, uint32_t, uint32_t);''')
    old_unload = retro[retro.index('void retro_unload_game(void)'):retro.index('\n#if defined(HAVE_OPENGL) || defined(HAVE_OPENGLES)\nstatic void glsm_exit')]
    retro = replace_once(retro, old_unload, '''void retro_unload_game(void)
{
    g_rsp_force_halt = 1;
    mupen_main_stop();
    frame_break = 0;
    stop_stepping = false;
    if (g_EmulatorRunning)
        main_run(); /* Genuine-stop path closes CPU caches and all plugins. */
    else if (emu_initialized)
        mupen_main_exit();

    g_EmulatorRunning = 0;
    CoreDoCommand(M64CMD_ROM_CLOSE, 0, NULL);
    emu_initialized = false;
    initializing = true;
    context_setup_first_init = false;
    first_context_reset = false;
    first_time = 1;
    frame_latched = false;
    screen_pixels = NULL;
    screen_pitch = 0;
    __atomic_store_n(&rtc_stop_requested, 0, __ATOMIC_RELEASE);
}
''')
    retro = replace_once(retro, '   mupencorestop      = false;\n   g_rsp_force_halt   = 0;',
                         '   __atomic_store_n(&rtc_stop_requested, 0, __ATOMIC_RELEASE);\n   g_real_stop       = 0;\n   mupencorestop      = false;\n   g_rsp_force_halt   = 0;')
    retro = replace_once(retro, '   mupen_main_stop();\n   mupen_main_exit();\n\n   deinit_audio_libretro();',
                         '   if (emu_initialized)\n      retro_unload_game();\n   rtc_buffer_callback = NULL;\n\n   deinit_audio_libretro();')
    hook = '''/* This setter is the only extension callable from another thread.
 * CPU/RSP state is changed exclusively by the emulation-thread poll below. */
void retro_rtc_request_stop(void)
{
    __atomic_store_n(&rtc_stop_requested, 1, __ATOMIC_RELEASE);
}

int badn64_rtc_poll_stop(void)
{
    if (!__atomic_load_n(&rtc_stop_requested, __ATOMIC_ACQUIRE))
        return 0;
    /* Yield out of the current slice; leave caches/plugins alive until the
     * queued unload traverses its genuine-stop teardown. Keep the request
     * latched across both slices performed by the first retro_run. */
    frame_break = 1;
    stop_stepping = true;
    mupencorestop = 1;
    *r4300_stop(&g_dev.r4300) = 1;
    return 1;
}

/* BadN64 extension: call on the emulation thread after a batch of
 * external RDRAM writes, before the next frame. Both direct and TLB aliases
 * are invalidated; the saved decoded PC must also be rebound immediately. */
void retro_rtc_invalidate_code(void)
{
    if (initializing || !emu_initialized || g_real_stop
        || g_dev.r4300.emumode == EMUMODE_PURE_INTERPRETER)
        return;
    uint32_t pc = *r4300_pc(&g_dev.r4300);
    uint32_t pending_jump = g_dev.r4300.skip_jump;
    invalidate_r4300_cached_code(&g_dev.r4300, 0, 0);
    g_dev.r4300.skip_jump = 0;
    generic_jump_to(&g_dev.r4300, pc);
    g_dev.r4300.skip_jump = pending_jump;
}

/* Buffer events describe real guest memory immediately before the hardware
 * reads it. IDs are RDRAM=0 and RSP DMEM=1, both native word byte order. */
void retro_rtc_set_buffer_callback(void (*callback)(unsigned, unsigned, uint32_t, uint32_t))
{
    rtc_buffer_callback = callback;
}

void *retro_rtc_get_memory_data(unsigned id)
{
    if (initializing || !emu_initialized || g_real_stop)
        return NULL;
    if (id == 0) return g_dev.rdram.dram;
    if (id == 1) return g_dev.sp.mem;
    return NULL;
}

size_t retro_rtc_get_memory_size(unsigned id)
{
    if (initializing || !emu_initialized || g_real_stop)
        return 0;
    if (id == 0) return g_dev.rdram.dram_size;
    if (id == 1) return 0x1000;
    return 0;
}

void badn64_rtc_buffer_event(unsigned kind, unsigned memory_id, uint32_t address, uint32_t length)
{
    if (rtc_buffer_callback && !initializing && emu_initialized && !g_real_stop && length)
        rtc_buffer_callback(kind, memory_id, address, length);
}

'''
    retro = replace_once(retro, 'bool retro_unserialize(const void * data, size_t size)',
                         hook + 'bool retro_unserialize(const void * data, size_t size)')
    retro = replace_once(retro, '    if (savestates_load_m64p(data, size))\n    {',
                         '    if (savestates_load_m64p(data, size))\n    {\n        retro_rtc_invalidate_code();')
    texts[retro_name] = retro
    texts['libretro/link.T'] = replace_once(texts['libretro/link.T'],
                                          '      retro_run;',
                                          '''      retro_run;
      retro_rtc_request_stop;
      retro_rtc_invalidate_code;
      retro_rtc_set_buffer_callback;
      retro_rtc_get_memory_data;
      retro_rtc_get_memory_size;''')
    graphics_name = 'mupen64plus-video-angrylion/interface.c'
    texts[graphics_name] = replace_once(texts[graphics_name],
        'void angrylionRomClosed (void)\n{\n  n64video_close();\n}',
        'void angrylionRomClosed (void)\n{\n  n64video_close();\n  angrylion_init = false;\n}')

    rdp_name = 'mupen64plus-video-angrylion/n64video.c'
    rdp = replace_once(texts[rdp_name], 'void n64video_process_list(void)',
        '''extern int badn64_rtc_poll_stop(void);
extern void badn64_rtc_buffer_event(unsigned, unsigned, uint32_t, uint32_t);
void n64video_process_list(void)''')
    rdp = replace_once(rdp, '        uint32_t i, toload;',
                       '        if (badn64_rtc_poll_stop()) return;\n        uint32_t i, toload;')
    rdp = replace_once(rdp, '    // while there\'s data in the command buffer...',
        '''    /* A retained fragment starts inside an earlier command, so its
     * coefficients cannot safely be parsed as a new opcode by the frontend.
     * HLE's synthetic host buffer is not guest RAM. XBUS wraps in 4 KiB;
     * only the first contiguous part is known to start at a command boundary. */
    if (hle_cmd_buf == NULL && rdp_cmd_pos == 0) {
        uint32_t address = dp_current_al << 2;
        uint32_t length = (dp_end_al - dp_current_al) << 2;
        if (*dp_reg[DP_STATUS] & DP_STATUS_XBUS_DMA) {
            address &= 0xfff;
            if (length > 0x1000) length = 0x1000;
            uint32_t first = MIN(length, 0x1000 - address);
            badn64_rtc_buffer_event(1, 1, address, first);
        } else if (address < config.gfx.rdram_size) {
            uint32_t available = (uint32_t)(config.gfx.rdram_size - address);
            badn64_rtc_buffer_event(1, 0, address, MIN(length, available));
        }
    }
    // while there's data in the command buffer...''')
    texts[rdp_name] = rdp
    ai_name = 'mupen64plus-core/src/device/rcp/ai/ai_controller.c'
    ai = replace_once(texts[ai_name], 'static void ai_push_span(struct ai_controller* ai, unsigned int diff,',
        '''extern void badn64_rtc_buffer_event(unsigned, unsigned, uint32_t, uint32_t);
static void ai_push_span(struct ai_controller* ai, unsigned int diff,''')
    ai = replace_once(ai, '    push_audio_samples_via_libretro(\n        (unsigned char*)ai->ri->rdram->dram + start + diff, length);',
        '''    length &= ~UINT32_C(3);
    badn64_rtc_buffer_event(2, 0, start + diff, length);
    push_audio_samples_via_libretro(
        (unsigned char*)ai->ri->rdram->dram + start + diff, length);''')
    texts[ai_name] = ai

    files = []
    for name, text in texts.items():
        fixed = text.encode('utf-8')
        (source / name).write_bytes(fixed)
        files.append({'file': name, 'original_sha256': PINNED_FILES[name],
                      'patched_sha256': hashlib.sha256(fixed).hexdigest()})
    provenance = {
        'core_commit': CORE_COMMIT,
        'fix_id': FIX_ID,
        'files': files,
        'changes': ['ARM64 interpreter CPU state aliases',
                    'Genuine CPU/plugin teardown and fresh ROM setup',
                    'Cached interpreter invalidation and decoded-PC refresh',
                    'Atomic cooperative CPU/RSP/RDP cancellation before unload',
                    'Guest RDP and AI buffer callbacks before hardware reads'],
    }
    (source / 'badn64-core-fixes.json').write_text(
        json.dumps(provenance, indent=2) + '\n', encoding='utf-8')
    return provenance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Fresh build copy of the pinned core')
    args = parser.parse_args()
    result = patch(args.source)
    print(f"Applied {result['fix_id']}: {len(result['files'])} reviewed files")


if __name__ == '__main__':
    main()
