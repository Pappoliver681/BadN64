#!/usr/bin/env bash
# Link production frontend code to the already-built real Linux N64 core.
set -Eeuo pipefail
if [[ $# != 3 ]]; then
  printf 'Usage: %s CORE_SO ROM OUTPUT_DIRECTORY\n' "$0" >&2
  exit 2
fi
BN_REAL_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BN_REAL_CORE="$(realpath -- "$1")"
BN_REAL_ROM="$(realpath -- "$2")"
mkdir -p -- "$3"
BN_REAL_OUTPUT="$(cd -- "$3" && pwd)"
BN_REAL_BUILD="$(mktemp -d "${TMPDIR:-/tmp}/badn64-real-backend.XXXXXX")"
trap 'rm -rf -- "$BN_REAL_BUILD"' EXIT
"${CXX:-c++}" -std=c++17 -O2 -Wall -Wextra -pthread \
  -I "$BN_REAL_ROOT/app/src/main/cpp" -I "$BN_REAL_ROOT/tests/include" \
  "$BN_REAL_ROOT/tests/native/backend-real.cpp" \
  "$BN_REAL_ROOT/app/src/main/cpp/native_backend.cpp" \
  "$BN_REAL_ROOT/app/src/main/cpp/rtc_engine.cpp" \
  "$BN_REAL_CORE" -lz -o "$BN_REAL_BUILD/backend-real"
BN_REAL_CORE_DIRECTORY="$(dirname -- "$BN_REAL_CORE")"
LD_LIBRARY_PATH="$BN_REAL_CORE_DIRECTORY${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
  timeout --kill-after=5s 90s "$BN_REAL_BUILD/backend-real" "$BN_REAL_ROM" "$BN_REAL_OUTPUT"
