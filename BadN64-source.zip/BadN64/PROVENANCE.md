# BadN64 source provenance

BadN64 is a separate native Android project, package `com.badn64.app`, using the native RTC interface and menu behavior developed for BadGenesis as its reference. Its N64 frontend, controller mapping, ROM normalization and memory adapter target ParaLLEl N64.

The emulator source is pinned to libretro/parallel-n64 commit `862071a8b786224905a763e8b15bdcaf75739341`, tree `b9ad8f8f6d00277e84f2ba63228712e0d7e9bf9d`. `tools/fetch-core.py` verifies the complete source against its Git object manifest. Original copyright and license notices remain in the source package.

Version 0.1.1 applies one core fix to build copies: in `mupen64plus-core/src/device/r4300/r4300.h`, ARM64 builds without `NEW_DYNAREC` use the existing base CPU register, accumulator and stop aliases. The original selector always chose dynamic-recompiler storage on ARM64, while the pure interpreter and per-frame reset used the base CPU stop flag. After the first hardware frame, the remaining stop flag prevented the next frame from yielding and the public `retro_run` call hung. The documented patch helper and build scripts are included in corresponding source; the pinned vendor files remain unmodified.

The software-core test uses a public-domain InputRDP homebrew fixture by Peter Lemon. Its original binary/source and a variant that waits for the controller interface to become idle are included under `tests/fixtures/input-rdp`, with the upstream Unlicense, checksums, source diff and detailed provenance.

Testing includes the actual software core and production frontend adapter on Linux. A regression reproduces the ARM64 alias-selection defect on the host; this is a targeted storage-selection test, not execution of an ARM64 Android binary. Commercial-game compatibility and physical-device performance remain unverified.
