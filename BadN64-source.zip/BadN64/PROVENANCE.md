# BadN64 source provenance

BadN64 is a separate native Android project, package `com.badn64.app`, using the native RTC interface and menu behavior developed for BadGenesis as its reference. Its N64 frontend, controller mapping, ROM normalization and memory adapter target ParaLLEl N64.

The emulator source is pinned to libretro/parallel-n64 commit `862071a8b786224905a763e8b15bdcaf75739341`, tree `b9ad8f8f6d00277e84f2ba63228712e0d7e9bf9d`. `tools/fetch-core.py` verifies the complete source against its Git object manifest. Original copyright and license notices remain in the source package.

Version 0.1.2 applies `badn64-lifecycle-cached-v3` through `tools/patch-core.py` to separate build copies. The helper verifies every original file against its pinned SHA-256 and writes a report containing each patched hash. The pinned vendor files remain unmodified. The changes are:

- ARM64 builds without `NEW_DYNAREC` use base CPU register, accumulator and stop aliases. This retains the 0.1.1 fix for first-frame interpreter hangs.
- ROM unload follows a genuine-stop path, releases CPU caches and plugins, resets renderer initialization and allows the next ROM to boot from fresh state.
- A thread-safe cooperative-stop extension lets the emulation thread yield from a guest loop before queued close/replacement runs. UI/native callers only set an atomic request; CPU state changes stay on the emulator thread.
- A frontend extension invalidates cached instructions and refreshes the decoded program counter after external RAM writes and state restoration.
- RDP and AI callbacks expose active guest-memory buffers immediately before the hardware reads them. Graphics RTC changes geometry/color payloads; audio RTC changes game PCM in RDRAM. These are source-memory mutations, with canonical-address Undo records.

The Android frontend cancels stale ROM/picker operations when a game is closed or replaced. The native backend clears per-game memory adapters, state/recovery data, audio, controls and pending targeted work on close. Normal play uses the cached interpreter with rewind off by default and a Fast/Accurate VI output choice; software Angrylion and cxd4 remain selected. Fast output skips the core's VI smoothing and has a different framebuffer size/appearance; its host benchmark does not establish Android frame rates.

The software-core test uses a public-domain InputRDP homebrew fixture by Peter Lemon. Its original binary/source and a variant that waits for the controller interface to become idle are included under `tests/fixtures/input-rdp`, with the upstream Unlicense, checksums, source diff and detailed provenance.

The additional triangle/audio fixture under `tests/fixtures/triangle-audio` includes its source, Unlicense and checksums. It submits RDP triangle commands and loops AI audio, allowing regression tests to observe actual polygon shape and PCM changes through production RTC helpers and Undo.

`tests/native/core-stop.cpp` constructs original public-domain CPU/RSP loop programs in the verified InputRDP boot image and recalculates CIC6102 checksums. Guest-written RAM/DMEM markers distinguish a deliberate running loop from an invalid boot. Both interpreter modes must remain blocked before the stop request, return after it, unload all active memory domains and render a fresh ROM with no stale guest marker.

Testing includes the actual software core and production frontend adapter on Linux. A regression reproduces the ARM64 alias-selection defect on the host; this is a targeted storage-selection test, not execution of an ARM64 Android binary. Commercial-game compatibility and physical-device performance remain unverified.
