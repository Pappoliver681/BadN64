# BadN64

BadN64 is an experimental native Android N64 emulator with the RTC controls and native menu style from BadGenesis. It uses its own application ID, `com.badn64.app`, and signing key. Version 0.1.2 targets Android 16/API 36 and requires a 64-bit ARM device running Android 8/API 26 or later.

The emulator is ParaLLEl N64 pinned to commit `862071a8b786224905a763e8b15bdcaf75739341`. Version 0.1.2 adds genuine CPU/plugin teardown when closing a game, fresh initialization when switching ROMs, cached-interpreter invalidation after RTC writes, and hooks into guest RDP and AI buffers. It retains the ARM64 interpreter register/stop alias correction from 0.1.1. The verified upstream source remains unchanged in `vendor/`; `tools/patch-core.py` applies the documented changes to separate build copies.

This build selects `cached_interpreter`, synchronous Angrylion software graphics and the cxd4 RSP. RTC writes invalidate decoded instructions between frames, including a refresh of the saved program counter. Rewind is off by default, avoiding periodic large-state serialization during normal play. Display settings offer Fast video (the default, direct color-buffer output) and Accurate video (the core's normal N64 VI smoothing), applied on the next ROM load. The renderer and RSP still run in software; these changes do not establish full-speed commercial-game performance on Android.

## Features

Open `.z64`, `.n64` or `.v64` cartridge ROMs, including ROMs inside ZIP files, through Android's document picker or a selected ROM folder. The original document is opened read-only. Native touch controls provide an analog stick, D-pad, A/B, four C buttons, L/R/Z and Start. Control size, opacity and group positions are adjustable. Android gamepads and keyboards are supported.

The native worker owns emulation timing, memory mutation and states. Android presentation runs separately and scales the software framebuffer with nearest-neighbor sampling. Audio comes from the emulation core through native stereo PCM.

Close and replacement request a cooperative stop before joining the worker queue. The CPU/RSP observe the atomic request on the emulation thread, so a guest loop that stops reaching video interrupts can yield for teardown. This mechanism does not recover the process from an arbitrary native crash.

- Blast Once, the gameplay Blast shortcut, Undo, history and recorded replay.
- General RAM, Graphics / polygons and Game audio targets. Graphics targets mutate active RDP geometry/color payloads before command fetch; audio targets mutate the game's active PCM in RDRAM before the AI reads it. These targets wait for the next matching buffer while the game runs and record actual memory addresses for Undo.
- Auto Blast intervals measured in emulated frames, domain address ranges and exclusions, and adjustable intensity.
- Bit Flip, Random Byte, Add, Subtract, Tilt, Zero, FF, Swap, aligned big-endian 16/32-bit words and aligned 32-bit MIPS NOP.
- Fresh system randomness by default for every RAM, polygon and audio blast, including Auto Blast; an optional manual seed supports repeatable blasts.
- Writable live RDRAM, RSP DMEM and the core's combined save-memory buffer; a read-only canonical ROM domain. Graphics/audio targets use active buffers independently of the General RAM domain ranges.
- Quick Save, four save slots, state import/export, save-memory import/export and pre-blast recovery.
- Optional RAM rewind with reverse deltas and reverse playback of recorded stereo PCM. Larger snapshot intervals produce larger visual steps. Its 96 MiB budget and N64 state size can shorten the selected duration; enabling it adds CPU and memory cost.
- Glitch Harvester: capture a clean state, blast, run selected frames, then keep or discard the result.
- A read-only memory inspector and native status information.

The `sram` domain and `.srm` exports contain the core's combined save-memory buffer, including EEPROM, SRAM, FlashRAM and Controller Pak data. Imports require the complete buffer with the exact expected size. Save files from other emulators may use a different layout.

## State limitations

The pinned core serializes CPU/TLB/registers, RDRAM, RSP memory and other machine state. BadN64 also stores save memory, the displayed framebuffer, frontend audio phase and RTC timeline metadata. The public libretro serializer omits Angrylion's private hidden bits/TMEM/tile state and cxd4's private vector/pipeline state. Save/load and rewind can therefore show graphics glitches when restoring an in-flight RDP/RSP operation; exact future execution has not been established for games.

States identify the original ROM, pinned core/configuration and CPU architecture. States from BadGenesis and earlier BadN64 core configurations are incompatible. Closing a ROM disables Auto Blast and cancels pending targeted blasts. No commercial game ROMs are included. The source package contains public-domain InputRDP and triangle/audio homebrew fixtures, with source, licenses and checksums. The InputRDP timing-corrected variant waits for the controller interface to finish each transfer.

## Build

Use a Linux host with a full JDK 17 or later, Python 3, Git, curl, CMake, Make and a C/C++ toolchain. The Linux core smoke test also requires OpenGL headers (`libgl-dev` on Debian/Ubuntu); the script installs those automatically in GitHub Actions. JDK 21 is suitable. The first build downloads the pinned core and official Android SDK/NDK components, requiring network access and several GiB of free space.

```sh
bash tools/test-native.sh
bash tools/test-backend.sh
bash tools/test-core.sh
bash tools/native-runtime-build.sh
```

The standalone RTC tests cover mutation bounds/alignment, N64 word-swapped byte adapters, MIPS NOP, Undo/replay, seeds, frame intervals, checkpoints and targeted payload bounds/opcode preservation. Repeated polygon/audio target tests verify fresh random seeds and varied mutation patterns. Java tests exercise cancellation of superseded content requests. Backend smoke tests exercise the production adapter with a test libretro fixture, including superseded-load/close races. `tools/test-core.sh` separately builds the real software core and checks rendered frames, input, full RDRAM save/load, warmed-code invalidation and all three ROM formats. Its production-adapter regressions cover close/reload, switching distinct ROMs, pause/resume, Fast/Accurate output and state restoration. Original CPU/RSP loop programs built from the verified homebrew boot image prove that a core call blocked without video interrupts releases on an atomic stop, unloads and boots a fresh ROM in both interpreter modes. The triangle/audio fixture checks actual rendered geometry and emitted PCM changes from targeted RTC memory writes, followed by Undo. These checks run on Linux and do not execute an Android ARM64 binary or establish physical-device performance. A complete source package includes the core and fixtures; missing sources or Linux build dependencies require network access.

`tools/native-runtime-build.sh` verifies/downloads the pinned core with `tools/fetch-core.py`, builds it with `tools/build-core.sh`, compiles the JNI/Android frontend, packages notices, signs the APK and checks signatures and 16 KiB native-library alignment. Output: `dist/BadN64-Native-Android16.apk`, with verification reports alongside it. This is the supported build entry point. The Gradle files are secondary metadata; Gradle alone requires a separately built core and a matching `PARALLEL_CORE_LIBRARY` CMake path.

An existing SDK/NDK can be selected through `ANDROID_SDK_ROOT`/`ANDROID_HOME` and `ANDROID_NDK_HOME`/`ANDROID_NDK_ROOT`. Otherwise the build installs API 36/build tools 36.0.0 and NDK 28.2.13676358 into `toolchain/`. `BADN64_TOOLCHAIN` selects another download cache; `BADN64_JOBS` sets build parallelism.

The first build creates `signing/badn64-development.keystore`. Keep this private key to sign future app updates. It is omitted from source archives. The development identity is intended for this experimental APK.

The repository's GitHub Actions workflow builds directly from `main`, retains the signing key in an Actions cache and uploads the APK, diagnostics and corresponding source. It accepts either the complete source tree or `BadN64-source.zip` at the repository root. For ZIP uploads, also add the supplied workflow as `.github/workflows/android-build.yml`. Download the APK artifact from a successful build run.

## Source packages and notices

```sh
python3 tools/package-source.py
```

This writes deterministic `dist/BadN64-source.zip` with a top-level `BadN64/` directory and a SHA-256 sidecar. Build output, APKs, signing material, caches, test reports and Git metadata are excluded. A verified complete pinned core checkout is included when present. An absent or partial vendor directory is omitted; that archive contains the pinned fetch/build recipe and requires downloading the core before building. The packager reports which type it created.

ParaLLEl N64 includes Mupen64Plus GPLv2 code and components under additional licenses. Upstream copyright headers remain in the complete source. The APK's About menu includes `Parallel-N64.txt`, cxd4's CC0 text, other upstream notices and this project's provenance. Distribute complete corresponding source with a binary build. See `app/src/main/assets/licenses/THIRD_PARTY_NOTICES.txt` and `PROVENANCE.md`.
