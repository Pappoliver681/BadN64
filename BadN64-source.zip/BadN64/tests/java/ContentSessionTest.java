package com.badn64.app;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Offline regression scenarios for the real ContentSession generation helper.
 * The adapter below models MainActivity's guards with deterministic IO, UI and
 * timer queues; this harness does not execute Android Activity or JNI code.
 */
public final class ContentSessionTest {
    private static int passed;

    public static void main(String[] args) {
        checkCase("queued A is superseded by B", ContentSessionTest::queuedLoad);
        checkCase("native A completion cannot update B's UI", ContentSessionTest::staleLoadCompletion);
        checkCase("old ZIP selection cannot reopen A", ContentSessionTest::staleZipSelection);
        checkCase("old Close completion cannot clear B", ContentSessionTest::staleCloseCompletion);
        checkCase("stale status still schedules the next poll", ContentSessionTest::staleStatus);
        checkCase("old import picker and queued import are ignored", ContentSessionTest::staleImport);
        checkCase("old export extraction and picker are ignored", ContentSessionTest::staleExport);
        checkCase("destruction cancels queued and late work", ContentSessionTest::destruction);
        checkCase("replacement resets an in-flight quick blast", ContentSessionTest::quickBlastReset);
        System.out.println("Passed " + passed + " ContentSession queue scenarios (no Android Activity/JNI execution).");
    }

    private static void queuedLoad() {
        Adapter a = new Adapter();
        long first = a.open("A");
        long second = a.open("B");
        require(second > first, "Open must create a newer generation");
        a.drain();
        equal(List.of("load B"), a.nativeEvents, "A must not reach the native loader");
        equal("B", a.visibleGame, "Only B should become visible");
        equal(List.of("B"), a.recents, "Only current success should update recents");
    }

    private static void staleLoadCompletion() {
        Adapter a = new Adapter();
        a.open("A");
        a.runIo(); // A has loaded, but its UI completion is still queued.
        equal("A", a.nativeGame, "A should have completed its native load");
        a.open("B");
        a.runUi();
        equal("", a.visibleGame, "A's stale completion must not apply");
        require(a.changing, "A must not clear B's pending-content state");
        equal(List.of(), a.recents, "A's stale completion must not enter recents");
        a.drain();
        equal("B", a.visibleGame, "B's current completion should apply");
    }

    private static void staleZipSelection() {
        Adapter a = new Adapter();
        a.openZip("A");
        a.drain();
        Runnable oldSelection = a.zipSelection;
        require(oldSelection != null, "ZIP read must present an entry selection");
        a.open("B");
        a.drain();
        oldSelection.run();
        a.drain();
        equal(List.of("load B"), a.nativeEvents, "Stale ZIP selection must not queue A");
        equal("B", a.visibleGame, "Old ZIP must not replace B");

        Adapter pendingChooser = new Adapter();
        pendingChooser.openZip("A");
        pendingChooser.runIo();
        pendingChooser.open("B");
        pendingChooser.drain();
        require(pendingChooser.zipSelection == null, "Stale ZIP UI callback must not show a chooser");
    }

    private static void staleCloseCompletion() {
        Adapter a = loaded("A");
        a.close();
        a.runIo(); // Close has finished natively; its UI callback is held.
        a.open("B");
        a.runIo(); // B has also finished natively before Close's callback runs.
        a.runUi();
        equal("A", a.visibleGame, "Old Close must not clear current UI state");
        require(a.changing, "Old Close must not end B's pending-content state");
        a.runUi();
        equal("B", a.visibleGame, "B's completion should remain effective");
    }

    private static void staleStatus() {
        Adapter a = loaded("A");
        a.requestStatus();
        a.runIo(); // Snapshot A, then hold its UI callback.
        a.open("B");
        a.runIo();
        a.runUi();
        equal(0, a.appliedStatuses, "Old snapshot must be discarded");
        equal(1, a.timers.size(), "Discarding a snapshot must preserve the polling timer");
        a.runUi();
        equal("B", a.visibleGame, "B should finish normally");
        a.runTimer();
        a.runIo();
        a.runUi();
        equal(1, a.appliedStatuses, "The next current snapshot must apply");
        equal("B", a.visibleGame, "The next snapshot must describe B");
        equal(1, a.timers.size(), "Current snapshot must continue periodic polling");
    }

    private static void staleImport() {
        Adapter a = loaded("A");
        a.pickImport("state");
        a.open("B");
        a.returnImport();
        a.drain();
        require(!a.nativeEvents.contains("import state"), "Old picker result must not import into B");

        Adapter queued = loaded("A");
        queued.pickImport("sram");
        queued.returnImport(); // Result accepted for A, IO has not run yet.
        queued.open("B");
        queued.drain();
        require(!queued.nativeEvents.contains("import sram"), "Queued import must recheck its generation");

        Adapter recreated = loaded("B");
        recreated.returnImport();
        equal(List.of("load B"), recreated.nativeEvents, "An unclaimed result must not default to a ROM load");
    }

    private static void staleExport() {
        Adapter a = loaded("A");
        a.export();
        a.runIo(); // Export bytes are ready, but the picker has not launched.
        a.open("B");
        a.drain();
        equal(0, a.exportPickers, "Old export completion must not launch a picker");

        Adapter picker = loaded("A");
        picker.export();
        picker.drain();
        equal(1, picker.exportPickers, "Current export should launch a picker");
        picker.open("B");
        picker.returnExport();
        picker.drain();
        equal(List.of(), picker.writes, "Old picker must not write previous cartridge bytes");

        Adapter queued = loaded("A");
        queued.export();
        queued.drain();
        queued.returnExport(); // Result accepted, but file write is queued.
        queued.open("B");
        queued.drain();
        equal(List.of(), queued.writes, "Queued write must recheck its generation");
    }

    private static void destruction() {
        Adapter queued = new Adapter();
        queued.open("A");
        queued.destroy();
        queued.drain();
        equal(List.of(), queued.nativeEvents, "Destroyed adapter must not start a queued native load");
        equal("", queued.visibleGame, "Destroyed adapter must not update UI state");

        Adapter late = new Adapter();
        late.open("A");
        late.runIo();
        late.destroy();
        late.drain(); // Keep the callback to exercise a late post after callback removal.
        equal("", late.visibleGame, "Late completion after destruction must be ignored");
        equal(List.of(), late.recents, "Late completion must not update recents");
        late.requestStatus();
        equal(0, late.io.size(), "Destroyed adapter must not submit another status request");
    }

    private static void quickBlastReset() {
        Adapter a = loaded("A");
        a.quickBlast();
        a.runIo();
        require(a.quickBlastInFlight, "Blast stays in flight until its UI completion");
        a.open("B");
        require(!a.quickBlastInFlight, "New content request must immediately reset quick blast");
        a.runUi(); // Old blast completion is discarded.
        a.drain();
        require(!a.quickBlastInFlight, "Discarded blast callback must not leave B blocked");
        a.quickBlast();
        a.drain();
        equal(2, a.completedNativeBlasts, "B should accept a new quick blast");
        require(!a.quickBlastInFlight, "Current blast callback should reset the flag");
    }

    private static Adapter loaded(String name) {
        Adapter a = new Adapter();
        a.open(name);
        a.drain();
        return a;
    }

    private static void checkCase(String name, Runnable test) {
        try {
            test.run();
            passed++;
            System.out.println("PASS " + name);
        } catch (AssertionError e) {
            throw new AssertionError(name + ": " + e.getMessage(), e);
        }
    }

    private static void equal(Object expected, Object actual, String message) {
        if (!Objects.equals(expected, actual)) {
            throw new AssertionError(message + " (expected " + expected + ", got " + actual + ")");
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    /** Models the relevant Activity boundary guards, with no Android dependencies. */
    private static final class Adapter {
        final ContentSession session = new ContentSession();
        final ArrayDeque<Runnable> io = new ArrayDeque<>();
        final ArrayDeque<Runnable> ui = new ArrayDeque<>();
        final ArrayDeque<Runnable> timers = new ArrayDeque<>();
        final List<String> nativeEvents = new ArrayList<>();
        final List<String> recents = new ArrayList<>();
        final List<String> writes = new ArrayList<>();
        boolean destroyed, changing, quickBlastInFlight;
        String nativeGame = "", visibleGame = "", pendingImport, pendingExport;
        long importGeneration = -1, exportGeneration = -1;
        int appliedStatuses, exportPickers, completedNativeBlasts;
        Runnable zipSelection;

        boolean current(long generation) {
            return !destroyed && session.isCurrent(generation);
        }

        long begin() {
            long generation = session.begin();
            changing = true;
            quickBlastInFlight = false;
            pendingImport = null;
            importGeneration = -1;
            pendingExport = null;
            exportGeneration = -1;
            return generation;
        }

        long open(String name) {
            long generation = begin();
            io.add(() -> load(name, generation));
            return generation;
        }

        void load(String name, long generation) {
            if (!current(generation)) return;
            nativeEvents.add("load " + name);
            nativeGame = name;
            ui.add(() -> {
                if (!current(generation)) return;
                changing = false;
                visibleGame = name;
                recents.add(name);
            });
        }

        void openZip(String name) {
            long generation = begin();
            io.add(() -> {
                if (!current(generation)) return;
                ui.add(() -> {
                    if (!current(generation)) return;
                    zipSelection = () -> {
                        if (!current(generation)) return;
                        io.add(() -> load(name, generation));
                    };
                });
            });
        }

        void close() {
            long generation = begin();
            io.add(() -> {
                if (!current(generation)) return;
                nativeEvents.add("close");
                nativeGame = "";
                ui.add(() -> {
                    if (!current(generation)) return;
                    changing = false;
                    visibleGame = "";
                });
            });
        }

        void requestStatus() {
            if (destroyed) return;
            long generation = session.current();
            io.add(() -> {
                String snapshot = nativeGame;
                ui.add(() -> {
                    if (destroyed) return;
                    if (session.isCurrent(generation) && !changing) {
                        visibleGame = snapshot;
                        appliedStatuses++;
                    }
                    timers.add(this::requestStatus);
                });
            });
        }

        void pickImport(String kind) {
            pendingImport = kind;
            importGeneration = session.current();
        }

        void returnImport() {
            String kind = pendingImport;
            long generation = importGeneration;
            pendingImport = null;
            importGeneration = -1;
            if (kind == null || !current(generation)) return;
            io.add(() -> {
                if (current(generation)) nativeEvents.add("import " + kind);
            });
        }

        void export() {
            long generation = session.current();
            io.add(() -> {
                if (!current(generation)) return;
                String bytes = nativeGame + "-state";
                ui.add(() -> {
                    if (!current(generation) || changing) return;
                    pendingExport = bytes;
                    exportGeneration = generation;
                    exportPickers++;
                });
            });
        }

        void returnExport() {
            String bytes = pendingExport;
            long generation = exportGeneration;
            pendingExport = null;
            exportGeneration = -1;
            if (bytes == null || !current(generation)) return;
            io.add(() -> {
                if (current(generation)) writes.add(bytes);
            });
        }

        void quickBlast() {
            if (destroyed || changing || quickBlastInFlight) return;
            quickBlastInFlight = true;
            long generation = session.current();
            io.add(() -> {
                if (!current(generation)) return;
                completedNativeBlasts++;
                ui.add(() -> {
                    if (current(generation)) quickBlastInFlight = false;
                });
            });
        }

        void destroy() {
            destroyed = true;
            session.begin();
        }

        void runIo() { runOne(io, "IO"); }
        void runUi() { runOne(ui, "UI"); }
        void runTimer() { runOne(timers, "timer"); }

        void drain() {
            while (!io.isEmpty() || !ui.isEmpty()) {
                if (!io.isEmpty()) runIo();
                if (!ui.isEmpty()) runUi();
            }
        }

        private void runOne(ArrayDeque<Runnable> queue, String label) {
            require(!queue.isEmpty(), "Expected pending " + label + " work");
            queue.remove().run();
        }
    }
}
