/* Header regression for shared CPU state at the libretro frame boundary.
 * Exercise actual struct storage and alias writes, including the stop flag
 * that the interpreter clears before the next frame. No emulator substitute.
 */
#include <stdint.h>
#include <stdio.h>
#include "device/device.h"

struct device g_dev;

/* Capture storage addresses before r4300.h's hi/lo macros are introduced. */
static int* const base_stop = &g_dev.r4300.stop;
static int* const hot_stop = &g_dev.r4300.new_dynarec_hot_state.stop;
static int64_t* const base_regs = g_dev.r4300.regs;
static int64_t* const hot_regs = g_dev.r4300.new_dynarec_hot_state.regs;
static int64_t* const base_hi = &g_dev.r4300.hi;
static int64_t* const hot_hi = &g_dev.r4300.new_dynarec_hot_state.hi;
static int64_t* const base_lo = &g_dev.r4300.lo;
static int64_t* const hot_lo = &g_dev.r4300.new_dynarec_hot_state.lo;

#include "device/r4300/r4300.h"

#ifndef EXPECT_HOT
#error "Choose the CPU storage contract for this build configuration"
#endif

int main(void) {
    int* const active_stop = EXPECT_HOT ? hot_stop : base_stop;
    int64_t* const active_regs = EXPECT_HOT ? hot_regs : base_regs;
    int64_t* const active_hi = EXPECT_HOT ? hot_hi : base_hi;
    int64_t* const active_lo = EXPECT_HOT ? hot_lo : base_lo;
    if (&mupencorestop != active_stop || mupencorereg != active_regs
        || &hi != active_hi || &lo != active_lo) {
        fputs("CPU aliases disagree with the selected CPU storage\n", stderr);
        return 1;
    }
    /* A VI yield sets the alias, then the active CPU clears it to resume.
     * If those fields differ, retro_return's early-out never clears. */
    mupencorestop = 1;
    if (*active_stop != 1) return 2;
    *active_stop = 0;
    if (mupencorestop != 0) return 3;
    mupencorereg[5] = INT64_C(0x123456789abcdef);
    hi = INT64_C(0x1234567887654321);
    lo = INT64_C(0x2345678998765432);
    if (active_regs[5] != INT64_C(0x123456789abcdef)
        || *active_hi != INT64_C(0x1234567887654321)
        || *active_lo != INT64_C(0x2345678998765432)) return 4;
    return 0;
}
