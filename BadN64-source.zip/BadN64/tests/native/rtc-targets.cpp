#include "rtc_engine.h"
#include "rtc_target_ranges.h"
#include <array>
#include <cassert>
#include <iostream>
#include <set>
#include <sstream>

int main() {
    using namespace badn64;
    std::array<uint8_t, 256> memory{};
    memory[16] = 0x08; // Complete 32-byte triangle.
    memory[48] = 0x37; // Fill color.
    memory[56] = 0x36; // Fill rectangle.
    MemoryDomain domain;
    domain.id = "rdram"; domain.size = memory.size(); domain.writable = true;
    domain.read8 = [&](uint32_t address) { return memory.at(address); };
    domain.write8 = [&](uint32_t address, uint8_t value) { memory.at(address) = value; };
    const auto ranges = graphicsTargetRanges(domain, 16, 48);
    assert(ranges.size() == 3);
    assert(ranges[0].start == 24 && ranges[0].end == 47);
    assert(graphicsTargetRanges(domain, 16, 16).empty()); // Incomplete command.
    assert(graphicsTargetRanges(domain, 256, 32).empty());
    const auto before = memory;
    RtcEngine rtc; rtc.setDomains({domain});
    DomainConfig disabled; rtc.setDomainConfig("rdram", disabled);
    rtc.setEngine("ff"); rtc.setIntensity(200); rtc.setManualSeed(true, 17);
    const auto result = rtc.blastTargeted(ranges);
    assert(result.applied && result.writes);
    for (const auto& unit : rtc.history().back().units) {
        bool selected = false;
        for (const auto& range : ranges)
            if (unit.address >= range.start && unit.address <= range.end) selected = true;
        assert(selected && unit.domain == "rdram");
    }
    for (unsigned address = 0; address < memory.size(); ++address) {
        bool selected = false;
        for (const auto& range : ranges)
            if (address >= range.start && address <= range.end) selected = true;
        if (!selected) assert(memory[address] == before[address]);
    }
    assert(memory[16] == 0x08 && memory[48] == 0x37 && memory[56] == 0x36);
    assert(rtc.undoLastBlast().applied && memory == before);
    assert(!rtc.blastTargeted({}).applied);
    assert(!rtc.blastTargeted({{"rdram", 256, 300}}).applied);
    rtc.setEngine("bitflip"); rtc.setIntensity(16);
    rtc.setAutoBlast(true, 10); rtc.setFrame(10);
    const auto audio = audioTargetRanges(domain, 128, 16);
    assert(rtc.blastTargeted(audio, true).applied);
    for (const auto& unit : rtc.history().back().units) {
        assert(unit.address >= 128 && unit.address < 144);
        const auto difference = unit.previous ^ unit.value;
        assert(difference && !(difference & (difference - 1)));
    }
    assert(!rtc.autoDue(19) && rtc.autoDue(20));
    assert(rtc.undoLastBlast().applied && memory == before);
    assert(audioTargetRanges(domain, 250, UINT32_MAX).front().end == 255);
    rtc.setManualSeed(false);
    for (const auto& target : {ranges, audio}) {
        std::set<uint64_t> seeds;
        std::set<std::string> patterns;
        for (unsigned blast = 0; blast < 20; ++blast) {
            rtc.setFrame(100 + blast * 10);
            assert(rtc.blastTargeted(target, true).applied);
            const auto& record = rtc.history().back();
            assert(record.random && record.automatic && seeds.insert(record.seed).second);
            std::ostringstream pattern;
            for (const auto& unit : record.units) {
                bool selected = false;
                for (const auto& range : target)
                    if (unit.address >= range.start && unit.address <= range.end) selected = true;
                assert(selected && unit.domain == "rdram");
                pattern << unit.address << ':' << unsigned(unit.value) << ',';
            }
            patterns.insert(pattern.str());
            assert(rtc.undoLastBlast().applied && memory == before);
        }
        assert(patterns.size() > 1);
    }
    std::cout << "Targeted RTC bounds, opcode preservation, physical-address Undo, Auto Blast scheduling and fresh polygon/audio randomness passed.\n";
}
