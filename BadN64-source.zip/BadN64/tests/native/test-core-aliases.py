#!/usr/bin/env python3
"""Compile the real CPU headers under supported architecture/JIT selections."""
import argparse
import json
import os
from pathlib import Path
import subprocess


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    test = Path(__file__).with_name('core-alias-test.c')
    include = args.source / 'mupen64plus-core/src'
    # These assert the storage contract, independent of the patch expression:
    # pure/cached interpreter -> base; an Ari64 JIT build -> hot state.
    cases = {
        'arm64-interpreter': ['-D__aarch64__', '-DEXPECT_HOT=0'],
        'apple-arm64-interpreter': ['-D__arm64__', '-DEXPECT_HOT=0'],
        'arm64-ari64': ['-D__aarch64__', '-DNEW_DYNAREC=2', '-DEXPECT_HOT=1'],
        'desktop-interpreter': ['-DEXPECT_HOT=0'],
        'desktop-ari64': ['-D_M_X64', '-DNEW_DYNAREC=2', '-DEXPECT_HOT=1'],
    }
    for name, flags in cases.items():
        executable = args.output / name
        subprocess.run([os.environ.get('CC', 'cc'), '-std=c11', '-O2',
                        '-I' + str(include), '-I' + str(include / 'api'),
                        *flags, str(test), '-o', str(executable)], check=True)
        subprocess.run([str(executable)], check=True, timeout=10)
        print(f'CPU state alias regression passed: {name}', flush=True)
    (args.output / 'core-alias-report.json').write_text(json.dumps({
        'status': 'passed', 'cases': list(cases),
        'arm64_machine_code_executed': False,
        'verified': 'Real CPU header state aliases and VI stop/reset contract',
    }, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
