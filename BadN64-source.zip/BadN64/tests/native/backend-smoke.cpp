// Adapter contract smoke test with a deliberately small mock libretro core.
// This validates the frontend; real N64 emulation is verified separately.
#include "../../app/src/main/cpp/native_backend.h"
#include "libretro.h"
#include <array>
#include <cassert>
#include <cstring>
#include <iostream>
#include <thread>
#include <atomic>
#include <unistd.h>
namespace {
retro_environment_t envcb;
retro_input_state_t inputcb;
std::array<uint8_t, 8192> ram{};
std::array<uint8_t, 4096> dmem{};
std::array<uint8_t, 296960> save{};
std::vector<uint8_t> lastRom;
std::atomic<int> runs{0};
std::atomic<int> invalidations{0};
std::atomic<int> serializations{0};
std::atomic<int> stopRequests{0};
std::atomic<int> loads{0};
std::atomic<unsigned> audioMemoryId{0};
std::atomic<bool> serializationFailure{false};
std::atomic<bool> suppressBuffers{false};
std::atomic<bool> blockRun{false}, blockedRunEntered{false};
void (*bufferCallback)(unsigned, unsigned, uint32_t, uint32_t) = nullptr;
bool insideRetroRun = false;
constexpr uint32_t graphicsStart = 128, audioStart = 256, dmemAudioStart = 64;
constexpr uint32_t audioLength = 16;
void logicalFill(std::array<uint8_t, 8192>& memory, uint32_t start, uint32_t length, uint8_t value) {
 for (uint32_t offset=start; offset<start+length; ++offset) memory[offset^3]=value;
}
void successful(const std::string& response) { assert(response.find("\"ok\":true")!=std::string::npos); }
bool variablesUpdated() {
 bool changed=false; assert(envcb(RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE,&changed)); return changed;
}
std::string videoOption() {
 retro_variable mode{"parallel-n64-angrylion-vioverlay",nullptr};
 assert(envcb(RETRO_ENVIRONMENT_GET_VARIABLE,&mode)); assert(mode.value); return mode.value;
}
void runFrames(badn64::NativeBackend& backend, int count) {
 const int before=runs.load();
 successful(backend.command("pause","{\"paused\":false}"));
 const auto deadline=std::chrono::steady_clock::now()+std::chrono::milliseconds(2000+count*20);
 while (runs.load()<before+count && std::chrono::steady_clock::now()<deadline)
  std::this_thread::sleep_for(std::chrono::milliseconds(1));
 successful(backend.command("pause","{\"paused\":true}"));
 assert(runs.load()>=before+count);
}
void runOneFrame(badn64::NativeBackend& backend) { runFrames(backend,1); }
}
extern "C" {
void retro_set_environment(retro_environment_t f) { envcb = f; }
void retro_set_video_refresh(retro_video_refresh_t) {}
void retro_set_audio_sample(retro_audio_sample_t) {}
void retro_set_audio_sample_batch(retro_audio_sample_batch_t) {}
void retro_set_input_poll(retro_input_poll_t) {}
void retro_set_input_state(retro_input_state_t f) { inputcb = f; }
void retro_init() {
 retro_variable cpu{"parallel-n64-cpucore",nullptr}; assert(envcb(RETRO_ENVIRONMENT_GET_VARIABLE,&cpu)); assert(std::string(cpu.value)=="cached_interpreter");
 retro_variable exp{"parallel-n64-disable_expmem",nullptr}; assert(envcb(RETRO_ENVIRONMENT_GET_VARIABLE,&exp)); assert(std::string(exp.value)=="enabled");
}
void retro_deinit() {}
void retro_run() {
 insideRetroRun=true; ram[4]++;
 if (blockRun.load()) {
  blockedRunEntered=true;
  while (blockRun.load()) std::this_thread::sleep_for(std::chrono::milliseconds(1));
 }
 if (bufferCallback && !suppressBuffers.load()) {
  bufferCallback(1,0,graphicsStart,8);
  bufferCallback(2,audioMemoryId.load(),audioMemoryId.load()==0?audioStart:dmemAudioStart,audioLength);
 }
 insideRetroRun=false; ++runs;
}
void retro_rtc_invalidate_code() { assert(!insideRetroRun); ++invalidations; }
void retro_rtc_request_stop() { ++stopRequests; }
void retro_rtc_set_buffer_callback(void (*callback)(unsigned,unsigned,uint32_t,uint32_t)) { bufferCallback=callback; }
void* retro_rtc_get_memory_data(unsigned id) { return id==0 ? ram.data() : id==1 ? dmem.data() : nullptr; }
size_t retro_rtc_get_memory_size(unsigned id) { return id==0 ? ram.size() : id==1 ? dmem.size() : 0; }
bool retro_load_game(const retro_game_info* i) {
 ++loads;
 lastRom.assign((const uint8_t*)i->data,(const uint8_t*)i->data+i->size); ram.fill(0); dmem.fill(0x66); save.fill(0xff);
 logicalFill(ram,graphicsStart,8,0xa5); ram[graphicsStart^3]=0x37;
 logicalFill(ram,audioStart,audioLength,0x5a); return true;
}
void retro_unload_game() {}
void retro_reset() { ram.fill(0); }
void retro_set_controller_port_device(unsigned,unsigned) {}
void retro_get_system_av_info(retro_system_av_info* i) { i->timing.fps=60; i->timing.sample_rate=44100; }
void* retro_get_memory_data(unsigned type) { return type==RETRO_MEMORY_SYSTEM_RAM ? ram.data() : type==RETRO_MEMORY_SAVE_RAM ? save.data() : nullptr; }
size_t retro_get_memory_size(unsigned type) { return type==RETRO_MEMORY_SYSTEM_RAM ? ram.size() : type==RETRO_MEMORY_SAVE_RAM ? save.size() : 0; }
size_t retro_serialize_size() { return ram.size()+dmem.size(); }
bool retro_serialize(void* p,size_t n) { assert(!insideRetroRun); ++serializations; if(serializationFailure) return false; if(n!=retro_serialize_size())return false; std::memcpy(p,ram.data(),ram.size());std::memcpy(static_cast<uint8_t*>(p)+ram.size(),dmem.data(),dmem.size());return true; }
bool retro_unserialize(const void* p,size_t n) { if(n!=retro_serialize_size())return false;std::memcpy(ram.data(),p,ram.size());std::memcpy(dmem.data(),static_cast<const uint8_t*>(p)+ram.size(),dmem.size());return true; }
}
int main(int argc, char** argv) {
 char directory[] = "/tmp/badn64-adapter-test-XXXXXX";
 if (argc < 2) assert(mkdtemp(directory));
 badn64::NativeBackend b(argc > 1 ? argv[1] : directory);
 assert(b.command("pause","{\"paused\":true}").find("true")!=std::string::npos);
 const int emptyCloseStops=stopRequests.load();
 successful(b.command("close","{}")); assert(stopRequests.load()>emptyCloseStops);
 assert(b.status().find("\"videoMode\":\"fast\"")!=std::string::npos);
 assert(videoOption()=="Unfiltered");
 assert(!variablesUpdated());
 std::vector<uint8_t> canonical(4096); canonical[0]=0x80;canonical[1]=0x37;canonical[2]=0x12;canonical[3]=0x40;canonical[8]=0x91;
 assert(b.loadRom(canonical,"demo.z64").empty());
 assert(lastRom==canonical);
 assert(b.status().find("\"rewindSeconds\":0")!=std::string::npos);
 assert(b.command("recover","{}").find("\"ok\":false")!=std::string::npos);
 // VI configuration applies at the next ROM boot, preserving live RDP state.
 successful(b.command("display_config","{\"videoMode\":\"accurate\"}"));
 assert(videoOption()=="Unfiltered"); assert(!variablesUpdated()); assert(!variablesUpdated());
 const auto pendingVideoStatus=b.status();
 assert(pendingVideoStatus.find("\"videoMode\":\"fast\"")!=std::string::npos);
 assert(pendingVideoStatus.find("\"nextVideoMode\":\"accurate\"")!=std::string::npos);
 successful(b.command("display_config","{\"videoMode\":\"accurate\"}")); assert(!variablesUpdated());
 assert(b.command("display_config","{\"videoMode\":\"invalid\"}").find("\"ok\":false")!=std::string::npos);
 assert(videoOption()=="Unfiltered"); assert(!variablesUpdated());
 assert(b.status().find("\"nextVideoMode\":\"accurate\"")!=std::string::npos);
 // Stop is delivered without waiting for the core worker to leave a frame.
 blockRun=true; blockedRunEntered=false;
 successful(b.command("pause","{\"paused\":false}"));
 const auto blockedDeadline=std::chrono::steady_clock::now()+std::chrono::seconds(2);
 while (!blockedRunEntered.load() && std::chrono::steady_clock::now()<blockedDeadline)
  std::this_thread::sleep_for(std::chrono::milliseconds(1));
 assert(blockedRunEntered.load());
 const int directStopBefore=stopRequests.load();
 const auto stopStarted=std::chrono::steady_clock::now(); b.requestStop();
 const auto stopElapsed=std::chrono::steady_clock::now()-stopStarted;
 const int earlyCloseBefore=stopRequests.load();
 auto earlyClose=std::async(std::launch::async,[&] { return b.command("close","{}"); });
 const auto earlyCloseDeadline=std::chrono::steady_clock::now()+std::chrono::seconds(2);
 while (stopRequests.load()==earlyCloseBefore && std::chrono::steady_clock::now()<earlyCloseDeadline)
  std::this_thread::sleep_for(std::chrono::milliseconds(1));
 const bool closeSignaledBeforeWorkerReturned=stopRequests.load()>earlyCloseBefore;
 blockRun=false;
 successful(earlyClose.get());
 successful(b.command("pause","{\"paused\":true}"));
 assert(stopRequests.load()>directStopBefore); assert(stopElapsed<std::chrono::milliseconds(500));
 assert(closeSignaledBeforeWorkerReturned);
 assert(b.loadRom(canonical,"demo.z64").empty()); assert(lastRom==canonical);
 assert(videoOption()=="Filtered"); assert(!variablesUpdated());
 assert(b.status().find("\"videoMode\":\"accurate\"")!=std::string::npos);
 successful(b.command("display_config","{\"videoMode\":\"fast\"}"));
 assert(videoOption()=="Filtered"); assert(!variablesUpdated());
 assert(b.status().find("\"nextVideoMode\":\"fast\"")!=std::string::npos);
 successful(b.command("display_config","{\"videoMode\":\"accurate\"}"));
 auto domain=b.domains(); assert(domain.find("rdram")!=std::string::npos); assert(domain.find("\"id\":\"dmem\"")!=std::string::npos); assert(domain.find("Original ROM (read-only")!=std::string::npos);
 ram[3]=0xab; assert(b.readMemory("rdram",0,1)==std::vector<uint8_t>{0xab});
 dmem[3]=0x6c; assert(b.readMemory("dmem",0,1)==std::vector<uint8_t>{0x6c});
 assert(b.readMemory("rom",8,1)==std::vector<uint8_t>{0x91});
 b.setButtons((1u<<0)|(1u<<13)); b.setStick(80000,-90000);
 assert(inputcb(0,RETRO_DEVICE_JOYPAD,0,RETRO_DEVICE_ID_JOYPAD_MASK)==((1u<<0)|(1u<<13)));
 assert(inputcb(0,RETRO_DEVICE_ANALOG,RETRO_DEVICE_INDEX_ANALOG_LEFT,RETRO_DEVICE_ID_ANALOG_X)==32767);
 assert(inputcb(0,RETRO_DEVICE_ANALOG,RETRO_DEVICE_INDEX_ANALOG_LEFT,RETRO_DEVICE_ID_ANALOG_Y)==-32767);
 assert(inputcb(1,RETRO_DEVICE_ANALOG,0,0)==0);
 save[25]=0x22; auto state=b.exportState(); assert(std::memcmp(state.data(),"BN64001Z",8)==0);
 ram[3]=0xcd;save[25]=0x44;assert(b.importState(state).empty());assert(ram[3]==0xab && save[25]==0x22);
 assert(!b.importData("sram",{1,2,3}).empty());
 auto damaged=state;damaged[0]='G';assert(!b.importState(damaged).empty());
 assert(b.command("rtc_config","{\"engine\":\"zero\",\"intensity\":1,\"domains\":[{\"id\":\"rdram\",\"enabled\":true,\"start\":0,\"end\":0}]}").find("\"ok\":true")!=std::string::npos);
 assert(b.command("blast","{\"quick\":true}").find("\"ok\":true")!=std::string::npos);assert(ram[3]==0);
 assert(b.command("recover","{}").find("\"ok\":true")!=std::string::npos);assert(ram[3]==0xab && save[25]==0x22);
 // Target presets wait for the core's next consumption callback. Only the
 // selected payload may change; the RDP opcode and unrelated PCM stay intact.
 runOneFrame(b); // Flush the earlier explicit RAM blast/restore first.
 auto targetBlast=[&](const char* target,uint32_t first,uint32_t last) {
  successful(b.command("rtc_config",std::string("{\"target\":\"")+target+"\",\"engine\":\"zero\",\"intensity\":1}"));
  const auto before=ram;
  const int invalidationsBefore=invalidations.load();
  const auto historyBefore=b.command("history","{\"includeUnits\":true}");
  const auto response=b.command("blast","{\"quick\":true}"); successful(response);
  assert(response.find("\"pending\":true")!=std::string::npos);
  assert(b.status().find("\"targetPending\":true")!=std::string::npos);
  assert(ram==before);
  assert(b.command("history","{\"includeUnits\":true}")==historyBefore);
  runOneFrame(b);
  assert(b.status().find("\"targetPending\":false")!=std::string::npos);
  size_t changes=0; uint32_t changedAddress=0;
  for (size_t raw=0;raw<ram.size();++raw) {
   if (raw==4 || before[raw]==ram[raw]) continue; // The fake CPU's frame counter.
   const auto logical=raw^3;
   assert(logical>=first && logical<=last); assert(ram[raw]==0); changedAddress=logical; ++changes;
  }
  assert(changes==1);
  assert(ram[graphicsStart^3]==0x37);
  const auto historyAfter=b.command("history","{\"includeUnits\":true}");
  assert(historyAfter!=historyBefore);
  assert(historyAfter.find("\"address\":"+std::to_string(changedAddress)+",")!=std::string::npos);
  runOneFrame(b); // A callback write must flush cached code between frames.
  assert(invalidations.load()>invalidationsBefore);
 };
 targetBlast("graphics",graphicsStart+4,graphicsStart+7);
 targetBlast("audio",audioStart,audioStart+audioLength-1);
 // Targeted Auto Blast captures once before each armed frame, even when
 // General RAM is disabled and its range is elsewhere.
 successful(b.command("rtc_config","{\"target\":\"graphics\",\"engine\":\"ff\",\"intensity\":1,\"auto\":true,\"interval\":1,\"domains\":[{\"id\":\"rdram\",\"enabled\":false,\"start\":0,\"end\":0}]}"));
 const auto autoBefore=ram;
 const int autoSerializationsBefore=serializations.load(), autoRunsBefore=runs.load();
 runOneFrame(b);
 assert(serializations.load()-autoSerializationsBefore==runs.load()-autoRunsBefore);
 assert(b.command("history","{\"includeUnits\":true}").find("\"automatic\":true")!=std::string::npos);
 size_t autoChanges=0;
 for (size_t raw=0;raw<ram.size();++raw) if (raw!=4 && ram[raw]!=autoBefore[raw]) {
  const auto logical=raw^3; assert(logical>=graphicsStart+4 && logical<=graphicsStart+7);
  assert(ram[raw]==0xff); ++autoChanges;
 }
 assert(autoChanges>0); assert(ram[graphicsStart^3]==0x37);
 successful(b.command("rtc_config","{\"auto\":false}"));
 // A missing consumption callback expires after actual emulated frames;
 // waiting neither mutates history nor serializes every idle frame.
 suppressBuffers=true;
 const auto expiryBefore=ram;
 const auto expiryHistory=b.command("history","{\"includeUnits\":true}");
 const int expirySerializationsBefore=serializations.load();
 successful(b.command("blast","{\"quick\":true}"));
 assert(serializations.load()==expirySerializationsBefore+1);
 assert(b.status().find("\"targetPending\":true")!=std::string::npos);
 runFrames(b,180);
 const auto expiredStatus=b.status();
 assert(expiredStatus.find("\"targetPending\":false")!=std::string::npos);
 assert(expiredStatus.find("within 180 frames")!=std::string::npos);
 assert(serializations.load()==expirySerializationsBefore+1);
 assert(b.command("history","{\"includeUnits\":true}")==expiryHistory);
 for (size_t raw=0;raw<ram.size();++raw) if (raw!=4) assert(ram[raw]==expiryBefore[raw]);
 suppressBuffers=false;
 // Audio work can use SP DMEM too; its bytes share RDRAM's logical XOR3 map.
 audioMemoryId=1;
 successful(b.command("rtc_config","{\"target\":\"audio\",\"engine\":\"zero\",\"intensity\":1}"));
 const auto dmemBefore=dmem;
 const auto ramBeforeDmem=ram;
 const auto saveBeforeDmem=save;
 successful(b.command("blast","{}")); assert(dmem==dmemBefore);
 runOneFrame(b);
 size_t dmemChanges=0;
 for (size_t raw=0;raw<dmem.size();++raw) if (dmem[raw]!=dmemBefore[raw]) {
  const auto logical=raw^3; assert(logical>=dmemAudioStart && logical<dmemAudioStart+audioLength);
  assert(dmem[raw]==0); ++dmemChanges;
 }
 assert(dmemChanges==1); audioMemoryId=0;
 successful(b.command("rtc_config","{\"target\":\"ram\"}"));
 const int replacementStops=stopRequests.load();
 auto swapped=canonical;for(size_t n=0;n<swapped.size();n++)swapped[n]=canonical[n^3];assert(b.loadRom(swapped,"demo.n64").empty());assert(lastRom==canonical);
 assert(stopRequests.load()>replacementStops);
 swapped=canonical;for(size_t n=0;n<swapped.size();n++)swapped[n]=canonical[n^1];assert(b.loadRom(swapped,"demo.v64").empty());assert(lastRom==canonical);
 const int invalidRomStops=stopRequests.load();
 assert(!b.loadRom(std::vector<uint8_t>(4096),"bad.z64").empty()); assert(stopRequests.load()==invalidRomStops);
 successful(b.command("rewind_config","{\"seconds\":15,\"intervalFrames\":1}"));
 serializationFailure=true;b.command("pause","{\"paused\":false}");std::this_thread::sleep_for(std::chrono::milliseconds(250));
 assert(b.status().find("\"paused\":true")!=std::string::npos);assert(b.status().find("could not serialize")!=std::string::npos);
 serializationFailure=false;successful(b.command("recover","{}"));
 assert(ram==ramBeforeDmem && dmem==dmemBefore && save==saveBeforeDmem);
 successful(b.command("rtc_config","{\"target\":\"graphics\",\"auto\":false}"));
 successful(b.command("blast","{\"quick\":true}"));
 assert(b.status().find("\"targetPending\":true")!=std::string::npos);
 const int armedCloseStops=stopRequests.load();
 successful(b.command("close","{}")); assert(stopRequests.load()>armedCloseStops);
 const auto closedStatus=b.status();
 assert(closedStatus.find("\"targetPending\":false")!=std::string::npos);
 assert(closedStatus.find("\"loaded\":false")!=std::string::npos);
 // Queued older loads cannot boot after a newer selection has stopped the
 // current guest. Neither Close nor replacement waits on the core worker
 // before setting its cooperative stop latch.
 auto waitForStop=[&](int previous) {
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(2);
  while (stopRequests.load()<=previous && std::chrono::steady_clock::now()<deadline)
   std::this_thread::sleep_for(std::chrono::milliseconds(1));
  assert(stopRequests.load()>previous);
 };
 auto blockFrame=[&] {
  blockRun=true; blockedRunEntered=false;
  successful(b.command("pause","{\"paused\":false}"));
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(2);
  while (!blockedRunEntered.load() && std::chrono::steady_clock::now()<deadline)
   std::this_thread::sleep_for(std::chrono::milliseconds(1));
  assert(blockedRunEntered.load());
 };
 successful(b.command("pause","{\"paused\":true}"));
 assert(b.loadRom(canonical,"Old.z64").empty());
 blockFrame();
 auto supersededRom=canonical; supersededRom[8]=0xa1;
 auto newestRom=canonical; newestRom[8]=0xb2;
 const int supersededStops=stopRequests.load(), loadsBeforeOverlap=loads.load();
 auto supersededLoad=std::async(std::launch::async,[&] { return b.loadRom(supersededRom,"Superseded.z64"); });
 waitForStop(supersededStops);
 const int newestStops=stopRequests.load();
 auto newestLoad=std::async(std::launch::async,[&] { return b.loadRom(newestRom,"Newest.z64"); });
 waitForStop(newestStops);
 blockRun=false;
 assert(supersededLoad.get().find("canceled")!=std::string::npos);
 assert(newestLoad.get().empty());
 successful(b.command("pause","{\"paused\":true}"));
 assert(lastRom==newestRom && loads.load()==loadsBeforeOverlap+1);
 assert(b.status().find("\"romName\":\"Newest.z64\"")!=std::string::npos);
 // A superseded queued Close must leave a later game selection running.
 blockFrame();
 const int staleCloseStops=stopRequests.load();
 auto staleClose=std::async(std::launch::async,[&] { return b.command("close","{}"); });
 waitForStop(staleCloseStops);
 const int afterCloseStops=stopRequests.load();
 auto afterCloseLoad=std::async(std::launch::async,[&] { return b.loadRom(canonical,"AfterClose.z64"); });
 waitForStop(afterCloseStops);
 blockRun=false;
 successful(staleClose.get()); assert(afterCloseLoad.get().empty());
 successful(b.command("pause","{\"paused\":true}"));
 assert(b.status().find("\"romName\":\"AfterClose.z64\"")!=std::string::npos);
 // If the picker has already stopped the current game, an invalid
 // replacement leaves a closed session. A pending target cannot write
 // source buffers when that stopped frame returns to the frontend.
 successful(b.command("rtc_config","{\"target\":\"graphics\",\"engine\":\"zero\",\"intensity\":1}"));
 successful(b.command("blast","{\"quick\":true}"));
 const auto pendingBeforeStop=ram;
 blockFrame(); b.requestStop(); blockRun=false;
 assert(!b.loadRom(std::vector<uint8_t>(4096),"Invalid-after-stop.z64").empty());
 const auto invalidStatus=b.status();
 assert(invalidStatus.find("\"loaded\":false")!=std::string::npos);
 assert(invalidStatus.find("\"frame\":0")!=std::string::npos);
 assert(invalidStatus.find("\"targetPending\":false")!=std::string::npos);
 assert(b.domains()=="[]" && b.exportData("rom").empty());
 for (uint32_t logical=graphicsStart;logical<graphicsStart+8;++logical)
  assert(ram[logical^3]==pendingBeforeStop[logical^3]);
 std::cout << "{\"adapter_smoke\":true,\"core_emulation_tested\":false}\n";
}
