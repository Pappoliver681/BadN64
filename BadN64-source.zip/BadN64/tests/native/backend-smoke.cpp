// Adapter contract smoke test with a deliberately small mock libretro core.
// This validates the frontend; real N64 emulation is verified separately.
#include "../../app/src/main/cpp/native_backend.h"
#include "libretro.h"
#include <array>
#include <cassert>
#include <cstring>
#include <iostream>
#include <thread>
#include <atomic>
#include <unistd.h>
namespace {
retro_environment_t envcb;
retro_input_state_t inputcb;
std::array<uint8_t, 8192> ram{};
std::array<uint8_t, 296960> save{};
std::vector<uint8_t> lastRom;
std::atomic<int> runs{0};
std::atomic<bool> serializationFailure{false};
}
extern "C" {
void retro_set_environment(retro_environment_t f) { envcb = f; }
void retro_set_video_refresh(retro_video_refresh_t) {}
void retro_set_audio_sample(retro_audio_sample_t) {}
void retro_set_audio_sample_batch(retro_audio_sample_batch_t) {}
void retro_set_input_poll(retro_input_poll_t) {}
void retro_set_input_state(retro_input_state_t f) { inputcb = f; }
void retro_init() {
 retro_variable cpu{"parallel-n64-cpucore",nullptr}; assert(envcb(RETRO_ENVIRONMENT_GET_VARIABLE,&cpu)); assert(std::string(cpu.value)=="pure_interpreter");
 retro_variable exp{"parallel-n64-disable_expmem",nullptr}; assert(envcb(RETRO_ENVIRONMENT_GET_VARIABLE,&exp)); assert(std::string(exp.value)=="enabled");
}
void retro_deinit() {}
void retro_run() { ++runs; ram[4]++; }
bool retro_load_game(const retro_game_info* i) {
 lastRom.assign((const uint8_t*)i->data,(const uint8_t*)i->data+i->size); ram.fill(0); save.fill(0xff); return true;
}
void retro_unload_game() {}
void retro_reset() { ram.fill(0); }
void retro_set_controller_port_device(unsigned,unsigned) {}
void retro_get_system_av_info(retro_system_av_info* i) { i->timing.fps=60; i->timing.sample_rate=44100; }
void* retro_get_memory_data(unsigned type) { return type==RETRO_MEMORY_SYSTEM_RAM ? ram.data() : type==RETRO_MEMORY_SAVE_RAM ? save.data() : nullptr; }
size_t retro_get_memory_size(unsigned type) { return type==RETRO_MEMORY_SYSTEM_RAM ? ram.size() : type==RETRO_MEMORY_SAVE_RAM ? save.size() : 0; }
size_t retro_serialize_size() { return ram.size(); }
bool retro_serialize(void* p,size_t n) { if(serializationFailure) return false; if(n!=ram.size())return false; std::memcpy(p,ram.data(),n);return true; }
bool retro_unserialize(const void* p,size_t n) { if(n!=ram.size())return false;std::memcpy(ram.data(),p,n);return true; }
}
int main(int argc, char** argv) {
 char directory[] = "/tmp/badn64-adapter-test-XXXXXX";
 if (argc < 2) assert(mkdtemp(directory));
 badn64::NativeBackend b(argc > 1 ? argv[1] : directory);
 assert(b.command("pause","{\"paused\":true}").find("true")!=std::string::npos);
 std::vector<uint8_t> canonical(4096); canonical[0]=0x80;canonical[1]=0x37;canonical[2]=0x12;canonical[3]=0x40;canonical[8]=0x91;
 assert(b.loadRom(canonical,"demo.z64").empty());
 assert(lastRom==canonical);
 auto domain=b.domains(); assert(domain.find("rdram")!=std::string::npos); assert(domain.find("Original ROM (read-only")!=std::string::npos);
 ram[3]=0xab; assert(b.readMemory("rdram",0,1)==std::vector<uint8_t>{0xab});
 assert(b.readMemory("rom",8,1)==std::vector<uint8_t>{0x91});
 b.setButtons((1u<<0)|(1u<<13)); b.setStick(80000,-90000);
 assert(inputcb(0,RETRO_DEVICE_JOYPAD,0,RETRO_DEVICE_ID_JOYPAD_MASK)==((1u<<0)|(1u<<13)));
 assert(inputcb(0,RETRO_DEVICE_ANALOG,RETRO_DEVICE_INDEX_ANALOG_LEFT,RETRO_DEVICE_ID_ANALOG_X)==32767);
 assert(inputcb(0,RETRO_DEVICE_ANALOG,RETRO_DEVICE_INDEX_ANALOG_LEFT,RETRO_DEVICE_ID_ANALOG_Y)==-32767);
 assert(inputcb(1,RETRO_DEVICE_ANALOG,0,0)==0);
 save[25]=0x22; auto state=b.exportState(); assert(std::memcmp(state.data(),"BN64001Z",8)==0);
 ram[3]=0xcd;save[25]=0x44;assert(b.importState(state).empty());assert(ram[3]==0xab && save[25]==0x22);
 assert(!b.importData("sram",{1,2,3}).empty());
 auto damaged=state;damaged[0]='G';assert(!b.importState(damaged).empty());
 assert(b.command("rtc_config","{\"engine\":\"zero\",\"intensity\":1,\"domains\":[{\"id\":\"rdram\",\"enabled\":true,\"start\":0,\"end\":0}]}").find("\"ok\":true")!=std::string::npos);
 assert(b.command("blast","{\"quick\":true}").find("\"ok\":true")!=std::string::npos);assert(ram[3]==0);
 assert(b.command("recover","{}").find("\"ok\":true")!=std::string::npos);assert(ram[3]==0xab && save[25]==0x22);
 auto swapped=canonical;for(size_t n=0;n<swapped.size();n++)swapped[n]=canonical[n^3];assert(b.loadRom(swapped,"demo.n64").empty());assert(lastRom==canonical);
 swapped=canonical;for(size_t n=0;n<swapped.size();n++)swapped[n]=canonical[n^1];assert(b.loadRom(swapped,"demo.v64").empty());assert(lastRom==canonical);
 assert(!b.loadRom(std::vector<uint8_t>(4096),"bad.z64").empty());
 serializationFailure=true;b.command("pause","{\"paused\":false}");std::this_thread::sleep_for(std::chrono::milliseconds(250));
 assert(b.status().find("\"paused\":true")!=std::string::npos);assert(b.status().find("could not serialize")!=std::string::npos);
 serializationFailure=false;assert(b.command("recover","{}").find("\"ok\":false")!=std::string::npos);
 std::cout << "{\"adapter_smoke\":true,\"core_emulation_tested\":false}\n";
}
