// Real software N64 libretro integration smoke test.
// The pinned InputRDP demo is Unlicense homebrew by Peter Lemon.
#include <libretro.h>
#include <dlfcn.h>
#include <algorithm>
#include <cstdarg>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
std::map<std::string, std::string> options{
    {"parallel-n64-cpucore", "pure_interpreter"},
    {"parallel-n64-gfxplugin", "angrylion"},
    {"parallel-n64-rspplugin", "cxd4"},
    {"parallel-n64-angrylion-multithread", "off"},
    {"parallel-n64-angrylion-sync", "High"},
    {"parallel-n64-disable_expmem", "enabled"},
    {"parallel-n64-alt-map", "enabled"},
    {"parallel-n64-pak1", "memory"},
    {"parallel-n64-pak2", "none"},
    {"parallel-n64-pak3", "none"},
    {"parallel-n64-pak4", "none"},
};
std::string callback_error;
enum retro_pixel_format pixel_format = RETRO_PIXEL_FORMAT_0RGB1555;
unsigned width = 0, height = 0;
std::vector<uint32_t> frame;
size_t frames_presented = 0, video_callbacks = 0, audio_frames = 0;
size_t input_queries = 0, analog_queries = 0;
uint16_t buttons = 0;
bool hardware_requested = false;

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
void log_callback(enum retro_log_level level, const char* format, ...) {
    if (level < RETRO_LOG_WARN) return;
    va_list args;
    va_start(args, format);
    std::vfprintf(stderr, format, args);
    va_end(args);
}
bool environment(unsigned command, void* data) {
    switch (command) {
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
        static_cast<retro_log_callback*>(data)->log = log_callback;
        return true;
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
        *static_cast<unsigned*>(data) = 0;
        return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES:
        for (auto* variable = static_cast<retro_variable*>(data); variable->key; ++variable) {
            if (!variable->value || options.count(variable->key)) continue;
            std::string description(variable->value);
            auto separator = description.find(';');
            if (separator == std::string::npos) continue;
            auto start = description.find_first_not_of(' ', separator + 1);
            if (start != std::string::npos)
                options[variable->key] = description.substr(start, description.find('|', start) - start);
        }
        return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        auto* variable = static_cast<retro_variable*>(data);
        auto found = options.find(variable->key);
        variable->value = found == options.end() ? nullptr : found->second.c_str();
        return variable->value != nullptr;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *static_cast<bool*>(data) = false;
        return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *static_cast<const char**>(data) = ".";
        return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        pixel_format = *static_cast<retro_pixel_format*>(data);
        return pixel_format == RETRO_PIXEL_FORMAT_XRGB8888;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        *static_cast<bool*>(data) = true;
        return true;
    case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
        *static_cast<int*>(data) = 3;
        return true;
    case RETRO_ENVIRONMENT_SET_HW_RENDER:
        hardware_requested = true;
        return false;
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
    case RETRO_ENVIRONMENT_SET_GEOMETRY:
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
        return true;
    default:
        return false;
    }
}
void video(const void* data, unsigned w, unsigned h, size_t pitch) {
    ++video_callbacks;
    if (!data) return;
    if (data == RETRO_HW_FRAME_BUFFER_VALID || pixel_format != RETRO_PIXEL_FORMAT_XRGB8888
        || w == 0 || h == 0 || w > 4096 || h > 4096 || pitch < size_t(w) * 4) {
        callback_error = "Core supplied an invalid software framebuffer";
        return;
    }
    width = w;
    height = h;
    frame.resize(size_t(w) * h);
    for (unsigned row = 0; row < h; ++row)
        std::memcpy(frame.data() + size_t(row) * w,
                    static_cast<const uint8_t*>(data) + size_t(row) * pitch, size_t(w) * 4);
    ++frames_presented;
}
void audio_sample(int16_t, int16_t) { ++audio_frames; }
size_t audio_batch(const int16_t* data, size_t count) {
    if (count && !data) callback_error = "Core supplied a null PCM buffer";
    audio_frames += count;
    return count;
}
void input_poll() {}
int16_t input(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (port != 0) return 0;
    if (device == RETRO_DEVICE_JOYPAD) {
        ++input_queries;
        if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return static_cast<int16_t>(buttons);
        return id < 16 && (buttons & (1u << id)) ? 1 : 0;
    }
    if (device == RETRO_DEVICE_ANALOG && index == RETRO_DEVICE_INDEX_ANALOG_LEFT) {
        ++analog_queries;
        if (!buttons) return 0;
        return id == RETRO_DEVICE_ID_ANALOG_X ? 16384 : -8192;
    }
    return 0;
}
double red_position() {
    uint64_t sum = 0, pixels = 0;
    for (size_t i = 0; i < frame.size(); ++i) {
        uint32_t color = frame[i];
        if (((color >> 16) & 255) > 180 && ((color >> 8) & 255) < 80 && (color & 255) < 80) {
            sum += i % width;
            ++pixels;
        }
    }
    require(pixels > 16, "Homebrew red rectangle was not rendered");
    return double(sum) / double(pixels);
}
template<typename Function> Function symbol(void* library, const char* name) {
    auto result = reinterpret_cast<Function>(dlsym(library, name));
    require(result != nullptr, name);
    return result;
}
}

int main(int argc, char** argv) {
    if (argc != 4) {
        std::cerr << "Usage: core-smoke CORE_SO INPUT_RDP_ROM REPORT_JSON\n";
        return 2;
    }
    try {
        void* library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
        if (!library) throw std::runtime_error(dlerror());
        auto init = symbol<decltype(&retro_init)>(library, "retro_init");
        auto deinit = symbol<decltype(&retro_deinit)>(library, "retro_deinit");
        auto load = symbol<decltype(&retro_load_game)>(library, "retro_load_game");
        auto unload = symbol<decltype(&retro_unload_game)>(library, "retro_unload_game");
        auto run = symbol<decltype(&retro_run)>(library, "retro_run");
        auto memory = symbol<decltype(&retro_get_memory_data)>(library, "retro_get_memory_data");
        auto memory_size = symbol<decltype(&retro_get_memory_size)>(library, "retro_get_memory_size");
        auto state_size = symbol<decltype(&retro_serialize_size)>(library, "retro_serialize_size");
        auto serialize = symbol<decltype(&retro_serialize)>(library, "retro_serialize");
        auto unserialize = symbol<decltype(&retro_unserialize)>(library, "retro_unserialize");
        symbol<decltype(&retro_set_environment)>(library, "retro_set_environment")(environment);
        symbol<decltype(&retro_set_video_refresh)>(library, "retro_set_video_refresh")(video);
        symbol<decltype(&retro_set_audio_sample)>(library, "retro_set_audio_sample")(audio_sample);
        symbol<decltype(&retro_set_audio_sample_batch)>(library, "retro_set_audio_sample_batch")(audio_batch);
        symbol<decltype(&retro_set_input_poll)>(library, "retro_set_input_poll")(input_poll);
        symbol<decltype(&retro_set_input_state)>(library, "retro_set_input_state")(input);
        require(symbol<decltype(&retro_api_version)>(library, "retro_api_version")() == RETRO_API_VERSION,
                "Unexpected libretro API version");
        init();
        std::ifstream rom_file(argv[2], std::ios::binary);
        require(bool(rom_file), "Unable to open homebrew ROM");
        std::vector<uint8_t> rom{std::istreambuf_iterator<char>(rom_file), {}};
        retro_game_info game{argv[2], rom.data(), rom.size(), nullptr};
        require(load(&game), "Real core rejected the pinned homebrew ROM");
        for (unsigned i = 0; i < 60; ++i) run();
        require(callback_error.empty(), callback_error.c_str());
        require(!hardware_requested, "Software-only core requested GPU rendering");
        require(frames_presented > 20, "Real core did not present software frames");
        require(memory_size(RETRO_MEMORY_SYSTEM_RAM) == 0x800000, "RDRAM size is not 8 MiB");
        auto* ram = static_cast<uint8_t*>(memory(RETRO_MEMORY_SYSTEM_RAM));
        require(ram != nullptr, "Real core has no live RDRAM pointer");
        require(memory_size(RETRO_MEMORY_SAVE_RAM) == 0x48800, "Unexpected native save-memory layout");
        auto* saves = static_cast<uint8_t*>(memory(RETRO_MEMORY_SAVE_RAM));
        require(saves != nullptr, "Real core has no save-memory pointer");
        double before = red_position();
        std::vector<uint8_t> baseline(ram, ram + 0x800000);
        std::vector<uint8_t> state(state_size());
        require(!state.empty() && serialize(state.data(), state.size()), "Native serialization failed");
        constexpr size_t sentinel = 0x700000 ^ 3; // N64 byte order on little-endian hosts.
        ram[sentinel] ^= 0x5a;
        require(ram[sentinel] != baseline[sentinel], "Live RDRAM byte corruption failed");
        buttons = (1u << RETRO_DEVICE_ID_JOYPAD_RIGHT) | (1u << RETRO_DEVICE_ID_JOYPAD_B);
        for (unsigned i = 0; i < 12; ++i) run();
        require(ram[sentinel] != baseline[sentinel], "Unused live RDRAM corruption did not persist");
        double after = red_position();
        require(after > before + 1, "Emulated controller input did not move the homebrew rectangle");
        require(input_queries > 0 && analog_queries > 0, "Core did not query digital and analog input");
        buttons = 0;
        require(unserialize(state.data(), state.size()), "Native state restore failed");
        ram = static_cast<uint8_t*>(memory(RETRO_MEMORY_SYSTEM_RAM));
        require(ram && std::memcmp(ram, baseline.data(), baseline.size()) == 0,
                "State restore did not recover the complete live RDRAM image");
        for (unsigned i = 0; i < 3; ++i) run();
        require(callback_error.empty(), callback_error.c_str());
        require(std::abs(red_position() - before) < 2, "Restored homebrew did not resume at the saved position");
        std::ofstream report(argv[3]);
        require(bool(report), "Unable to write core smoke report");
        report << "{\n  \"status\": \"passed\",\n"
               << "  \"core_commit\": \"862071a8b786224905a763e8b15bdcaf75739341\",\n"
               << "  \"homebrew_commit\": \"7085543e4a19d8c539fc9e0a4d2869e788b4ed4b\",\n"
               << "  \"homebrew_license\": \"Unlicense\",\n"
               << "  \"cpu\": \"pure_interpreter\",\n  \"renderer\": \"angrylion\",\n  \"rsp\": \"cxd4\",\n"
               << "  \"rdram_bytes\": 8388608,\n  \"full_rdram_restore_verified\": true,\n"
               << "  \"software_frames\": " << frames_presented << ",\n"
               << "  \"video_callbacks\": " << video_callbacks << ",\n"
               << "  \"audio_sample_frames\": " << audio_frames << ",\n"
               << "  \"audio_gameplay_verified\": false,\n"
               << "  \"controller_movement_verified\": true,\n"
               << "  \"analog_callback_queries\": " << analog_queries << ",\n"
               << "  \"analog_gameplay_verified\": false,\n"
               << "  \"frame_width\": " << width << ",\n  \"frame_height\": " << height << "\n}\n";
        report.close();
        unload();
        deinit();
        dlclose(library);
        std::cout << "Real N64 core smoke passed: software rendering, controller input, live RDRAM corruption, complete RDRAM state restore.\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Real N64 core smoke failed: " << error.what() << '\n';
        return 1;
    }
}
