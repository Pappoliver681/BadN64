#include "rtc_engine.h"

#include <algorithm>
#include <array>
#include <functional>
#include <iostream>
#include <set>
#include <stdexcept>
#include <unordered_map>
#include <vector>

using namespace badn64;

#define CHECK(condition) do { if (!(condition)) throw std::runtime_error(\
    std::string("Check failed at line ") + std::to_string(__LINE__) + ": " + #condition); } while (false)

namespace {
struct MemoryFixture {
    std::array<uint8_t, 68> storage{};
    uint32_t readCount = 0;
    uint32_t writeCount = 0;
    bool swapped = false;
    MemoryFixture() {
        std::fill(storage.begin(), storage.end(), 0x5a);
    }
    MemoryDomain domain(std::string id = "rdram", uint32_t size = 64, bool writable = true) {
        MemoryDomain result;
        result.id = id;
        result.name = id;
        result.base = storage.data() + 2;
        result.size = size;
        result.writable = writable;
        result.bigEndian = swapped;
        result.read8 = [this, size](uint32_t offset) {
            CHECK(offset < size);
            ++readCount;
            return storage[2 + (swapped ? (offset ^ 3U) : offset)];
        };
        result.write8 = [this, size, writable](uint32_t offset, uint8_t value) {
            CHECK(offset < size && writable);
            ++writeCount;
            storage[2 + (swapped ? (offset ^ 3U) : offset)] = value;
        };
        return result;
    }
    std::vector<uint8_t> bytes() const { return {storage.begin(), storage.end()}; }
    void guards() const {
        CHECK(storage[0] == 0x5a && storage[1] == 0x5a);
        CHECK(storage[66] == 0x5a && storage[67] == 0x5a);
    }
};

DomainConfig selected(uint32_t start = 0, uint32_t end = 63) {
    DomainConfig config;
    config.enabled = true;
    config.start = start;
    config.end = end;
    return config;
}

void rangesAndExclusions() {
    MemoryFixture memory;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    auto config = selected(3, 37);
    config.exclusions = {{4, 12}, {8, 15}, {16, 18}, {21, 22}, {25, 35}};
    rtc.setDomainConfig("rdram", config);
    rtc.setManualSeed(true, 12345);
    rtc.setIntensity(4096);
    rtc.setEngine("word16");
    CHECK(rtc.blast().applied);
    const auto& record = rtc.history().back();
    CHECK(record.units.size() == 8192);
    for (size_t i = 0; i < record.units.size(); i += 2) {
        CHECK(record.units[i].address == 36);
        CHECK(record.units[i + 1].address == 37);
    }
    for (uint32_t offset = 0; offset < 64; ++offset)
        if (offset != 36 && offset != 37) CHECK(memory.storage[offset + 2] == 0x5a);
    memory.guards();
    config.exclusions.push_back({36, 37});
    rtc.setDomainConfig("rdram", config);
    const auto before = memory.bytes();
    CHECK(!rtc.blast().applied);
    CHECK(memory.bytes() == before);
}

void byteMutationsAndUndo() {
    const std::vector<std::string> modes = {"bitflip", "random", "add", "sub", "tilt", "zero", "ff"};
    for (const auto& mode : modes) {
        MemoryFixture memory;
        RtcEngine rtc;
        rtc.setDomains({memory.domain()});
        rtc.setDomainConfig("rdram", selected(11, 11));
        rtc.setManualSeed(true, 9988);
        rtc.setIntensity(1);
        CHECK(rtc.setEngine(mode));
        const auto before = memory.bytes();
        const auto result = rtc.blast();
        CHECK(result.applied && result.operations == 1 && result.writes == 1);
        const auto unit = rtc.history().back().units.front();
        CHECK(unit.address == 11 && unit.previous == 0x5a);
        const unsigned changed = unit.previous ^ unit.value;
        if (mode == "bitflip") CHECK(changed && !(changed & (changed - 1)));
        if (mode == "add") CHECK(static_cast<uint8_t>(unit.value - unit.previous) >= 1
                            && static_cast<uint8_t>(unit.value - unit.previous) <= 31);
        if (mode == "sub") CHECK(static_cast<uint8_t>(unit.previous - unit.value) >= 1
                            && static_cast<uint8_t>(unit.previous - unit.value) <= 31);
        if (mode == "tilt") CHECK(std::abs(static_cast<int>(unit.value) - unit.previous) >= 1
                             && std::abs(static_cast<int>(unit.value) - unit.previous) <= 4);
        if (mode == "zero") CHECK(unit.value == 0);
        if (mode == "ff") CHECK(unit.value == 255);
        CHECK(rtc.undoLastBlast().applied);
        CHECK(memory.bytes() == before);
        memory.guards();
    }
}

void overlappingWritesUndoAndReplay() {
    MemoryFixture memory;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected(6, 7));
    rtc.setIntensity(200);
    rtc.setManualSeed(true, 73);
    rtc.setEngine("random");
    const auto clean = memory.bytes();
    CHECK(rtc.blast().applied);
    const auto corrupted = memory.bytes();
    const BlastRecord record = rtc.history().back();
    CHECK(record.units.size() == 200);
    CHECK(rtc.undoLastBlast().applied);
    CHECK(memory.bytes() == clean);
    CHECK(rtc.applyRecorded(record, true).applied);
    CHECK(memory.bytes() == corrupted);
    CHECK(rtc.undoLastBlast().applied && memory.bytes() == clean);
    memory.storage[8] ^= 1;
    const auto mismatched = memory.bytes();
    CHECK(!rtc.applyRecorded(record, true).applied);
    CHECK(memory.bytes() == mismatched);
    BlastRecord invalid = record;
    invalid.units.back().address = 64;
    CHECK(!rtc.applyRecorded(invalid, false).applied);
    CHECK(memory.bytes() == mismatched);
}

void swapPreservesBytes() {
    MemoryFixture memory;
    for (uint8_t i = 0; i < 64; ++i) memory.storage[i + 2] = i;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected());
    rtc.setManualSeed(true, 901);
    rtc.setEngine("swap");
    rtc.setIntensity(500);
    const auto before = memory.bytes();
    CHECK(rtc.blast().applied);
    auto sorted = std::vector<uint8_t>(memory.storage.begin() + 2, memory.storage.begin() + 66);
    std::sort(sorted.begin(), sorted.end());
    for (size_t i = 0; i < sorted.size(); ++i) CHECK(sorted[i] == i);
    CHECK(rtc.history().back().units.size() == 1000);
    CHECK(rtc.undoLastBlast().applied && memory.bytes() == before);
    memory.guards();
}

void nativeBigEndianAndNop() {
    MemoryFixture memory;
    memory.swapped = true;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected(9, 17));
    rtc.setEngine("mips_nop");
    rtc.setIntensity(1);
    CHECK(rtc.blast().applied);
    const BlastRecord nopRecord = rtc.history().back();
    CHECK(nopRecord.operations == 1 && nopRecord.units.size() == 4);
    for (uint32_t byte = 0; byte < 4; ++byte) {
        CHECK(nopRecord.units[byte].address == 12 + byte);
        CHECK(nopRecord.units[byte].value == 0);
        CHECK(memory.storage[2 + ((12 + byte) ^ 3U)] == 0);
    }
    for (size_t i = 0; i < memory.storage.size(); ++i)
        if (i < 14 || i > 17) CHECK(memory.storage[i] == 0x5a);
    CHECK(rtc.undoLastBlast().applied);
    CHECK(rtc.applyRecorded(nopRecord, true).applied);
    CHECK(rtc.undoLastBlast().applied);
    rtc.setDomainConfig("rdram", selected(17, 23));
    rtc.setEngine("word32");
    rtc.setManualSeed(true, 8841);
    CHECK(rtc.blast().applied);
    const auto& units = rtc.history().back().units;
    CHECK(units.size() == 4 && units.front().address == 20);
    for (size_t i = 0; i < units.size(); ++i) {
        CHECK(units[i].address == 20 + i);
        CHECK(memory.storage[2 + ((20 + i) ^ 3U)] == units[i].value);
    }
    CHECK(rtc.undoLastBlast().applied);
    memory.guards();
    MemoryFixture dmem;
    rtc.setDomains({dmem.domain("dmem")});
    rtc.setDomainConfig("dmem", selected());
    rtc.setEngine("mips_nop");
    CHECK(!rtc.blast().applied && dmem.writeCount == 0);
    MemoryFixture nativeWorkRam;
    rtc.setDomains({nativeWorkRam.domain("rdram")});
    rtc.setDomainConfig("rdram", selected(0, 3));
    CHECK(rtc.blast().applied);
    CHECK(std::all_of(nativeWorkRam.storage.begin() + 2, nativeWorkRam.storage.begin() + 6,
                     [](uint8_t value) { return value == 0; }));
    CHECK(rtc.undoLastBlast().applied);
    // An instruction must fit entirely inside the selection and exclusions.
    auto incomplete = selected(1, 6);
    rtc.setDomainConfig("rdram", incomplete);
    const auto before = nativeWorkRam.bytes();
    CHECK(!rtc.blast().applied && nativeWorkRam.bytes() == before);
    incomplete = selected(1, 11);
    incomplete.exclusions = {{6, 6}, {9, 9}};
    rtc.setDomainConfig("rdram", incomplete);
    CHECK(!rtc.blast().applied && nativeWorkRam.bytes() == before);
    nativeWorkRam.guards();
}

void freshRandomAndManualReproduction() {
    MemoryFixture memory;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected());
    rtc.setEngine("random");
    rtc.setIntensity(64);
    std::set<uint64_t> seeds;
    std::set<std::vector<uint8_t>> patterns;
    for (unsigned i = 0; i < 32; ++i) {
        CHECK(rtc.blast().applied);
        CHECK(rtc.history().back().random);
        CHECK(seeds.insert(rtc.history().back().seed).second);
        CHECK(patterns.insert(memory.bytes()).second);
        CHECK(rtc.undoLastBlast().applied);
    }
    rtc.setManualSeed(true, 1234567890);
    CHECK(rtc.blast().applied);
    const auto first = rtc.history().back();
    const auto output = memory.bytes();
    CHECK(!first.random && first.seed == 1234567890);
    CHECK(rtc.undoLastBlast().applied);
    CHECK(rtc.blast().applied && memory.bytes() == output);
    const auto second = rtc.history().back();
    CHECK(first.units.size() == second.units.size());
    for (size_t i = 0; i < first.units.size(); ++i)
        CHECK(first.units[i].address == second.units[i].address
            && first.units[i].value == second.units[i].value);
}

void autoUsesEmulatedFrames() {
    MemoryFixture memory;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected());
    rtc.setAutoBlast(true, 4);
    CHECK(!rtc.onEmulatedFrame(1).applied);
    CHECK(!rtc.onEmulatedFrame(2).applied);
    CHECK(!rtc.onEmulatedFrame(3).applied);
    CHECK(rtc.onEmulatedFrame(4).applied);
    const uint64_t seed = rtc.history().back().seed;
    CHECK(rtc.history().back().automatic && rtc.history().back().frame == 4);
    for (unsigned displayTicks = 0; displayTicks < 120; ++displayTicks)
        CHECK(!rtc.onEmulatedFrame(4).applied);
    CHECK(rtc.history().size() == 1);
    CHECK(!rtc.onEmulatedFrame(7).applied);
    CHECK(rtc.onEmulatedFrame(8).applied);
    CHECK(rtc.history().back().seed != seed && rtc.history().back().automatic);
    rtc.setAutoBlast(false, 4);
    CHECK(!rtc.onEmulatedFrame(500).applied && rtc.history().size() == 2);
}

void rewindRestoresUndoTimelineAndSession() {
    MemoryFixture memory;
    RtcEngine rtc;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected(8, 8));
    rtc.setEngine("add");
    rtc.setIntensity(1);
    const auto initial = memory.bytes();
    const auto initialTimeline = rtc.checkpoint();
    rtc.setFrame(10);
    CHECK(rtc.blast().applied);
    const auto blasted = memory.bytes();
    const auto afterBlast = rtc.checkpoint();
    CHECK(rtc.undoLastBlast().applied && memory.bytes() == initial);
    const auto afterUndo = rtc.checkpoint();
    std::copy(blasted.begin(), blasted.end(), memory.storage.begin()); // Core state restore.
    rtc.onRestore(afterBlast);
    CHECK(rtc.history().front().active);
    CHECK(rtc.undoLastBlast().applied && memory.bytes() == initial);
    std::copy(initial.begin(), initial.end(), memory.storage.begin());
    rtc.onRestore(afterUndo);
    CHECK(!rtc.history().front().active && !rtc.undoLastBlast().applied);
    rtc.setFrame(20);
    CHECK(rtc.blast().applied && rtc.history().back().number == 2);
    std::copy(initial.begin(), initial.end(), memory.storage.begin());
    rtc.onRestore(initialTimeline);
    CHECK(!rtc.history()[0].active && !rtc.history()[1].active);
    CHECK(!rtc.undoLastBlast().applied);
    CHECK(rtc.blast().applied && rtc.history().back().number == 3);
    rtc.beginSession();
    CHECK(rtc.history().empty());
    CHECK(rtc.blast().applied);
    rtc.onRestore(afterBlast); // Old ROM/session snapshot must not grant Undo.
    CHECK(!rtc.history().front().active && !rtc.undoLastBlast().applied);
}

void domainsRemainSeparateAndReadonlySafe() {
    std::vector<MemoryFixture> memories(7);
    const std::vector<std::string> ids = {"rdram", "dmem", "imem", "sram", "flashram", "eeprom", "rom"};
    RtcEngine rtc;
    std::vector<MemoryDomain> domains;
    for (size_t i = 0; i < ids.size(); ++i) {
        domains.push_back(memories[i].domain(ids[i]));
        rtc.setDomainConfig(ids[i], selected());
    }
    rtc.setDomains(std::move(domains));
    rtc.setEngine("ff");
    rtc.setIntensity(500);
    CHECK(rtc.blast().applied);
    for (const auto& memory : memories) CHECK(memory.writeCount > 0);
    for (const auto& unit : rtc.history().back().units) CHECK(unit.value == 255);
    CHECK(rtc.undoLastBlast().applied);
    for (const auto& memory : memories) {
        CHECK(std::all_of(memory.storage.begin(), memory.storage.end(), [](uint8_t value) { return value == 0x5a; }));
        memory.guards();
    }
    MemoryFixture readOnly;
    rtc.setDomains({readOnly.domain("rdram", 64, false)});
    CHECK(!rtc.blast().applied && readOnly.writeCount == 0);
}

void edgeAddressesAndBoundedHistory() {
    RtcEngine rtc;
    MemoryDomain domain;
    domain.id = "rdram";
    domain.name = "Large address test";
    domain.size = 0xffffffffU;
    std::unordered_map<uint32_t, uint8_t> values;
    domain.read8 = [&](uint32_t offset) { CHECK(offset < domain.size); return values[offset]; };
    domain.write8 = [&](uint32_t offset, uint8_t value) { CHECK(offset < domain.size); values[offset] = value; };
    rtc.setDomains({domain});
    rtc.setDomainConfig("rdram", selected(0xfffffff8U, 0xffffffffU));
    rtc.setEngine("word32");
    rtc.setIntensity(4);
    CHECK(rtc.blast().applied);
    for (const auto& unit : rtc.history().back().units)
        CHECK(unit.address >= 0xfffffff8U && unit.address <= 0xfffffffbU);
    auto config = selected(0xfffffff8U, 0xffffffffU);
    config.exclusions = {{0xfffffff8U, 0xffffffffU}};
    rtc.setDomainConfig("rdram", config);
    CHECK(!rtc.blast().applied);
    MemoryFixture memory;
    rtc.setDomains({memory.domain()});
    rtc.setDomainConfig("rdram", selected(0, 0));
    rtc.setEngine("zero");
    rtc.setIntensity(1);
    for (unsigned i = 0; i < 250; ++i) CHECK(rtc.blast().applied);
    CHECK(rtc.history().size() == 128);
    CHECK(rtc.history().back().number == 251);
    rtc.setDomainConfig("rdram", selected(0, 63));
    rtc.setEngine("word32");
    rtc.setIntensity(4096);
    for (unsigned i = 0; i < 10; ++i) CHECK(rtc.blast().applied);
    size_t totalUnits = 0;
    for (const auto& record : rtc.history()) totalUnits += record.units.size();
    CHECK(totalUnits <= 131072);
}

void serializationAndValidation() {
    MemoryFixture memory;
    RtcEngine rtc;
    auto domain = memory.domain();
    domain.name = "Name with \"quotes\"\n and \\ slash";
    rtc.setDomains({domain});
    const auto json = rtc.domainsJson();
    CHECK(json.find("\\\"quotes\\\"") != std::string::npos);
    CHECK(json.find("\\n") != std::string::npos);
    CHECK(json.find("\\\\ slash") != std::string::npos);
    CHECK(!rtc.setEngine("not-an-engine"));
    CHECK(!rtc.setEngine("nop") && !rtc.setEngine("4e71"));
    CHECK(std::string(mutationEngineId(MutationEngine::MipsNop)) == "mips_nop");
    const std::vector<std::string> nativeUiModes = {"bitflip", "random", "add", "subtract", "tilt", "zero", "ff", "swap", "be16", "be32", "mips_nop"};
    for (const auto& mode : nativeUiModes) CHECK(rtc.setEngine(mode));
    bool rejected = false;
    try { rtc.setDomainConfig("rdram", selected(10, 9)); } catch (const std::invalid_argument&) { rejected = true; }
    CHECK(rejected);
    rejected = false;
    try { rtc.setDomains({domain, domain}); } catch (const std::invalid_argument&) { rejected = true; }
    CHECK(rejected);
    CHECK(rtc.setEngine("random"));
    CHECK(rtc.blast().applied);
    CHECK(rtc.historyJson(true).find("\"previous\":") != std::string::npos);
    CHECK(rtc.recordJson(1).find("\"units\":[") != std::string::npos);
    CHECK(rtc.recordJson(999) == "null");
    CHECK(rtc.configJson().find("\"manualSeed\":false") != std::string::npos);
}

void historyRecordsAcceptedHardwareBits() {
    MemoryFixture memory;
    RtcEngine rtc;
    auto domain = memory.domain("masked_registers");
    domain.write8 = [&](uint32_t offset, uint8_t value) {
        CHECK(offset < 64);
        memory.storage[offset + 2] = value & 0x0e;
    };
    std::fill(memory.storage.begin() + 2, memory.storage.begin() + 66, 0x0a);
    rtc.setDomains({domain});
    rtc.setDomainConfig("masked_registers", selected(2, 2));
    rtc.setEngine("ff");
    rtc.setIntensity(2);
    CHECK(rtc.blast().applied);
    const BlastRecord record = rtc.history().back();
    CHECK(record.units[0].value == 0x0e && record.units[1].previous == 0x0e);
    CHECK(rtc.undoLastBlast().applied && memory.storage[4] == 0x0a);
    CHECK(rtc.applyRecorded(record, true).applied && memory.storage[4] == 0x0e);
}
} // namespace

int main() {
    const std::vector<std::pair<std::string, std::function<void()>>> cases = {
        {"aligned widths respect ranges and overlapping exclusions", rangesAndExclusions},
        {"byte mutation engines modify live memory and Undo restores it", byteMutationsAndUndo},
        {"duplicate writes undo and recorded replay validates before writes", overlappingWritesUndoAndReplay},
        {"swap preserves the exact byte multiset", swapPreservesBytes},
        {"N64 word-swapped adapters receive logical big-endian words and MIPS NOP", nativeBigEndianAndNop},
        {"default randomness is fresh and optional manual seed reproduces", freshRandomAndManualReproduction},
        {"Auto Blast uses emulated frames and independently fresh seeds", autoUsesEmulatedFrames},
        {"rewind restores Undo timeline across Undo, branches and sessions", rewindRestoresUndoTimelineAndSession},
        {"all seven memory domains remain separate and read-only is safe", domainsRemainSeparateAndReadonlySafe},
        {"32-bit boundary arithmetic and history stay bounded", edgeAddressesAndBoundedHistory},
        {"JSON escapes English labels and invalid configurations reject", serializationAndValidation},
        {"history records actual accepted hardware bits for strict replay", historyRecordsAcceptedHardwareBits},
    };
    for (const auto& test : cases) {
        try {
            test.second();
            std::cout << "PASS " << test.first << '\n';
        } catch (const std::exception& error) {
            std::cerr << "FAIL " << test.first << ": " << error.what() << '\n';
            return 1;
        }
    }
    std::cout << cases.size() << " native RTC checks passed.\n";
}
