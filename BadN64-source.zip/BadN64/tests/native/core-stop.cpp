// Actual guest loops that never configure VI and never return a frame.
// The small CPU/RSP programs below are original public-domain test code.
// They reuse the verified Unlicense InputRDP boot image, not a commercial ROM.
#include <libretro.h>
#include <dlfcn.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
std::map<std::string, std::string> options{
    {"parallel-n64-cpucore", "cached_interpreter"},
    {"parallel-n64-gfxplugin", "angrylion"},
    {"parallel-n64-rspplugin", "cxd4"},
    {"parallel-n64-angrylion-multithread", "off"},
    {"parallel-n64-angrylion-sync", "High"},
    {"parallel-n64-disable_expmem", "enabled"},
    {"parallel-n64-alt-map", "enabled"},
};
size_t presented = 0;
size_t red_pixels = 0;
bool hardware_requested = false;

void require(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}
template<class Function> Function symbol(void* library, const char* name) {
    auto function = reinterpret_cast<Function>(dlsym(library, name));
    require(function != nullptr, name);
    return function;
}
bool environment(unsigned command, void* data) {
    switch (command) {
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
        *static_cast<unsigned*>(data) = 0; return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES:
        for (auto* variable = static_cast<retro_variable*>(data); variable->key; ++variable) {
            if (!variable->value || options.count(variable->key)) continue;
            std::string text(variable->value);
            auto separator = text.find(';');
            if (separator == std::string::npos) continue;
            auto start = text.find_first_not_of(' ', separator + 1);
            if (start != std::string::npos)
                options[variable->key] = text.substr(start, text.find('|', start) - start);
        }
        return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        auto* variable = static_cast<retro_variable*>(data);
        auto found = options.find(variable->key);
        variable->value = found == options.end() ? nullptr : found->second.c_str();
        return variable->value != nullptr;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *static_cast<bool*>(data) = false; return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *static_cast<const char**>(data) = "."; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        return *static_cast<retro_pixel_format*>(data) == RETRO_PIXEL_FORMAT_XRGB8888;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        *static_cast<bool*>(data) = true; return true;
    case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
        *static_cast<int*>(data) = 3; return true;
    case RETRO_ENVIRONMENT_SET_HW_RENDER:
        hardware_requested = true; return false;
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
    case RETRO_ENVIRONMENT_SET_GEOMETRY:
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
        return true;
    default: return false;
    }
}
void video(const void* data, unsigned width, unsigned height, size_t pitch) {
    if (!data || data == RETRO_HW_FRAME_BUFFER_VALID) return;
    ++presented;
    red_pixels = 0;
    for (unsigned row = 0; row < height; ++row) {
        const auto* pixels = reinterpret_cast<const uint32_t*>(
            static_cast<const uint8_t*>(data) + size_t(row) * pitch);
        for (unsigned col = 0; col < width; ++col) {
            uint32_t color = pixels[col];
            if (((color >> 16) & 255) > 180 && ((color >> 8) & 255) < 80 && (color & 255) < 80)
                ++red_pixels;
        }
    }
}
void audio_sample(int16_t, int16_t) {}
size_t audio_batch(const int16_t*, size_t frames) { return frames; }
void input_poll() {}
int16_t input(unsigned, unsigned, unsigned, unsigned) { return 0; }

void write_word(std::vector<uint8_t>& image, size_t offset, uint32_t word) {
    for (unsigned i = 0; i < 4; ++i)
        image.at(offset + i) = static_cast<uint8_t>(word >> (24 - 8 * i));
}
void checksum_cic6102(std::vector<uint8_t>& image) {
    // The shell verifies the complete CIC6102 fixture before this derivative
    // is made. Its IPL3 checks these two header words before entering Start.
    require(image.size() >= 0x101000, "Truncated CIC6102 fixture");
    uint32_t t1 = 0xf8ca4ddc, t2 = t1, t3 = t1, t4 = t1, t5 = t1, t6 = t1;
    for (size_t at = 0x1000; at < 0x101000; at += 4) {
        uint32_t word = (uint32_t(image[at]) << 24) | (uint32_t(image[at+1]) << 16)
                      | (uint32_t(image[at+2]) << 8) | image[at+3];
        uint32_t sum = t6 + word;
        if (sum < t6) ++t4;
        t6 = sum;
        t3 ^= word;
        uint32_t shift = word & 31;
        uint32_t rotated = (word << shift) | (word >> ((32 - shift) & 31));
        t5 += rotated;
        t2 ^= t2 > word ? rotated : t6 ^ word;
        t1 += t5 ^ word;
    }
    write_word(image, 0x10, t6 ^ t4 ^ t3);
    write_word(image, 0x14, t5 ^ t2 ^ t1);
}
std::vector<uint8_t> loop_image(const std::vector<uint8_t>& boot, bool rsp) {
    std::vector<uint8_t> image = boot;
    // ROM Start is 0x80001000; the bootloader copies these words into RDRAM.
    // No VI register is written, so neither program can yield at a frame.
    const std::vector<uint32_t> cpu_program{
        0x3c08a070, // lui t0,0xa070       (unused RDRAM marker 0x700000)
        0x3409cafe, // ori t1,zero,0xcafe
        0xad090000, // sw t1,0(t0)
        0x08000403, // j 0x8000100c       (infinite self-loop)
        0x00000000, // nop                (branch delay slot)
    };
    const std::vector<uint32_t> rsp_program{
        0x3c08a400, // lui t0,0xa400       (SP memory)
        0xad000fc0, // sw zero,0xfc0(t0)   (unknown task type: real LLE)
        0x3c093408, 0x35290600, 0xad091000, // IMEM: ori t0,zero,0x600
        0x3c093409, 0x3529b00b, 0xad091004, // IMEM: ori t1,zero,0xb00b
        0x3c09ad09, 0xad091008,             // IMEM: sw t1,0(t0)
        0x3c090800, 0x35290003, 0xad09100c, // IMEM: j 0x0000000c
        0xad001010,                         // IMEM: nop (branch delay)
        0x3c08a408, 0xad000000, // SP_PC = 0
        0x3c08a070, 0x3409beef, 0xad090000, // CPU RDRAM marker 0xbeef
        0x3c08a404, 0x34090005, 0xad090010, // clear SP_STATUS_HALT/BROKE
        0x08000416, 0x00000000, // j 0x80001058; nop (if SP yields)
    };
    const auto& program = rsp ? rsp_program : cpu_program;
    std::fill(image.begin() + 0x1000, image.begin() + 0x2000, 0);
    for (size_t i = 0; i < program.size(); ++i) write_word(image, 0x1000 + i * 4, program[i]);
    const char* name = rsp ? "BADN64 RSP STOP LOOP" : "BADN64 CPU STOP LOOP";
    std::fill(image.begin() + 0x20, image.begin() + 0x34, ' ');
    std::memcpy(image.data() + 0x20, name, std::strlen(name));
    checksum_cic6102(image);
    return image;
}
uint32_t memory_word(const void* data, size_t offset) {
    uint32_t value = 0;
    std::memcpy(&value, static_cast<const uint8_t*>(data) + offset, sizeof(value));
    return value;
}
}

int main(int argc, char** argv) {
    if (argc != 5) {
        std::cerr << "Usage: core-stop CORE_SO INPUT_RDP_ROM REPORT_JSON CPU_MODE\n";
        return 2;
    }
    try {
        const std::string cpu = argv[4];
        require(cpu == "cached_interpreter" || cpu == "pure_interpreter", "Unknown CPU mode");
        options["parallel-n64-cpucore"] = cpu;
        std::ifstream file(argv[2], std::ios::binary);
        std::vector<uint8_t> valid{std::istreambuf_iterator<char>(file), {}};
        require(valid.size() == 1052672, "Expected verified homebrew boot image");
        auto checked = valid;
        checksum_cic6102(checked);
        require(checked == valid, "CIC6102 helper disagrees with original fixture checksum");
        void* library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
        if (!library) throw std::runtime_error(dlerror());
        auto init = symbol<decltype(&retro_init)>(library, "retro_init");
        auto deinit = symbol<decltype(&retro_deinit)>(library, "retro_deinit");
        auto load = symbol<decltype(&retro_load_game)>(library, "retro_load_game");
        auto unload = symbol<decltype(&retro_unload_game)>(library, "retro_unload_game");
        auto run = symbol<decltype(&retro_run)>(library, "retro_run");
        auto memory = symbol<decltype(&retro_get_memory_data)>(library, "retro_get_memory_data");
        auto rtc_memory = symbol<void*(*)(unsigned)>(library, "retro_rtc_get_memory_data");
        auto rtc_size = symbol<size_t(*)(unsigned)>(library, "retro_rtc_get_memory_size");
        auto request_stop = symbol<void(*)()>(library, "retro_rtc_request_stop");
        symbol<decltype(&retro_set_environment)>(library, "retro_set_environment")(environment);
        symbol<decltype(&retro_set_video_refresh)>(library, "retro_set_video_refresh")(video);
        symbol<decltype(&retro_set_audio_sample)>(library, "retro_set_audio_sample")(audio_sample);
        symbol<decltype(&retro_set_audio_sample_batch)>(library, "retro_set_audio_sample_batch")(audio_batch);
        symbol<decltype(&retro_set_input_poll)>(library, "retro_set_input_poll")(input_poll);
        symbol<decltype(&retro_set_input_state)>(library, "retro_set_input_state")(input);
        init();
        double latency_ms[2]{};
        for (unsigned kind = 0; kind < 2; ++kind) {
            const bool rsp = kind == 1;
            auto image = loop_image(valid, rsp);
            const char* path = rsp ? "RSP-no-VI-loop.N64" : "CPU-no-VI-loop.N64";
            retro_game_info game{path, image.data(), image.size(), nullptr};
            require(load(&game), "Core rejected original loop homebrew");
            size_t previous_presented = presented;
            std::atomic<bool> started{false}, returned{false};
            std::thread worker([&] {
                started.store(true, std::memory_order_release);
                run();
                returned.store(true, std::memory_order_release);
            });
            while (!started.load(std::memory_order_acquire)) std::this_thread::yield();
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            if (returned.load(std::memory_order_acquire)) {
                worker.join();
                throw std::runtime_error("Loop fixture returned without a stop request");
            }
            const auto stop_started = std::chrono::steady_clock::now();
            request_stop();
            const auto deadline = stop_started + std::chrono::seconds(2);
            while (!returned.load(std::memory_order_acquire)
                   && std::chrono::steady_clock::now() < deadline)
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            if (!returned.load(std::memory_order_acquire)) {
                std::cerr << "Atomic stop did not release " << (rsp ? "RSP" : "CPU")
                          << " no-VI guest loop within two seconds\n";
                std::_Exit(3); // An actually hung core must not strand CI in join().
            }
            worker.join();
            latency_ms[kind] = std::chrono::duration<double, std::milli>(
                std::chrono::steady_clock::now() - stop_started).count();
            auto* ram = memory(RETRO_MEMORY_SYSTEM_RAM);
            require(ram && memory_word(ram, 0x700000) == (rsp ? 0xbeef : 0xcafe),
                    "Stop happened before the loop program executed");
            if (rsp) {
                void* dmem = rtc_memory(1);
                require(dmem && rtc_size(1) == 0x1000 && memory_word(dmem, 0x600) == 0xb00b,
                        "RSP loop did not execute its own marker instruction");
            }
            require(presented == previous_presented, "No-VI loop unexpectedly presented a frame");
            unload();
            require(rtc_memory(0) == nullptr && rtc_size(0) == 0
                    && rtc_memory(1) == nullptr && rtc_size(1) == 0,
                    "Unloaded core exposed an active memory domain");
            // A stop queued before the next accepted ROM must not poison it.
            request_stop();
            retro_game_info next{argv[2], valid.data(), valid.size(), nullptr};
            require(load(&next), "Valid ROM failed to reload after cancelled guest loop");
            for (unsigned frame = 0; frame < 30; ++frame) run();
            require(presented > previous_presented + 10 && red_pixels > 16,
                    "Fresh ROM did not boot and render after cancelled guest loop");
            require(memory_word(memory(RETRO_MEMORY_SYSTEM_RAM), 0x700000) == 0,
                    "Cancelled guest RDRAM marker survived a fresh ROM boot");
            unload();
        }
        require(!hardware_requested, "Software stop regression requested a GPU context");
        deinit();
        dlclose(library);
        std::ofstream report(argv[3]);
        require(bool(report), "Cannot write stop regression report");
        report << "{\n  \"cpu\": \"" << cpu << "\",\n"
               << "  \"cpu_no_vi_loop_stop_ms\": " << latency_ms[0] << ",\n"
               << "  \"rsp_no_vi_loop_stop_ms\": " << latency_ms[1] << ",\n"
               << "  \"guest_markers_verified\": true,\n"
               << "  \"stopped_before_frame\": true,\n"
               << "  \"fresh_rom_rendered_after_each_stop\": true,\n"
               << "  \"old_rdram_cleared\": true,\n"
               << "  \"preload_stop_cleared\": true\n}\n";
        std::cout << cpu << ": CPU no-VI stop " << latency_ms[0]
                  << " ms, RSP no-VI stop " << latency_ms[1]
                  << " ms; both unload and fresh reload passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Core stop regression failed: " << error.what() << '\n';
        return 1;
    }
}
