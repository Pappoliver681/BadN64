// Production NativeBackend integration against a real headless libretro core.
// This verifies frontend/core scheduling and public state APIs, not Android UI.
#include "native_backend.h"
#include "mini_json.h"
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
#include <zlib.h>

namespace {
using badn64::Json;
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
Json successful(const std::string& text, const std::string& operation) {
    const auto value = Json::parse(text);
    require(value["ok"].flag(), operation + " failed: " + text);
    return value;
}
std::vector<uint8_t> canonicalRom(std::vector<uint8_t> bytes) {
    require(bytes.size() >= 4096 && bytes.size() % 4 == 0, "Invalid ROM fixture size");
    unsigned byteXor = 0;
    if (bytes[0] == 0x37 && bytes[1] == 0x80 && bytes[2] == 0x40 && bytes[3] == 0x12) byteXor = 1;
    else if (bytes[0] == 0x40 && bytes[1] == 0x12 && bytes[2] == 0x37 && bytes[3] == 0x80) byteXor = 3;
    else require(bytes[0] == 0x80 && bytes[1] == 0x37 && bytes[2] == 0x12 && bytes[3] == 0x40, "Invalid ROM fixture header");
    const auto original = bytes;
    for (size_t at = 0; at < bytes.size(); ++at) bytes[at] = original[at ^ byteXor];
    return bytes;
}
std::vector<uint8_t> romOrder(const std::vector<uint8_t>& canonical, unsigned byteXor) {
    auto result = canonical;
    for (size_t at = 0; at < result.size(); ++at) result[at] = canonical[at ^ byteXor];
    return result;
}
void checksumCic6102(std::vector<uint8_t>& rom) {
    require(rom.size() >= 0x101000 && crc32(0, rom.data() + 0x40, 0xfc0) == 0x90bb6cb5,
            "Distinct-color lifecycle fixture requires the known CIC6102 boot code");
    auto word = [&](size_t at) {
        return (uint32_t(rom[at]) << 24) | (uint32_t(rom[at + 1]) << 16) |
               (uint32_t(rom[at + 2]) << 8) | rom[at + 3];
    };
    uint32_t t1 = 0xf8ca4ddc, t2 = t1, t3 = t1, t4 = t1, t5 = t1, t6 = t1;
    for (size_t at = 0x1000; at < 0x101000; at += 4) {
        const auto d = word(at), sum = t6 + d;
        if (sum < t6) ++t4;
        t6 = sum; t3 ^= d;
        const auto shift = d & 31;
        const auto rotated = (d << shift) | (d >> ((32 - shift) & 31));
        t5 += rotated; t2 ^= t2 > d ? rotated : t6 ^ d; t1 += t5 ^ d;
    }
    auto setWord = [&](size_t at, uint32_t value) {
        for (unsigned i = 0; i < 4; ++i) rom[at + i] = value >> (24 - i * 8);
    };
    setWord(0x10, t6 ^ t4 ^ t3); setWord(0x14, t5 ^ t2 ^ t1);
}
void advanceFrames(badn64::NativeBackend& backend, int64_t count) {
    const auto initial = successful(backend.status(), "Before resume")["frame"].integer();
    successful(backend.command("pause", "{\"paused\":false}"), "Resume for lifecycle test");
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    int64_t frame = initial;
    while (frame < initial + count && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        frame = successful(backend.status(), "Lifecycle running status")["frame"].integer();
    }
    require(frame >= initial + count, "Fresh game did not advance its own core frames");
    successful(backend.command("pause", "{\"paused\":true}"), "Pause lifecycle test");
}
size_t coloredPixels(badn64::NativeBackend& backend, bool blue) {
    const auto pixels = backend.exportData("framebuffer");
    require(!pixels.empty() && pixels.size() % 4 == 0, "Fresh game has no software frame");
    size_t count = 0;
    // NativeBackend's presentation buffer contains R,G,B,A byte tuples.
    for (size_t at = 0; at < pixels.size(); at += 4) {
        const auto dominant = pixels[at + (blue ? 2 : 0)];
        const auto other = pixels[at + (blue ? 0 : 2)];
        if (dominant > 180 && other < 80 && pixels[at + 1] < 80) ++count;
    }
    return count;
}
void requireClosed(badn64::NativeBackend& backend) {
    const auto status = successful(backend.status(), "Closed status");
    require(!status["loaded"].flag() && status["frame"].integer() == 0 && status["romName"].text().empty(),
            "Close retained the active game identity or frame clock");
    require(!status["quickStateAvailable"].flag() && status["rewindSnapshots"].integer() == 0,
            "Close retained in-memory game states");
    require(Json::parse(backend.domains()).array.empty() && backend.readMemory("rdram", 0, 16).empty(),
            "Close retained borrowed core memory domains");
    require(backend.exportData("framebuffer").empty() && backend.exportData("rom").empty(),
            "Close retained old display or ROM bytes");
    require(successful(backend.command("history", "{}"), "Closed history")["history"].array.empty(),
            "Close retained RTC history from the previous game");
}
}

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: backend-real ROM OUTPUT_DIRECTORY\n";
        return 2;
    }
    try {
        std::ifstream input(argv[1], std::ios::binary);
        require(bool(input), "Cannot open ROM fixture");
        const auto canonical = canonicalRom(std::vector<uint8_t>(std::istreambuf_iterator<char>{input}, {}));
        const std::string outputDirectory = argv[2];
        badn64::NativeBackend backend(outputDirectory + "/backend-real-app-data");
        successful(backend.command("pause", "{\"paused\":true}"), "Initial pause");
        std::vector<uint8_t> compatibleState;
        const auto started = std::chrono::steady_clock::now();
        for (const auto& format : std::vector<std::pair<std::string, unsigned>>{{"z64", 0}, {"n64", 3}, {"v64", 1}}) {
            std::cout << "Production backend: load/reload " << format.first << std::endl;
            require(backend.loadRom(romOrder(canonical, format.second), "InputRDP." + format.first).empty(), "Production backend could not load " + format.first);
            const auto loaded = successful(backend.status(), "Post-load status");
            require(loaded["loaded"].flag() && loaded["paused"].flag(), "ROM did not load in paused mode");
            require(loaded["cpuCore"].text() == "cached_interpreter" && loaded["videoMode"].text() == "fast" &&
                    loaded["rewindSeconds"].integer() == 0, "Default playback does not use cached CPU, Fast VI and rewind off");
            const auto domains = Json::parse(backend.domains());
            bool rdram = false, save = false, rom = false;
            for (const auto& domain : domains.array) {
                const auto id = domain["id"].text();
                if (id == "rdram") rdram = domain["writable"].flag() && domain["size"].integer() == 8 * 1024 * 1024;
                if (id == "sram") save = domain["writable"].flag() && domain["size"].integer() > 0;
                if (id == "rom") rom = !domain["writable"].flag() && uint64_t(domain["size"].integer()) == canonical.size();
            }
            require(rdram && save && rom, "Production memory domains are incomplete");
            require(backend.exportData("rom") == canonical, "Canonical ROM differs for " + format.first);
            if (!compatibleState.empty())
                require(backend.importState(compatibleState).empty(), "State identity differs between equivalent ROM formats");

            const auto initialFrame = successful(backend.status(), "Paused status")["frame"].integer();
            successful(backend.command("pause", "{\"paused\":false}"), "Resume");
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
            int64_t runningFrame = initialFrame;
            while (runningFrame < initialFrame + 4 && std::chrono::steady_clock::now() < deadline) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                runningFrame = successful(backend.status(), "Running status")["frame"].integer();
            }
            require(runningFrame >= initialFrame + 4, "Production worker did not advance four real core slices");
            successful(backend.command("pause", "{\"paused\":true}"), "Pause after running");
            const auto savedFrame = successful(backend.status(), "Pre-save status")["frame"].integer();
            const auto ramBefore = backend.readMemory("rdram", 0, 64);
            const auto saveBefore = backend.exportData("sram");
            require(ramBefore.size() == 64 && !saveBefore.empty(), "Public memory reads are unavailable");
            const auto state = backend.exportState();
            require(state.size() > 12 && std::equal(state.begin(), state.begin() + 8, "BN64001Z"), "Invalid native state container");
            auto changedSave = saveBefore;
            changedSave.back() ^= 1;
            require(backend.importData("sram", changedSave).empty(), "Could not modify public save memory");
            require(backend.exportData("sram") == changedSave, "Save-memory import was not applied");
            require(backend.importState(state).empty(), "Production native state restore failed");
            require(successful(backend.status(), "Restored status")["frame"].integer() == savedFrame, "Restored frame differs");
            require(backend.readMemory("rdram", 0, 64) == ramBefore, "Restored RDRAM differs");
            require(backend.exportData("sram") == saveBefore, "Restored save memory differs");
            compatibleState = state;
            successful(backend.command("close", "{}"), "Close ROM");
            requireClosed(backend);
        }
        // Equivalent byte orders cannot expose stale CPU/RDP initialization.
        // Change the demo's actual RDP program so the next ROM draws blue.
        const std::vector<uint8_t> redCommand{0x37, 0, 0, 0, 0xff, 0, 0, 0xff};
        auto blueRom = canonical;
        checksumCic6102(blueRom);
        require(blueRom == canonical, "Lifecycle checksum helper disagrees with the original valid fixture");
        const auto command = std::search(blueRom.begin(), blueRom.end(), redCommand.begin(), redCommand.end());
        require(command != blueRom.end(), "InputRDP color-switch fixture command is absent");
        const auto colorAt = size_t(command - blueRom.begin()) + 4;
        require(std::search(command + redCommand.size(), blueRom.end(), redCommand.begin(), redCommand.end()) == blueRom.end(),
                "InputRDP color-switch fixture command is ambiguous");
        blueRom[colorAt] = 0; blueRom[colorAt + 2] = 0xff;
        // The real boot program validates the cartridge CRC before its first
        // VI. A color change must remain a valid independently bootable ROM.
        checksumCic6102(blueRom);
        std::cout << "Production backend: boot red lifecycle fixture" << std::endl;
        require(backend.loadRom(canonical, "InputRDP-Red.z64").empty(), "Cannot boot red lifecycle fixture");
        advanceFrames(backend, 40);
        require(coloredPixels(backend, false) > 16 && coloredPixels(backend, true) == 0, "Red fixture did not draw its own program");
        successful(backend.command("quick_save", "{}"), "Lifecycle quick save");
        successful(backend.command("rtc_config", "{\"target\":\"ram\",\"engine\":\"bitflip\",\"intensity\":1,\"domains\":[{\"id\":\"rdram\",\"enabled\":true,\"start\":8388352,\"end\":8388352}]}"), "Lifecycle RTC setup");
        successful(backend.command("blast", "{\"quick\":true}"), "Lifecycle history fixture");
        require(!successful(backend.command("history", "{}"), "Pre-close history")["history"].array.empty(), "Lifecycle history fixture was not created");
        // Close while play is active, then prove the worker stays unloaded.
        successful(backend.command("pause", "{\"paused\":false}"), "Resume before close");
        successful(backend.command("close", "{}"), "Close active red game");
        requireClosed(backend);
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
        requireClosed(backend);
        successful(backend.command("close", "{}"), "Idempotent close");
        successful(backend.command("pause", "{\"paused\":true}"), "Pause before blue boot");
        std::cout << "Production backend: close red then boot distinct blue ROM" << std::endl;
        require(backend.loadRom(blueRom, "InputRDP-Blue.z64").empty(), "Cannot boot a different ROM after close");
        require(!backend.importState(compatibleState).empty(), "Different ROM accepted the previous game's native state");
        advanceFrames(backend, 40);
        require(coloredPixels(backend, true) > 16 && coloredPixels(backend, false) == 0,
                "Close then load executed the old red ROM instead of the new blue ROM");
        // Replacing an active game uses the same unload/init path as close.
        successful(backend.command("pause", "{\"paused\":false}"), "Resume before direct replacement");
        std::cout << "Production backend: replace active blue ROM with red" << std::endl;
        require(backend.loadRom(canonical, "InputRDP-Red-Replacement.z64").empty(), "Cannot directly replace an active ROM");
        advanceFrames(backend, 40);
        require(coloredPixels(backend, false) > 16 && coloredPixels(backend, true) == 0,
                "Direct ROM replacement continued the previous blue game");
        successful(backend.command("close", "{}"), "Final close");
        requireClosed(backend);
        // VI filtering changes private renderer state, so the option applies
        // on the next boot and is part of the save-state compatibility key.
        successful(backend.command("display_config", "{\"videoMode\":\"accurate\"}"), "Select Accurate for next boot");
        require(backend.loadRom(canonical, "InputRDP-Accurate.z64").empty(), "Cannot boot Accurate video");
        require(successful(backend.status(), "Accurate status")["videoMode"].text() == "accurate", "Accurate option was not applied on boot");
        advanceFrames(backend, 40);
        require(coloredPixels(backend, false) > 16, "Accurate renderer did not draw the game");
        require(backend.importState(compatibleState).find("video mode") != std::string::npos,
                "Accurate session accepted a Fast VI state");
        const auto accurateState = backend.exportState();
        successful(backend.command("display_config", "{\"videoMode\":\"fast\"}"), "Select Fast for next boot");
        const auto pendingMode = successful(backend.status(), "Pending Fast status");
        require(pendingMode["videoMode"].text() == "accurate" && pendingMode["nextVideoMode"].text() == "fast",
                "Changing the next video mode modified the current renderer session");
        require(backend.importState(accurateState).empty(), "Pending mode change invalidated the current session's state");
        successful(backend.command("close", "{}"), "Close Accurate session");
        require(backend.loadRom(canonical, "InputRDP-Fast.z64").empty(), "Cannot return to Fast video");
        require(backend.importState(accurateState).find("video mode") != std::string::npos,
                "Fast session accepted an Accurate VI state");
        require(backend.importState(compatibleState).empty(), "Fast session did not accept its compatible state");
        // File import stops the old guest before reading. Bad replacement
        // input must then leave the native session unloaded and empty.
        backend.requestStop();
        require(!backend.loadRom(std::vector<uint8_t>(4096), "Invalid.z64").empty(), "Invalid replacement was accepted");
        requireClosed(backend);
        const auto elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
        const std::string report = "{\"production_backend_tested\":true,\"real_core_emulation_tested\":true,\"android_runtime_tested\":false,\"rom_formats\":[\"z64\",\"n64\",\"v64\"],\"reload_tested\":true,\"post_load_commands_tested\":true,\"pause_resume_tested\":true,\"native_state_restore_tested\":true,\"save_memory_restore_tested\":true,\"active_game_close_tested\":true,\"distinct_rom_graphics_reload_tested\":true,\"active_rom_replacement_tested\":true,\"closed_memory_history_state_cleared\":true,\"fast_vi_default_tested\":true,\"accurate_vi_next_boot_tested\":true,\"vi_state_identity_tested\":true,\"invalid_replacement_after_stop_closes\":true,\"elapsed_seconds\":" + std::to_string(elapsed) + "}\n";
        std::ofstream output(outputDirectory + "/backend-real-report.json");
        require(bool(output << report), "Cannot write production-backend report");
        std::cout << report;
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Production backend regression failed: " << error.what() << std::endl;
        return 1;
    }
}
