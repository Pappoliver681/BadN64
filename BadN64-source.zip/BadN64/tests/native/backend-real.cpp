// Production NativeBackend integration against a real headless libretro core.
// This verifies frontend/core scheduling and public state APIs, not Android UI.
#include "native_backend.h"
#include "mini_json.h"
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
using badn64::Json;
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
Json successful(const std::string& text, const std::string& operation) {
    const auto value = Json::parse(text);
    require(value["ok"].flag(), operation + " failed: " + text);
    return value;
}
std::vector<uint8_t> canonicalRom(std::vector<uint8_t> bytes) {
    require(bytes.size() >= 4096 && bytes.size() % 4 == 0, "Invalid ROM fixture size");
    unsigned byteXor = 0;
    if (bytes[0] == 0x37 && bytes[1] == 0x80 && bytes[2] == 0x40 && bytes[3] == 0x12) byteXor = 1;
    else if (bytes[0] == 0x40 && bytes[1] == 0x12 && bytes[2] == 0x37 && bytes[3] == 0x80) byteXor = 3;
    else require(bytes[0] == 0x80 && bytes[1] == 0x37 && bytes[2] == 0x12 && bytes[3] == 0x40, "Invalid ROM fixture header");
    const auto original = bytes;
    for (size_t at = 0; at < bytes.size(); ++at) bytes[at] = original[at ^ byteXor];
    return bytes;
}
std::vector<uint8_t> romOrder(const std::vector<uint8_t>& canonical, unsigned byteXor) {
    auto result = canonical;
    for (size_t at = 0; at < result.size(); ++at) result[at] = canonical[at ^ byteXor];
    return result;
}
}

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: backend-real ROM OUTPUT_DIRECTORY\n";
        return 2;
    }
    try {
        std::ifstream input(argv[1], std::ios::binary);
        require(bool(input), "Cannot open ROM fixture");
        const auto canonical = canonicalRom(std::vector<uint8_t>(std::istreambuf_iterator<char>{input}, {}));
        const std::string outputDirectory = argv[2];
        badn64::NativeBackend backend(outputDirectory + "/backend-real-app-data");
        successful(backend.command("pause", "{\"paused\":true}"), "Initial pause");
        std::vector<uint8_t> compatibleState;
        const auto started = std::chrono::steady_clock::now();
        for (const auto& format : std::vector<std::pair<std::string, unsigned>>{{"z64", 0}, {"n64", 3}, {"v64", 1}}) {
            std::cout << "Production backend: load/reload " << format.first << std::endl;
            require(backend.loadRom(romOrder(canonical, format.second), "InputRDP." + format.first).empty(), "Production backend could not load " + format.first);
            const auto loaded = successful(backend.status(), "Post-load status");
            require(loaded["loaded"].flag() && loaded["paused"].flag(), "ROM did not load in paused mode");
            const auto domains = Json::parse(backend.domains());
            bool rdram = false, save = false, rom = false;
            for (const auto& domain : domains.array) {
                const auto id = domain["id"].text();
                if (id == "rdram") rdram = domain["writable"].flag() && domain["size"].integer() == 8 * 1024 * 1024;
                if (id == "sram") save = domain["writable"].flag() && domain["size"].integer() > 0;
                if (id == "rom") rom = !domain["writable"].flag() && uint64_t(domain["size"].integer()) == canonical.size();
            }
            require(rdram && save && rom, "Production memory domains are incomplete");
            require(backend.exportData("rom") == canonical, "Canonical ROM differs for " + format.first);
            if (!compatibleState.empty())
                require(backend.importState(compatibleState).empty(), "State identity differs between equivalent ROM formats");

            const auto initialFrame = successful(backend.status(), "Paused status")["frame"].integer();
            successful(backend.command("pause", "{\"paused\":false}"), "Resume");
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
            int64_t runningFrame = initialFrame;
            while (runningFrame < initialFrame + 4 && std::chrono::steady_clock::now() < deadline) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                runningFrame = successful(backend.status(), "Running status")["frame"].integer();
            }
            require(runningFrame >= initialFrame + 4, "Production worker did not advance four real core slices");
            successful(backend.command("pause", "{\"paused\":true}"), "Pause after running");
            const auto savedFrame = successful(backend.status(), "Pre-save status")["frame"].integer();
            const auto ramBefore = backend.readMemory("rdram", 0, 64);
            const auto saveBefore = backend.exportData("sram");
            require(ramBefore.size() == 64 && !saveBefore.empty(), "Public memory reads are unavailable");
            const auto state = backend.exportState();
            require(state.size() > 12 && std::equal(state.begin(), state.begin() + 8, "BN64001Z"), "Invalid native state container");
            auto changedSave = saveBefore;
            changedSave.back() ^= 1;
            require(backend.importData("sram", changedSave).empty(), "Could not modify public save memory");
            require(backend.exportData("sram") == changedSave, "Save-memory import was not applied");
            require(backend.importState(state).empty(), "Production native state restore failed");
            require(successful(backend.status(), "Restored status")["frame"].integer() == savedFrame, "Restored frame differs");
            require(backend.readMemory("rdram", 0, 64) == ramBefore, "Restored RDRAM differs");
            require(backend.exportData("sram") == saveBefore, "Restored save memory differs");
            compatibleState = state;
            successful(backend.command("close", "{}"), "Close ROM");
            require(!successful(backend.status(), "Closed status")["loaded"].flag(), "ROM remained loaded after close");
        }
        const auto elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
        const std::string report = "{\"production_backend_tested\":true,\"real_core_emulation_tested\":true,\"android_runtime_tested\":false,\"rom_formats\":[\"z64\",\"n64\",\"v64\"],\"reload_tested\":true,\"post_load_commands_tested\":true,\"pause_resume_tested\":true,\"native_state_restore_tested\":true,\"save_memory_restore_tested\":true,\"elapsed_seconds\":" + std::to_string(elapsed) + "}\n";
        std::ofstream output(outputDirectory + "/backend-real-report.json");
        require(bool(output << report), "Cannot write production-backend report");
        std::cout << report;
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Production backend regression failed: " << error.what() << std::endl;
        return 1;
    }
}
