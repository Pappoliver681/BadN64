// Real RDP geometry and AI sample-buffer mutation checks. No output filters.
#include <libretro.h>
#include "rtc_engine.h"
#include "rtc_target_ranges.h"
#include <dlfcn.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
std::map<std::string, std::string> options{
    {"parallel-n64-cpucore", "cached_interpreter"},
    {"parallel-n64-gfxplugin", "angrylion"},
    {"parallel-n64-rspplugin", "cxd4"},
    {"parallel-n64-angrylion-multithread", "off"},
    {"parallel-n64-angrylion-sync", "High"},
    {"parallel-n64-disable_expmem", "enabled"},
    {"parallel-n64-alt-map", "enabled"},
};
std::vector<uint32_t> pixels;
unsigned width = 0;
uint64_t audioFrames = 0, audioNonzero = 0;
int audioPeak = 0;
uint8_t* rdram = nullptr;
size_t rdramSize = 0;
unsigned mode = 0;
uint64_t graphicsEvents = 0, audioEvents = 0, geometryWrites = 0, pcmWrites = 0;
badn64::RtcEngine rtc;
badn64::MemoryDomain ramDomain;
uint32_t geometryAddress = 0, pcmAddress = 0;
bool journalValid = true;
bool hardwareRequested = false;

void require(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}
template<class F> F symbol(void* core, const char* name) {
    F function = reinterpret_cast<F>(dlsym(core, name));
    require(function != nullptr, name);
    return function;
}
bool environment(unsigned command, void* data) {
    switch (command) {
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
        *static_cast<unsigned*>(data) = 0; return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES:
        for (auto* v = static_cast<retro_variable*>(data); v->key; ++v) {
            if (!v->value || options.count(v->key)) continue;
            std::string text(v->value);
            auto separator = text.find(';');
            if (separator == std::string::npos) continue;
            auto start = text.find_first_not_of(' ', separator + 1);
            if (start != std::string::npos)
                options[v->key] = text.substr(start, text.find('|', start) - start);
        }
        return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        auto* v = static_cast<retro_variable*>(data);
        auto found = options.find(v->key);
        v->value = found == options.end() ? nullptr : found->second.c_str();
        return v->value != nullptr;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *static_cast<bool*>(data) = false; return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *static_cast<const char**>(data) = "."; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        return *static_cast<retro_pixel_format*>(data) == RETRO_PIXEL_FORMAT_XRGB8888;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        *static_cast<bool*>(data) = true; return true;
    case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
        *static_cast<int*>(data) = 3; return true;
    case RETRO_ENVIRONMENT_SET_HW_RENDER:
        hardwareRequested = true; return false;
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
    case RETRO_ENVIRONMENT_SET_GEOMETRY:
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
        return true;
    default: return false;
    }
}
void video(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data || data == RETRO_HW_FRAME_BUFFER_VALID || !w || !h || pitch < w * 4) return;
    width = w; pixels.resize(size_t(w) * h);
    for (unsigned y = 0; y < h; ++y)
        std::memcpy(pixels.data() + size_t(y) * w,
                    static_cast<const uint8_t*>(data) + size_t(y) * pitch, size_t(w) * 4);
}
size_t audio(const int16_t* samples, size_t frames) {
    audioFrames += frames;
    for (size_t i = 0; i < frames * 2; ++i) {
        int value = samples[i];
        if (value) ++audioNonzero;
        audioPeak = std::max(audioPeak, value < 0 ? -value : value);
    }
    return frames;
}
void singleAudio(int16_t l, int16_t r) { int16_t samples[] = {l, r}; audio(samples, 1); }
void poll() {}
int16_t input(unsigned, unsigned, unsigned, unsigned) { return 0; }
uint32_t read32(uint32_t address) {
    uint32_t value = 0;
    for (unsigned i = 0; i < 4; ++i) value = (value << 8) | rdram[(address + i) ^ 3];
    return value;
}
void buffer(unsigned kind, unsigned memoryId, uint32_t start, uint32_t length) {
    if (kind == 1) ++graphicsEvents;
    if (kind == 2) ++audioEvents;
    if (!rdram || memoryId != 0 || start > rdramSize || length > rdramSize - start) return;
    if (mode == 1 && kind == 1 && !geometryWrites) {
        auto ranges = badn64::graphicsTargetRanges(ramDomain, start, length);
        // Isolate the helper's real triangle edge range for this geometry assertion.
        ranges.erase(std::remove_if(ranges.begin(), ranges.end(), [](const auto& range) {
            return range.end - range.start + 1 != 24;
        }), ranges.end());
        if (ranges.empty()) return;
        geometryAddress = ranges.front().start;
        const uint32_t opcodeWord = read32(geometryAddress - 8);
        auto result = rtc.blastTargeted(ranges);
        if (result.applied) {
            geometryWrites = result.writes;
            journalValid &= read32(geometryAddress - 8) == opcodeWord;
            for (const auto& unit : rtc.history().back().units)
                journalValid &= unit.domain == "rdram" && unit.address >= geometryAddress
                    && unit.address < geometryAddress + 24;
        }
    }
    if (mode == 2 && kind == 2 && !pcmWrites && length >= 4) {
        // Production range helper and RTC mutate this real AI source span before copy.
        pcmAddress = start;
        auto result = rtc.blastTargeted(badn64::audioTargetRanges(ramDomain, start, length));
        if (result.applied) {
            pcmWrites = result.writes;
            for (const auto& unit : rtc.history().back().units)
                journalValid &= unit.domain == "rdram" && unit.address >= start
                    && uint64_t(unit.address) < uint64_t(start) + length;
        }
    }
}
uint64_t redPixels() {
    return std::count_if(pixels.begin(), pixels.end(), [](uint32_t color) {
        return ((color >> 16) & 255) > 180 && ((color >> 8) & 255) < 80 && (color & 255) < 80;
    });
}
}

int main(int argc, char** argv) {
    if (argc != 4) { std::cerr << "Usage: target-corruption-real CORE_SO ROM REPORT_JSON\n"; return 2; }
    try {
        void* core = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
        if (!core) throw std::runtime_error(dlerror());
        auto run = symbol<decltype(&retro_run)>(core, "retro_run");
        auto memory = symbol<decltype(&retro_get_memory_data)>(core, "retro_get_memory_data");
        auto size = symbol<decltype(&retro_get_memory_size)>(core, "retro_get_memory_size");
        using BufferCallback = void (*)(unsigned, unsigned, uint32_t, uint32_t);
        using SetBuffer = void (*)(BufferCallback);
        auto setBuffer = reinterpret_cast<SetBuffer>(dlsym(core, "retro_rtc_set_buffer_callback"));
        symbol<decltype(&retro_set_environment)>(core, "retro_set_environment")(environment);
        symbol<decltype(&retro_set_video_refresh)>(core, "retro_set_video_refresh")(video);
        symbol<decltype(&retro_set_audio_sample_batch)>(core, "retro_set_audio_sample_batch")(audio);
        symbol<decltype(&retro_set_audio_sample)>(core, "retro_set_audio_sample")(singleAudio);
        symbol<decltype(&retro_set_input_poll)>(core, "retro_set_input_poll")(poll);
        symbol<decltype(&retro_set_input_state)>(core, "retro_set_input_state")(input);
        symbol<decltype(&retro_init)>(core, "retro_init")();
        std::ifstream file(argv[2], std::ios::binary);
        require(bool(file), "Unable to open original triangle/audio fixture");
        std::vector<uint8_t> rom{std::istreambuf_iterator<char>(file), {}};
        retro_game_info game{argv[2], rom.data(), rom.size(), nullptr};
        require(symbol<decltype(&retro_load_game)>(core, "retro_load_game")(&game), "Fixture rejected");
        if (setBuffer) setBuffer(buffer);
        for (unsigned i = 0; i < 60; ++i) run();
        rdram = static_cast<uint8_t*>(memory(RETRO_MEMORY_SYSTEM_RAM));
        rdramSize = size(RETRO_MEMORY_SYSTEM_RAM);
        require(rdram && rdramSize == 0x800000, "Live RDRAM unavailable");
        ramDomain.id = "rdram"; ramDomain.name = "N64 RDRAM";
        ramDomain.base = rdram; ramDomain.size = static_cast<uint32_t>(rdramSize);
        ramDomain.bigEndian = true;
        ramDomain.read8 = [](uint32_t address) { return rdram[address ^ 3]; };
        ramDomain.write8 = [](uint32_t address, uint8_t value) { rdram[address ^ 3] = value; };
        rtc.setDomains({ramDomain});
        rtc.setEngine("bitflip"); rtc.setIntensity(32); rtc.setManualSeed(true, 1);
        const uint64_t baselineRed = redPixels();
        const int baselineAudioPeak = audioPeak;
        std::cout << "Baseline: red pixels " << baselineRed << ", audio frames " << audioFrames
                  << ", nonzero samples " << audioNonzero << ", peak " << baselineAudioPeak << std::endl;
        require(!hardwareRequested && width && baselineRed > 200, "Fixture did not render a software triangle");
        require(audioNonzero > 100 && baselineAudioPeak == 4096, "Fixture did not emit its real AI square wave");
        require(setBuffer != nullptr, "Missing real-buffer RTC hook export");
        mode = 1;
        for (unsigned i = 0; i < 5; ++i) run();
        uint64_t corruptedRed = redPixels();
        require(geometryWrites == 32 && corruptedRed != baselineRed, "RDP edge mutation did not alter rendered geometry");
        mode = 0;
        require(rtc.undoLastBlast().applied, "RTC geometry undo failed");
        for (unsigned i = 0; i < 5; ++i) run();
        require(redPixels() == baselineRed, "Restoring command RAM did not recover original geometry");
        audioPeak = 0; mode = 2; rtc.setManualSeed(true, 2);
        for (unsigned i = 0; i < 8; ++i) run();
        int corruptedAudioPeak = audioPeak;
        require(pcmWrites == 32 && corruptedAudioPeak > baselineAudioPeak,
                "AI source RAM bit flip did not alter emitted game PCM");
        mode = 0; audioPeak = 0;
        require(rtc.undoLastBlast().applied, "RTC PCM undo failed");
        for (unsigned i = 0; i < 8; ++i) run();
        require(audioPeak == baselineAudioPeak, "Restoring AI source RAM did not recover original PCM");
        require(journalValid, "RTC journal escaped canonical source memory or changed command opcode");
        setBuffer(nullptr);
        std::ofstream report(argv[3]);
        require(bool(report), "Unable to write target corruption report");
        report << "{\n  \"status\": \"passed\",\n  \"cpu\": \"cached_interpreter\",\n"
               << "  \"renderer\": \"angrylion\",\n  \"source_ram_mutations\": true,\n"
               << "  \"post_processing\": false,\n  \"rdp_geometry_verified\": true,\n"
               << "  \"baseline_red_pixels\": " << baselineRed << ",\n"
               << "  \"corrupted_red_pixels\": " << corruptedRed << ",\n"
               << "  \"rdp_edge_payload_address\": " << geometryAddress << ",\n"
               << "  \"rtc_geometry_byte_writes\": " << geometryWrites << ",\n"
               << "  \"graphics_buffer_events\": " << graphicsEvents << ",\n"
               << "  \"ai_pcm_verified\": true,\n  \"baseline_pcm_peak\": " << baselineAudioPeak << ",\n"
               << "  \"corrupted_pcm_peak\": " << corruptedAudioPeak << ",\n"
               << "  \"pcm_source_address\": " << pcmAddress << ",\n"
               << "  \"rtc_pcm_byte_writes\": " << pcmWrites << ",\n"
               << "  \"canonical_journal_and_undo_verified\": true,\n"
               << "  \"audio_buffer_events\": " << audioEvents << "\n}\n";
        symbol<decltype(&retro_unload_game)>(core, "retro_unload_game")();
        symbol<decltype(&retro_deinit)>(core, "retro_deinit")();
        dlclose(core);
        std::cout << "Actual RDP edge and AI PCM memory mutations passed, with RAM restore.\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Target corruption failed: " << error.what() << '\n'; return 1;
    }
}
