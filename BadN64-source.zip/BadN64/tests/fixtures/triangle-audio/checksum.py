#!/usr/bin/env python3
"""Apply the standard CIC N64 cartridge header checksum to an assembled image."""
from pathlib import Path
import struct
import sys
import zlib

rom = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent/'TriangleAudio.N64'
data = bytearray(rom.read_bytes())
boot_crc = zlib.crc32(data[0x40:0x1000])
cic = {0x6170a4a1: 6101, 0x90bb6cb5: 6102, 0x0b050ee0: 6103,
       0x98bc2c86: 6105, 0xacc8580a: 6106}[boot_crc]
seed = {6101: 0xf8ca4ddc, 6102: 0xf8ca4ddc, 6103: 0xa3886759,
        6105: 0xdf26f436, 6106: 0x1fea617a}[cic]
t1 = t2 = t3 = t4 = t5 = t6 = seed
mask = 0xffffffff
for at in range(0x1000, 0x101000, 4):
    d = struct.unpack_from('>I', data, at)[0]
    if ((t6 + d) & mask) < t6:
        t4 = (t4 + 1) & mask
    t6 = (t6 + d) & mask
    t3 ^= d
    shift = d & 31
    r = ((d << shift) | (d >> ((32-shift) & 31))) & mask
    t5 = (t5 + r) & mask
    t2 ^= r if t2 > d else t6 ^ d
    if cic == 6105:
        t1 = (t1 + (struct.unpack_from('>I', data, 0x750 + (at & 255))[0] ^ d)) & mask
    else:
        t1 = (t1 + (t5 ^ d)) & mask
if cic == 6103:
    crc1, crc2 = ((t6 ^ t4) + t3) & mask, ((t5 ^ t2) + t1) & mask
elif cic == 6106:
    crc1, crc2 = ((t6 * t4) + t3) & mask, ((t5 * t2) + t1) & mask
else:
    crc1, crc2 = t6 ^ t4 ^ t3, t5 ^ t2 ^ t1
struct.pack_into('>II', data, 0x10, crc1, crc2)
rom.write_bytes(data)
print(f'CIC {cic}, boot CRC {boot_crc:08x}, header CRC {crc1:08x}/{crc2:08x}')
