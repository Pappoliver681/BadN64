// Original BadN64 regression homebrew, dedicated to the public domain.
// Reuses Peter Lemon's Unlicense hardware definitions and initialization.
arch n64.cpu
endian msb
output "TriangleAudio.N64", create
fill 1052672
origin $00000000
base $80000000
include "../input-rdp/LIB/N64.INC"
db $80,$37,$12,$40
dw $000F,Start,$1444
db "CRC1","CRC2"
dd 0
db "BADN64 TRIANGLE AUDIO      "
db 0,0,0,$45,0
insert "../input-rdp/LIB/N64_BOOTCODE.BIN"

Start:
  include "../input-rdp/LIB/N64_GFX.INC"
  N64_INIT()
  ScreenNTSC(320,240,BPP32,$A0100000)
  lui t7,AI_BASE
  ori t0,r0,1
  sw t0,AI_CONTROL(t7)
  ori t0,r0,1519
  sw t0,AI_DACRATE(t7)
  ori t0,r0,15
  sw t0,AI_BITRATE(t7)

Loop:
  WaitScanline($200)
  DPC(RDPBuffer,RDPBufferEnd)
  lui t7,AI_BASE
  lw t0,AI_STATUS(t7)
  bltz t0,Loop // Bit 31: both AI DMA slots are occupied.
  nop
  ori t0,r0,$2000
  sw t0,AI_DRAM_ADDR(t7)
  ori t0,r0,$1000
  sw t0,AI_LEN(t7)
  j Loop
  nop

align(8)
RDPBuffer:
arch n64.rdp
  Set_Scissor 0,0,0,0,320<<2,240<<2
  Set_Other_Modes CYCLE_TYPE_FILL
  Set_Color_Image IMAGE_DATA_FORMAT_RGBA,SIZE_OF_PIXEL_32B,320-1,$00100000
  Set_Fill_Color $FFFF00FF
  Fill_Rectangle 319<<2,239<<2,0,0
  Set_Fill_Color $FF0000FF
Triangle:
  // A red right triangle: top (80,40), left (80,180), right (240,180).
  Fill_Triangle 0,0,0,180<<2,180<<2,40<<2,80,0,0,0,80,0,1,$2492,80,0,0,0
  Sync_Full
RDPBufferEnd:

origin $2000
PCM:
variable sample = 0
while sample < 1024 {
  if (sample & 31) < 16 {
    dh $1000,$1000
  } else {
    dh $F000,$F000
  }
  sample = sample + 1
}
