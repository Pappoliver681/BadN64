# Triangle and AI audio regression fixture

`TriangleAudio.asm` is original BadN64 diagnostic homebrew, dedicated to the public domain under the included Unlicense. It draws a red triangle with the N64 RDP and submits an actual 16-bit stereo square wave to the N64 Audio Interface. It uses no frontend image or sound effects.

The source reuses the unchanged hardware definitions, graphics macros and boot code from the adjacent `../input-rdp/LIB/` fixture. Those files are from Peter Lemon's public-domain N64 examples at commit `7085543e4a19d8c539fc9e0a4d2869e788b4ed4b`; their exact provenance and original license are preserved in `../input-rdp/PROVENANCE.md` and `../input-rdp/LICENSE`.

The static RDP command list is at logical RDRAM `0x1110–0x1167`. Its 32-byte fill triangle begins at `0x1140`; the major-edge X coordinate is the 16.16 word at `0x1150`. The PCM buffer is logical RDRAM `0x2000–0x2FFF`, with 1,024 stereo sample frames of alternating +4096/-4096 square-wave samples. AI DACRATE is 1519 and the DMA length is 4096 bytes.

The included 1,052,672-byte `TriangleAudio.N64` was assembled locally with ARM9 bass's N64 architecture tables at commit `c3962ec01f4768be1667db0d09c12141c28241f3`, with compatibility for the original examples' legacy constant declarations. The standard CIC6102 checksum was then applied. Tests use the included ROM, so no assembler or network is needed.

To rebuild with a bass assembler supporting those N64 architecture tables and legacy `constant name(value)` declarations, run it from this directory and apply the included checksum program:

```sh
bass TriangleAudio.asm
python3 checksum.py TriangleAudio.N64
```

The test uses the production RTC engine and target-range helpers, with 32 deterministic bit flips into real triangle edge payloads in emulated RDRAM immediately before the RDP consumes its command buffer. It separately applies 32 deterministic bit flips into a real AI source span in emulated RDRAM, immediately before the AI converts it to host PCM. The RTC journal must record canonical RDRAM addresses, preserve command opcodes, and undo both blasts to recover the rendered geometry and original sample peak. This fixture does not test RSP microcode, commercial games, or physical Android audio output.

`SHA256SUMS` records the fixture bytes; shared includes retain the adjacent fixture's checksums.
