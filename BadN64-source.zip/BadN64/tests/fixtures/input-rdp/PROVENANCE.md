# InputRDP integration fixture

Author: krom (Peter Lemon).

Upstream repository: https://github.com/PeterLemon/N64

Pinned commit: `7085543e4a19d8c539fc9e0a4d2869e788b4ed4b`

Original directory: `Input/RDP/`. The original repository's `LICENSE` is included unchanged and dedicates the software to the public domain under the Unlicense.

This fixture draws a red rectangle against a yellow background through the N64 RDP. Its assembly program reads the controller D-pad to move the rectangle. It is a diagnostic homebrew fixture for the real N64 core smoke test, separate from commercial-game compatibility testing.

`InputRDP.N64` is byte-for-byte identical to the binary at the pinned upstream commit. It was reconstructed locally from the original assembly/includes/bootcode using the ARM9 bass assembler and the standard CIC6102 header checksum, then verified against the upstream Git blob hash. Tests use this included binary directly; no assembler or fixture download is required. The assembler and its sources are not included here. Upstream's original `make.bat` documents rebuilding with bass v14 and `chksum64`.

All original source/include/license files below are preserved byte-for-byte. Git blob SHA-1 uses the Git object header `blob <byte-length>\0` followed by the file bytes.

| File | Bytes | Git blob SHA-1 |
| --- | ---: | --- |
| InputRDP.N64 | 1052672 | 7a152859f5326c23307ad785395ae763951f950a |
| InputRDP.asm | 3054 | 7b91eb8d32c178fe4d3bf09a8a6f448e043d1279 |
| make.bat | 40 | a60f5717510b3dcace9c22475d74881768a53afd |
| LIB/N64.INC | 11965 | 3ef9992936376704faa44e7cce7f7e190ea0a299 |
| LIB/N64_GFX.INC | 51685 | 435fe2bea3952d9599437edffc43cda6505cb7fc |
| LIB/N64_HEADER.ASM | 838 | efa1f8bc806bcc316888bd2cb53c7b59aa384460 |
| LIB/N64_INPUT.INC | 1558 | 0ea5658d392cfb2520a287f98919585b7824b612 |
| LIB/N64_BOOTCODE.BIN | 4032 | a53352e1c9fd82eefafce7d6dacc80791d1155de |
| LICENSE | 1211 | fdddb29aa445bf3d6a5d843d6dd77e10a9f99657 |

ROM SHA-256: `7394d852e3620c48c8a5e300fa7e7560d8bc5b0c15da954f4e7f911e4ace11d1`

## Timing correction used by the smoke test

`InputRDP-timing-fixed.N64` is a clearly marked local derivative of this public-domain demo. `InputRDP-timing-fixed.asm` is its complete assembly source, using the unchanged `LIB/` files. `InputRDP-timing-fixed.patch` records the minimal difference from the original: a distinct output filename and SI idle polling before `InitController` and before each `ReadController` call. The polls wait for both SI DMA/IO busy bits to clear before starting another transfer.

The original fixture started controller initialization while the PIF/SI transfer from `N64_INIT` was still busy. The actual pinned core rejected that overlapping transfer with SI status `0x00000003`, so no controller channels were configured. The correction changes the test program's transfer timing and does not modify the emulator.

The corrected fixture passed the strict real-core smoke test with the unmodified pinned core: 75 software-rendered frames, a changed red-rectangle position after controller input, 4,599 digital and 438 analog input queries, byte-for-byte restoration of the full 8 MiB RDRAM and restoration of the saved rendered position. These are homebrew integration checks, not commercial-game or physical-Android verification.

The derivative remains 1,052,672 bytes. Its Git blob SHA-1 is `8dc0cdf6d7f3dbc66bf0424948774a6ef5f64677`; SHA-256 is `3053429905540e7f552e5d587ed30adb6c1a4b63e2f7c3a1551ea880625d8e6f`.

Rebuild with the same bass v14-compatible N64 architecture tables:

```sh
bass InputRDP-timing-fixed.asm
chksum64 InputRDP-timing-fixed.N64
```

The header uses the standard CIC6102 checksum. `SHA256SUMS` records every fixture file except itself, including both ROMs, sources, original license and this provenance record. The original upstream ROM and sources are preserved alongside the derivative.
