package com.badn64.app;

import android.view.Surface;

/** JNI only: the native core owns clocks, memory, video, audio and full states. */
public final class NativeBridge {
    static { System.loadLibrary("badn64"); }
    private NativeBridge() {}
    public static native long create(String filesDir);
    public static native void destroy(long handle);
    public static native void requestStop(long handle);
    public static native String loadRom(long handle, byte[] bytes, String name);
    public static native void attachSurface(long handle, Surface surface);
    public static native void setButtons(long handle, int mask);
    public static native void setStick(long handle, int x, int y);
    public static native String command(long handle, String command, String optionsJson);
    public static native String status(long handle);
    public static native String domains(long handle);
    public static native byte[] exportState(long handle);
    public static native String importState(long handle, byte[] bytes);
    public static native byte[] exportData(long handle, String kind);
    public static native String importData(long handle, String kind, byte[] bytes);
    public static native byte[] readMemory(long handle, String domain, int start, int length);
}
