package com.badn64.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.hardware.input.InputManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.OpenableColumns;
import android.provider.DocumentsContract;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Native Android frontend. No browser, script clock or script emulator is present. */
public final class MainActivity extends Activity implements InputManager.InputDeviceListener {
    private static final int PICK_DOCUMENT=41, EXPORT_DOCUMENT=42, PICK_ROM_FOLDER=43, MAX_DOCUMENT=64*1024*1024;
    private static final String[] DOMAIN_IDS={"rdram","dmem","sram","rom"};
    private static final String[] DOMAIN_NAMES={"RDRAM (8 MiB)","RSP DMEM (4 KiB)","Cartridge saves / controller paks","Cartridge ROM (read-only)"};
    private static final String[] TARGET_IDS={"ram","graphics","audio"};
    private static final String[] TARGET_NAMES={"General RAM","Graphics / polygons","Game audio"};
    private static final String[] ENGINE_IDS={"bitflip","random","add","sub","tilt","zero","ff","swap","word16","word32","mips_nop"};
    private static final String[] ENGINE_NAMES={"Bit Flip","Random Byte","Add","Subtract","Tilt / small +/- changes","Zero","FF","Swap","16-bit big-endian","32-bit big-endian","Advanced: MIPS NOP 00000000"};
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ContentSession contentSession=new ContentSession();
    private final Map<Integer,Set<Integer>> padKeys=new HashMap<>();
    private final Map<Integer,Integer> padAxes=new HashMap<>();
    private final Map<Integer,int[]> padSticks=new HashMap<>();
    private final Map<Integer,Set<Integer>> rewindKeys=new HashMap<>();
    private final Map<Integer,Boolean> rewindAxes=new HashMap<>();
    private final Map<Integer,Set<Integer>> fastForwardKeys=new HashMap<>();
    private final Map<Integer,Boolean> fastForwardAxes=new HashMap<>();
    private final List<MenuPanel> openMenus=new ArrayList<>();
    private SharedPreferences prefs;
    private FrameLayout root;
    private ControlsView controls;
    private SurfaceView surface;
    private TextView harvestStatus;
    private Button menuButton,editDone;
    private InputManager inputManager;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private Vibrator vibrator;
    private OnBackInvokedCallback backCallback;
    private long engine;
    private volatile boolean destroyed;
    private boolean resumed,hasAudioFocus=true,engineReady,loaded,editingControls;
    private volatile boolean contentChanging;
    private int dialogs,touchMask,sentMask,touchStickX,touchStickY,sentStickX,sentStickY;
    private boolean touchRewind,sentRewind,touchFastForward,sentFastForward,quickBlastInFlight,closingMenus;
    private int activeStateSlot;
    private final List<Uri> libraryPath=new ArrayList<>();
    private MenuPanel libraryMenu,contentSourcesMenu,systemActionsMenu;
    private int libraryGeneration;
    private static final class LibraryEntry {
        final Uri uri; final String name; final boolean directory;
        LibraryEntry(Uri uri,String name,boolean directory){this.uri=uri;this.name=name;this.directory=directory;}
    }
    private String pendingImport,romName="",lastError="";
    private long pendingImportGeneration=-1,pendingExportGeneration=-1,pendingFolderGeneration=-1;
    private byte[] pendingExport;
    private JSONObject lastStatus=new JSONObject();
    private interface Result { void done(String text); }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved); prefs=getSharedPreferences("badn64_native",MODE_PRIVATE);activeStateSlot=Math.max(0,Math.min(4,prefs.getInt("state.activeSlot",0)));
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);
        inputManager=(InputManager)getSystemService(INPUT_SERVICE);
        inputManager.registerInputDeviceListener(this,main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(Build.VERSION.SDK_INT>=28) {
            WindowManager.LayoutParams p=getWindow().getAttributes();
            p.layoutInDisplayCutoutMode=Build.VERSION.SDK_INT>=30?WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS:WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(p);
        }
        String orientation=prefs.getString("orientation","landscape");
        applyOrientation(orientation); buildViews(); configureFocus();
        if(Build.VERSION.SDK_INT>=33) {
            backCallback=this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,backCallback);
        }
        io.execute(()->{
            try {
                long handle=NativeBridge.create(getFilesDir().getAbsolutePath());
                if(handle==0) throw new IllegalStateException("The native emulator could not initialize.");
                engine=handle;
                main.post(()->{
                    if(destroyed) return;
                    engineReady=true;
                    if(surface.getHolder().getSurface().isValid()) attachSurface(surface.getHolder());
                    dispatchPause(); dispatchAudio(); applyRtc(); applyRewind(); applySpeed();applyDisplay();
                    main.post(statusTick);
                    // A recreated Activity starts a new empty native core too.
                    showMenu();
                });
            } catch(Throwable e) { main.post(()->showError("Native initialization failed",e.getMessage()==null?e.toString():e.getMessage())); }
        });
    }
    private SharedPreferences controlPrefs() { return getSharedPreferences("native_controls",MODE_PRIVATE); }
    private void buildViews() {
        root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        surface=new SurfaceView(this); surface.setKeepScreenOn(true);
        root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        surface.getHolder().addCallback(new SurfaceHolder.Callback(){
            public void surfaceCreated(SurfaceHolder holder) { attachSurface(holder); }
            public void surfaceChanged(SurfaceHolder holder,int format,int width,int height) { attachSurface(holder); }
            public void surfaceDestroyed(SurfaceHolder holder) {
                if(engineReady&&!destroyed) io.execute(()->{if(engine!=0&&!destroyed)NativeBridge.attachSurface(engine,null);});
            }
        });
        controls=new ControlsView(this,new ControlsView.Listener(){
            public void buttonsChanged(int mask) { touchMask=mask; sendButtons(); }
            public void stickChanged(int x,int y) { touchStickX=x;touchStickY=y;sendStick(); }
            public void rewindHeld(boolean held) { touchRewind=held;sendRewind(); }
            public void fastForwardHeld(boolean held) { touchFastForward=held;sendFastForward(); }
            public void blastRequested() { quickBlast(); }
            public void pressed() { vibrate(); }
        });
        root.addView(controls,new FrameLayout.LayoutParams(-1,-1));
        // The virtual controller owns held rewind / fast-forward icons at the top left.
        // The overflow menu stays transparent, without a persistent game status banner.
        menuButton=new Button(this);menuButton.setText("⋮");menuButton.setTextSize(30);menuButton.setTextColor(0xAFFFFFFF);menuButton.setBackgroundColor(Color.TRANSPARENT);menuButton.setContentDescription("Open BadN64 menu");menuButton.setPadding(0,0,0,0);menuButton.setOnClickListener(v->showMenu());
        FrameLayout.LayoutParams menuPosition=new FrameLayout.LayoutParams(dp(52),dp(52),android.view.Gravity.TOP|android.view.Gravity.RIGHT);
        root.addView(menuButton,menuPosition);
        editDone=MenuPanel.row(this,"Done");editDone.setTextSize(18);editDone.setVisibility(View.GONE);editDone.setOnClickListener(v->finishControlEdit());
        root.addView(editDone,new FrameLayout.LayoutParams(dp(90),dp(48),android.view.Gravity.TOP|android.view.Gravity.CENTER_HORIZONTAL));
        root.setOnApplyWindowInsetsListener((v,insets)->{
            int safeRight=0,safeTop=0;
            if(Build.VERSION.SDK_INT>=30) {android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.displayCutout());safeRight=safe.right;safeTop=safe.top;}
            else if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null){android.view.DisplayCutout c=insets.getDisplayCutout();safeRight=c.getSafeInsetRight();safeTop=c.getSafeInsetTop();}
            FrameLayout.LayoutParams position=(FrameLayout.LayoutParams)menuButton.getLayoutParams();position.rightMargin=safeRight;position.topMargin=safeTop;menuButton.setLayoutParams(position);
            return insets;
        });
        setContentView(root); immersive();
    }
    private void attachSurface(SurfaceHolder holder) {
        if(!engineReady||!holder.getSurface().isValid()) return;
        android.view.Surface nativeSurface=holder.getSurface();
        io.execute(()->{if(engine!=0&&!destroyed)NativeBridge.attachSurface(engine,nativeSurface);});
    }
    private void configureFocus() {
        AudioAttributes attr=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attr)
            .setOnAudioFocusChangeListener(change->{hasAudioFocus=change==AudioManager.AUDIOFOCUS_GAIN;dispatchAudio();},main).build();
    }
    private void dispatchAudio() { command("audio",json("enabled",resumed&&hasAudioFocus&&prefs.getBoolean("audio",true)),null); }
    private void dispatchPause() { command("pause",json("paused",!resumed||dialogs>0||editingControls||contentChanging),null);updateBlastAvailability(); }
    private void updateBlastAvailability(){if(controls!=null)controls.setBlastAvailable(engineReady&&loaded&&!contentChanging&&resumed&&dialogs==0&&!editingControls&&!sentRewind&&!quickBlastInFlight&&!lastStatus.optBoolean("harvester",false));}
    private void quickBlast(){
        if(!engineReady||!loaded||contentChanging||!resumed||dialogs>0||editingControls||sentRewind||quickBlastInFlight||lastStatus.optBoolean("harvester",false))return;
        quickBlastInFlight=true;updateBlastAvailability();
        command("blast",json("quick",true),text->{quickBlastInFlight=false;if(successful(text))notifyPendingBlast(text);updateBlastAvailability();});
    }
    private void notifyPendingBlast(String text){try{JSONObject result=new JSONObject(text);if(result.optBoolean("pending")||result.optBoolean("queued"))Toast.makeText(this,result.optString("message","Resume the game to apply the pending blast."),Toast.LENGTH_LONG).show();}catch(Exception ignored){}}
    private void command(String name,JSONObject options,Result result) {
        if(!engineReady||destroyed) { if(result!=null)result.done("{\"ok\":false,\"error\":\"Native emulator is not ready.\"}");return; }
        if(contentChanging&&isContentCommand(name)&&!name.equals("close")){if(result!=null)result.done("{\"ok\":false,\"error\":\"Wait for the cartridge change to finish.\"}");return;}
        String data=options==null?"{}":options.toString();
        long generation=contentSession.current();
        io.execute(()->{
            if(engine==0||destroyed) return;
            if(isContentCommand(name)&&!contentSession.isCurrent(generation))return;
            try {
                String output=NativeBridge.command(engine,name,data);
                if(result!=null) main.post(()->{if(isCurrentContent(generation))result.done(output==null?"{}":output);});
            } catch(Throwable e) { main.post(()->{if(!isCurrentContent(generation))return;if(result!=null){JSONObject failure=json("ok",false);try{failure.put("error",e.toString());}catch(Exception ignored){}result.done(failure.toString());}else showError("Native command failed",e.toString());}); }
        });
    }
    private boolean isCurrentContent(long generation){return !destroyed&&contentSession.isCurrent(generation);}
    private boolean isContentCommand(String name){
        switch(name){case "pause":case "audio":case "rtc_config":case "rewind_config":case "speed_config":case "display_config":case "core_config":return false;default:return true;}
    }
    private long beginContentChange(){
        long generation=contentSession.begin();contentChanging=true;quickBlastInFlight=false;libraryGeneration++;
        // Interrupt the old guest directly; the IO queue may be waiting for its frame.
        requestContentStop();
        pendingImport=null;pendingImportGeneration=-1;pendingExport=null;pendingExportGeneration=-1;pendingFolderGeneration=-1;
        releaseHeldInputs();dispatchPause();updateBlastAvailability();return generation;
    }
    private void requestContentStop(){if(engineReady&&engine!=0)NativeBridge.requestStop(engine);}
    private void closeGame(){
        if(!engineReady||destroyed)return;
        long generation=beginContentChange();
        command("close",null,text->{
            if(!isCurrentContent(generation))return;
            contentChanging=false;
            if(successful(text)){loaded=false;romName="";lastError="";lastStatus=new JSONObject();prefs.edit().putBoolean("rtc.auto",false).apply();closeMenus();showMainMenu();}
            else dispatchPause();
        });
    }
    private JSONObject json(String name,Object value) { JSONObject obj=new JSONObject();try{obj.put(name,value);}catch(Exception ignored){}return obj; }
    private boolean successful(String text) {
        try { JSONObject data=new JSONObject(text); if(!data.optBoolean("ok",true)) { showError("BadN64",data.optString("error","The native operation failed."));return false; } }
        catch(Exception e) { if(text!=null&&!text.isEmpty()) {showError("BadN64",text);return false;} }
        return true;
    }
    private final Runnable statusTick=new Runnable(){ public void run(){
        if(destroyed||!engineReady)return;
        long generation=contentSession.current();
        io.execute(()->{
            try { String text=NativeBridge.status(engine);JSONObject info=new JSONObject(text);
                main.post(()->{if(destroyed)return;if(contentSession.isCurrent(generation)&&!contentChanging){lastStatus=info;loaded=info.optBoolean("loaded",loaded);romName=info.optString("romName",romName);
                    if(harvestStatus!=null)harvestStatus.setText((info.optBoolean("harvestRunning")?"Running emulated frames…":"Harvester paused / ready")+"\n"+info.optString("message","")+"\nNative frame "+info.optLong("frame",0));
                    if(systemActionsMenu!=null)systemActionsMenu.setItemEnabled(0,selectedStateAvailable());
                    updateBlastAvailability();String error=info.optString("error",""); if(!error.isEmpty()&&!error.equals(lastError)){lastError=error;showError("Native emulator",error);}} main.postDelayed(this,1000);
                });
            }catch(Throwable e){main.post(()->{if(!destroyed)main.postDelayed(this,2000);});}
        });
    }};
    private void handleBack(){
        if(editingControls){finishControlEdit();return;}
        if(!openMenus.isEmpty()){MenuPanel top=openMenus.get(openMenus.size()-1);if(top==libraryMenu&&libraryPath.size()>1){libraryUp();return;}if(openMenus.size()==1&&top.isRootMenu()&&!loaded){moveTaskToBack(true);return;}top.dismiss();return;}
        showMenu();
    }
    private void showMenu() {
        if(destroyed) return;
        if(editingControls){finishControlEdit();return;}
        if(!openMenus.isEmpty())return;
        if(loaded)showSystemActions();else showMainMenu();
    }
    private void replaceWithMainMenu(){closingMenus=true;for(int i=openMenus.size()-1;i>=0;i--)openMenus.get(i).dismiss();closingMenus=false;showMainMenu();}
    private void showMainMenu(){
        String[] items={"Open Content","Recent Content","System Actions","On-screen Input Setup","Key/Gamepad Input Setup","Options","Benchmark Content","RTC Corruption","N64 Memory Inspector","About BadN64"};
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("BadN64").setRootMenu(true).setItems(items,(d,which)->{
            switch(which){
                case 0:showOpenContent();break;case 1:showRecent();break;case 2:showSystemActions();break;
                case 3:showControls();break;case 4:showGamepads();break;case 5:showOptions();break;
                case 6:showBenchmark();break;case 7:showRtcActions();break;case 8:showInspector();break;
                case 9:showAbout();break;
            }
        }).setEnabledItems(new boolean[]{true,true,loaded,true,true,true,loaded,true,loaded,true}).setKeepOpen(true).create();trackDialog(dialog);
    }
    private void showSystemActions(){
        String[] items={"Load State","Save State","State Slot ("+activeStateSlot+")","RTC Corruption","Save States / Rewind","Reset Game","Close Game","Main Menu","Recover Last Safe State","Import / Export"};
        systemActionsMenu=new MenuPanel.Builder(this).setTitle("System Actions").setItems(items,(d,which)->{
            switch(which){
                case 0:loadSelectedState();break;case 1:saveSelectedState();break;
                case 2:showStateSlot();break;case 3:showRtcActions();break;case 4:showStates();break;
                case 5:command("reset",null,t->{if(successful(t))closeMenus();});break;
                case 6:closeGame();break;
                case 7:replaceWithMainMenu();break;
                case 8:command("recover",null,t->{if(successful(t))closeMenus();});break;
                case 9:showImportExport();break;
            }
        }).setEnabledItems(new boolean[]{selectedStateAvailable(),true,true,true,true,true,true,true,true,true}).setKeepOpen(true).setNegativeButton("Back",null).create();trackDialog(systemActionsMenu);
    }
    private void saveSelectedState(){final int slot=activeStateSlot;command(slot==0?"quick_save":"save_slot",slot==0?null:json("slot",slot),text->{if(successful(text)){if(slot==0)try{lastStatus.put("quickStateAvailable",true);}catch(Exception ignored){}closeMenus();}});}
    private void loadSelectedState(){command(activeStateSlot==0?"quick_load":"load_slot",activeStateSlot==0?null:json("slot",activeStateSlot),text->{if(successful(text))closeMenus();});}
    private boolean selectedStateAvailable(){return activeStateSlot!=0||!lastStatus.has("quickStateAvailable")||lastStatus.optBoolean("quickStateAvailable");}
    private void showStateSlot(){
        final MenuPanel parent=systemActionsMenu;
        trackDialog(new MenuPanel.Builder(this).setTitle("State Slot").setItems(new String[]{"0 — Quick State","1","2","3","4"},(d,which)->{activeStateSlot=which;prefs.edit().putInt("state.activeSlot",which).apply();if(parent!=null&&showExistingPage(parent)){parent.setItemText(2,"State Slot ("+activeStateSlot+")");parent.setItemEnabled(0,selectedStateAvailable());}else showSystemActions();}).setNegativeButton("Back",null).create());
    }
    private void showRtcActions(){
        String[] items={"Corruption Settings","Blast Once","Undo Last Blast","Blast History","Glitch Harvester"};
        trackDialog(new MenuPanel.Builder(this).setTitle("RTC Corruption").setItems(items,(d,which)->{
            switch(which){case 0:showRtc();break;case 1:command("blast",null,t->{if(successful(t)){notifyPendingBlast(t);closeMenus();}});break;
                case 2:command("undo",null,t->{if(successful(t))closeMenus();});break;case 3:showHistory();break;case 4:showHarvester();break;}
        }).setEnabledItems(new boolean[]{true,loaded,loaded,loaded,loaded}).setKeepOpen(true).setNegativeButton("Back",null).create());
    }
    private void showOptions(){
        trackDialog(new MenuPanel.Builder(this).setTitle("Options").setItems(new String[]{"Fast-forward / Rewind Speed","Sound / Display / Touch Controls","Save States / Rewind Buffer","Import / Export"},(d,which)->{
            switch(which){case 0:showSpeedSettings();break;case 1:showControls();break;case 2:showStates();break;case 3:showImportExport();break;}
        }).setKeepOpen(true).setNegativeButton("Back",null).create());
    }
    private void showGamepads(){
        LinearLayout view=column();label(view,"Connected gamepads: "+gamepadNames());
        label(view,"Bluetooth and USB gamepads support a true analog stick. The D-pad stays separate; the right stick operates the four C buttons. Touch and gamepad input can be combined.");
        label(view,"A / B → N64 A / B\nX / Y → C-left / C-up     Right stick → C buttons\nL1 / R1 → L / R     L2 → Z\nSTART → Start     Hold SELECT: rewind\nHold R2: fast-forward");
        label(view,"Keyboard\nW / A / S / D: analog stick     Arrows: D-pad\nZ / X: A / B     I / J / K / L: C-up / left / down / right\nQ / E: L / R     Shift: Z     Enter: Start\nHold R: rewind     Hold F: fast-forward");
        button(view,"Speed Settings",this::showSpeedSettings);
        trackDialog(new MenuPanel.Builder(this).setTitle("Key/Gamepad Input Setup").setView(scrolling(view)).setNegativeButton("Back",null).create());
    }
    private void showBenchmark(){
        LinearLayout view=column();TextView result=label(view,"Run a native core benchmark for 120 emulated frames. Your complete emulator state is restored afterward; audio is not played during measurement.");
        button(view,"Run Benchmark",()->command("benchmark",json("frames",120),text->{if(successful(text))result.setText(pretty(text));}));
        trackDialog(new MenuPanel.Builder(this).setTitle("Benchmark Content").setView(scrolling(view)).setNegativeButton("Back",null).create());
    }
    private void closeMenus(){libraryGeneration++;closingMenus=true;for(int i=openMenus.size()-1;i>=0;i--)openMenus.get(i).dismiss();closingMenus=false;dispatchPause();updateMenuPresentation();}
    private void showSpeedSettings(){
        LinearLayout view=column();float ff=prefs.getFloat("speed.fastForward",2),rew=prefs.getFloat("speed.rewind",2);
        Spinner forward=spinner(view,"Fast-forward Speed",new String[]{"2×","3×","4×","8×"},speedIndex(new float[]{2,3,4,8},ff));
        Spinner reverse=spinner(view,"Rewind Speed",new String[]{"0.5×","1×","2×","4×","8×","16×"},speedIndex(new float[]{.5f,1,2,4,8,16},rew));
        CheckBox audible=check(view,"Play Audio While Rewinding",prefs.getBoolean("speed.rewindAudio",true));
        label(view,"Hold the double-triangle button to fast-forward. Hold the reverse button to rewind. Release to return to normal speed.");
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("Fast-forward / Rewind Speed").setView(scrolling(view)).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        trackDialog(dialog);dialog.getButton(MenuPanel.BUTTON_POSITIVE).setOnClickListener(v->{
            prefs.edit().putFloat("speed.fastForward",new float[]{2,3,4,8}[forward.getSelectedItemPosition()]).putFloat("speed.rewind",new float[]{.5f,1,2,4,8,16}[reverse.getSelectedItemPosition()]).putBoolean("speed.rewindAudio",audible.isChecked()).apply();applySpeed();dialog.dismiss();
        });
    }
    private int speedIndex(float[] values,float value){for(int i=0;i<values.length;i++)if(Math.abs(values[i]-value)<.01f)return i;return Math.min(2,values.length-1);}
    private void applySpeed(){
        try{JSONObject settings=new JSONObject().put("fastForwardMultiplier",prefs.getFloat("speed.fastForward",2)).put("rewindMultiplier",prefs.getFloat("speed.rewind",2)).put("rewindAudio",prefs.getBoolean("speed.rewindAudio",true));command("speed_config",settings,this::successful);}
        catch(Exception e){showError("Playback Speed",e.toString());}
    }
    private void applyDisplay(){JSONObject display=json("aspect",prefs.getString("display.aspect","4:3"));try{display.put("videoMode",prefs.getString("display.videoMode","fast"));}catch(Exception ignored){}command("display_config",display,this::successful);}
    private void showOpenContent(){
        String saved=prefs.getString("library.tree","");
        if(!saved.isEmpty()){
            try{Uri tree=Uri.parse(saved);if(!DocumentsContract.isTreeUri(tree))throw new IllegalArgumentException("Select a ROM folder again.");libraryPath.clear();libraryPath.add(DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree)));showLibraryFolder();return;}
            catch(Exception ignored){prefs.edit().remove("library.tree").apply();}
        }
        showContentSources();
    }
    private void showContentSources(){
        if(showExistingPage(contentSourcesMenu))return;
        contentSourcesMenu=new MenuPanel.Builder(this).setTitle("Open Content").setItems(new String[]{"Choose ROM Folder","Open a ROM File"},(d,which)->{if(which==0)pickRomFolder();else pick("rom");}).setKeepOpen(true).setNegativeButton("Back",null).create();trackDialog(contentSourcesMenu);
    }
    private void pickRomFolder(){
        pendingFolderGeneration=contentSession.current();
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        try{startActivityForResult(intent,PICK_ROM_FOLDER);}catch(Exception e){showError("Choose ROM Folder",e.toString());}
    }
    private void libraryUp(){
        if(libraryPath.size()>1){libraryPath.remove(libraryPath.size()-1);showLibraryFolder();}
        else {if(libraryMenu!=null)libraryMenu.dismiss();showContentSources();}
    }
    private boolean isRomDocument(String name){String n=name.toLowerCase(Locale.ROOT);return n.endsWith(".z64")||n.endsWith(".n64")||n.endsWith(".v64")||n.endsWith(".zip");}
    private void showLibraryFolder(){
        if(libraryPath.isEmpty())return;
        Uri folder=libraryPath.get(libraryPath.size()-1);
        final int generation=++libraryGeneration;
        if(libraryMenu!=null)libraryMenu.dismiss();
        libraryMenu=new MenuPanel.Builder(this).setTitle("Open Content").setFileBrowser(this::libraryUp).setMessage("Reading ROM folder…").create();
        trackDialog(libraryMenu);
        io.execute(()->{
            try{
                String folderName=documentName(folder);List<LibraryEntry> entries=new ArrayList<>();
                Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(folder,DocumentsContract.getDocumentId(folder));
                String[] projection={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
                try(Cursor cursor=getContentResolver().query(children,projection,null,null,null)){
                    if(cursor==null)throw new IllegalStateException("This provider could not list the folder. Use Open a ROM File instead.");
                    while(cursor.moveToNext()){
                        String id=cursor.getString(0),name=cursor.getString(1),mime=cursor.getString(2);
                        if(id==null||name==null)continue;boolean directory=DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
                        if(directory||isRomDocument(name))entries.add(new LibraryEntry(DocumentsContract.buildDocumentUriUsingTree(folder,id),name,directory));
                        if(entries.size()>=5000)break;
                    }
                }
                Collections.sort(entries,(a,b)->a.directory!=b.directory?(a.directory?-1:1):a.name.compareToIgnoreCase(b.name));
                main.post(()->{
                    if(destroyed||generation!=libraryGeneration||libraryMenu==null)return;
                    libraryMenu.dismiss();String[] names=new String[entries.size()];for(int i=0;i<entries.size();i++)names[i]=(entries.get(i).directory?"▸ ":"")+entries.get(i).name;
                    MenuPanel.Builder panel=new MenuPanel.Builder(this).setTitle(folderName).setFileBrowser(this::libraryUp).setKeepOpen(true);
                    if(entries.isEmpty())panel.setMessage("This folder contains no supported ROMs. Use the up arrow to choose another folder or open one ROM file.");
                    else panel.setItems(names,(dialog,index)->{LibraryEntry entry=entries.get(index);if(entry.directory){libraryPath.add(entry.uri);showLibraryFolder();}else openRomDocument(entry.uri,null);});
                    libraryMenu=panel.create();trackDialog(libraryMenu);
                });
            }catch(Throwable e){main.post(()->{if(destroyed||generation!=libraryGeneration||libraryMenu==null)return;libraryMenu.dismiss();showContentSources();showError("ROM Folder",e.getMessage()==null?e.toString():e.getMessage());});}
        });
    }
    private JSONArray recentContent(){try{return new JSONArray(prefs.getString("recent.content","[]"));}catch(Exception ignored){return new JSONArray();}}
    private void recordRecent(Uri source,String name,String entry){
        if(source==null)return;
        try{JSONArray previous=recentContent(),saved=new JSONArray();String uri=source.toString(),zipEntry=entry==null?"":entry;
            saved.put(new JSONObject().put("uri",uri).put("name",name).put("entry",zipEntry));
            for(int i=0;i<previous.length()&&saved.length()<12;i++){JSONObject item=previous.optJSONObject(i);if(item!=null&&!(uri.equals(item.optString("uri"))&&zipEntry.equals(item.optString("entry"))))saved.put(item);}
            prefs.edit().putString("recent.content",saved.toString()).apply();
        }catch(Exception ignored){}
    }
    private void showRecent(){
        JSONArray history=recentContent();if(history.length()==0){trackDialog(new MenuPanel.Builder(this).setTitle("Recent Content").setMessage("Open Nintendo 64 content to add it to this list.").setNegativeButton("Back",null).create());return;}
        String[] names=new String[history.length()];for(int i=0;i<names.length;i++){JSONObject item=history.optJSONObject(i);names[i]=item==null?"Unavailable content":item.optString("name","Nintendo 64 ROM");}
        trackDialog(new MenuPanel.Builder(this).setTitle("Recent Content").setItems(names,(d,index)->{
            JSONObject item=history.optJSONObject(index);if(item==null)return;openRomDocument(Uri.parse(item.optString("uri")),item.optString("entry",""));
        }).setNegativeButton("Back",null).setNeutralButton("Clear Recent Content",(d,w)->prefs.edit().remove("recent.content").apply()).create());
    }
    private void openRomDocument(Uri uri,String selectedEntry){
        if(!engineReady||destroyed)return;
        long generation=beginContentChange();
        io.execute(()->{try{
            if(!isCurrentContent(generation))return;
            JSONObject closed=new JSONObject(NativeBridge.command(engine,"close","{}"));
            if(!closed.optBoolean("ok",false))throw new IllegalStateException(closed.optString("error","Could not close the previous game."));
            main.post(()->{if(isCurrentContent(generation)){loaded=false;romName="";lastError="";lastStatus=new JSONObject();prefs.edit().putBoolean("rtc.auto",false).apply();updateBlastAvailability();updateMenuPresentation();}});
            if(!isCurrentContent(generation))return;
            String name=documentName(uri),entry=selectedEntry;byte[] bytes;
            try(InputStream input=getContentResolver().openInputStream(uri)){if(input==null)throw new IllegalStateException("The selected content could not be opened.");bytes=readLimited(input,MAX_DOCUMENT,generation);}
            if(!isCurrentContent(generation))return;
            if(bytes.length>=4&&bytes[0]=='P'&&bytes[1]=='K'){
                if(entry==null||entry.isEmpty()){List<String> names=zipRomNames(bytes);if(names.isEmpty())throw new IllegalArgumentException("The ZIP contains no .z64, .n64 or .v64 ROM.");if(names.size()>1){byte[] archive=bytes;main.post(()->{if(isCurrentContent(generation))chooseZip(archive,names,uri,generation);});return;}entry=names.get(0);}
                name=entry;bytes=zipRom(bytes,entry,generation);
            }
            loadRom(bytes,name,uri,entry,generation);
        }catch(Throwable e){main.post(()->{if(isCurrentContent(generation)){contentChanging=false;dispatchPause();showError("Open Content",e.getMessage()==null?e.toString():e.getMessage());}});}});
    }
    private boolean showExistingPage(MenuPanel page){
        int index=openMenus.indexOf(page);if(index<0)return false;
        closingMenus=true;for(int i=openMenus.size()-1;i>index;i--)openMenus.get(i).dismiss();closingMenus=false;
        page.setVisible(true);dispatchPause();updateMenuPresentation();return true;
    }
    private void trackDialog(MenuPanel dialog){trackDialog(dialog,null);}
    private void trackDialog(MenuPanel dialog,Runnable dismissed) {
        if(destroyed)return;
        if(!openMenus.isEmpty())openMenus.get(openMenus.size()-1).setVisible(false);
        dialogs++;openMenus.add(dialog);dialog.setGameBackdrop(loaded);dialog.setCloseAction(()->{if(loaded)closeMenus();else{dialog.dismiss();if(openMenus.isEmpty())showMainMenu();}});
        dispatchPause();releaseHeldInputs();
        dialog.setOnDismissListener(d->{
            openMenus.remove(dialog);dialogs=openMenus.size();
            if(!closingMenus){if(!openMenus.isEmpty())openMenus.get(openMenus.size()-1).setVisible(true);dispatchPause();updateMenuPresentation();}
            if(dialog==libraryMenu)libraryMenu=null;
            if(dialog==contentSourcesMenu)contentSourcesMenu=null;
            if(dialog==systemActionsMenu)systemActionsMenu=null;
            if(dismissed!=null)dismissed.run();
        });
        dialog.show();updateMenuPresentation();
    }
    private void updateMenuPresentation(){
        boolean browsing=dialogs>0;
        if(controls!=null)controls.setVisibility(browsing?View.INVISIBLE:View.VISIBLE);
        if(menuButton!=null)menuButton.setVisibility(browsing?View.INVISIBLE:View.VISIBLE);
        immersive();updateBlastAvailability();
    }
    private void showError(String title,String text) {
        if(destroyed)return;trackDialog(new MenuPanel.Builder(this).setTitle(title).setMessage(text).setPositiveButton("OK",null).create());
    }
    private void showAbout() {
        String text="BadN64 — Nintendo 64 emulation and live memory corruption\n\nAn experimental native Android build powered by ParaLLEl-N64 / Mupen64Plus, with software rendering. Game compatibility and speed vary by device; some games may run slowly.\n\nBlast RDRAM, explore corruption history, keep results with the Glitch Harvester, and recover or rewind full emulator states.\n\nSupports .z64, .n64, .v64 and ZIP ROMs. Cartridge files remain read-only. Save memory includes cartridge saves and controller paks.\n\nParaLLEl-N64 and Mupen64Plus are GPL-licensed. Source and attribution are included with this project.";
        String cpu=lastStatus.optString("cpuCore","");if(!cpu.isEmpty())text+="\n\nCPU: "+(cpu.equals("cached_interpreter")?"Cached interpreter":cpu.equals("pure_interpreter")?"Interpreter":cpu.replace('_',' '));
        trackDialog(new MenuPanel.Builder(this).setTitle("About BadN64").setMessage(text).setKeepOpen(true).setNeutralButton("Open source licenses",(d,w)->showLicenses()).setPositiveButton("OK",null).create());
    }
    private void showLicenses(){io.execute(()->{try{StringBuilder text=new StringBuilder();for(String name:new String[]{"Parallel-N64.txt","THIRD_PARTY_NOTICES.txt","PROVENANCE.md"})try(InputStream in=getAssets().open("licenses/"+name)){text.append(new String(readLimited(in,MAX_DOCUMENT),java.nio.charset.StandardCharsets.UTF_8)).append("\n\n");}main.post(()->{LinearLayout view=column();TextView data=label(view,text.toString());data.setTextIsSelectable(true);trackDialog(new MenuPanel.Builder(this).setTitle("Open source licenses").setView(scrolling(view)).setPositiveButton("Close",null).create());});}catch(Exception e){main.post(()->showError("Licenses",e.toString()));}});}
    private LinearLayout column() {LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);view.setPadding(dp(16),dp(8),dp(16),dp(8));return view;}
    private ScrollView scrolling(LinearLayout view){ScrollView sc=new ScrollView(this);sc.addView(view);return sc;}
    private TextView label(LinearLayout parent,String value){TextView t=new TextView(this);t.setText(value);t.setTextColor(Color.WHITE);t.setTextSize(18);t.setPadding(0,dp(7),0,dp(7));parent.addView(t);return t;}
    private Button button(LinearLayout parent,String name,Runnable action){Button b=MenuPanel.row(this,name);b.setOnClickListener(v->action.run());parent.addView(b,new LinearLayout.LayoutParams(-1,-2));MenuPanel.addDivider(this,parent);return b;}
    private CheckBox check(LinearLayout parent,String name,boolean value){CheckBox c=new CheckBox(this);c.setText(name);c.setTextColor(Color.WHITE);c.setTextSize(20);c.setButtonTintList(ColorStateList.valueOf(0xFF9696FF));c.setBackgroundColor(Color.BLACK);c.setChecked(value);c.setPadding(0,dp(8),0,dp(8));parent.addView(c);MenuPanel.addDivider(this,parent);return c;}
    private GradientDrawable formBackground(){GradientDrawable background=new GradientDrawable();background.setColor(Color.BLACK);background.setStroke(dp(1),0xFF454545);return background;}
    private EditText field(LinearLayout parent,String name,String value){label(parent,name);EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setTextColor(Color.WHITE);e.setTextSize(18);e.setBackground(formBackground());e.setPadding(dp(8),dp(8),dp(8),dp(8));parent.addView(e);return e;}
    private Spinner spinner(LinearLayout parent,String title,String[] values,int selected){
        label(parent,title);Spinner s=new Spinner(this,Spinner.MODE_DROPDOWN);
        ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
            private View item(int position,boolean expanded){TextView text=new TextView(MainActivity.this);text.setText(values[position]+(expanded?"":"  ▾"));text.setTextColor(Color.WHITE);text.setTextSize(20);text.setBackgroundColor(Color.BLACK);text.setPadding(dp(8),dp(10),dp(8),dp(10));text.setMinHeight(dp(44));return text;}
            @Override public View getView(int position,View recycled,android.view.ViewGroup parent){return item(position,false);}
            @Override public View getDropDownView(int position,View recycled,android.view.ViewGroup parent){return item(position,true);}
        };
        s.setAdapter(a);s.setSelection(selected);s.setPopupBackgroundDrawable(new ColorDrawable(Color.BLACK));s.setBackground(formBackground());parent.addView(s,new LinearLayout.LayoutParams(-1,-2));return s;
    }
    private SeekBar slider(LinearLayout parent,String title,int max,int progress){TextView name=label(parent,title+": "+progress);SeekBar seek=new SeekBar(this);seek.setProgressTintList(ColorStateList.valueOf(0xFF9696FF));seek.setThumbTintList(ColorStateList.valueOf(Color.WHITE));seek.setMax(max);seek.setProgress(progress);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int p,boolean user){name.setText(title+": "+p);}});parent.addView(seek);return seek;}
    private int indexOf(String[] values,String value){for(int i=0;i<values.length;i++)if(values[i].equals(value))return i;return 0;}
    private void showRtc() {
        LinearLayout view=column();
        Spinner targetChoice=spinner(view,"Target",TARGET_NAMES,indexOf(TARGET_IDS,prefs.getString("rtc.target","ram")));
        Spinner engineChoice=spinner(view,"Corruption engine",ENGINE_NAMES,indexOf(ENGINE_IDS,prefs.getString("rtc.engine","bitflip")));
        EditText intensity=field(view,"Intensity (corruption units per blast)",Integer.toString(prefs.getInt("rtc.intensity",16)));
        JSONObject liveRtc=lastStatus.optJSONObject("rtc");
        CheckBox auto=check(view,"Auto Blast",loaded&&liveRtc!=null?liveRtc.optBoolean("autoBlast"):prefs.getBoolean("rtc.auto",false));
        EditText interval=field(view,"Auto Blast interval in emulated frames",Integer.toString(prefs.getInt("rtc.interval",60)));
        label(view,"Random mode is the default. Every Blast and Auto Blast independently selects new addresses and mutation values.");
        CheckBox seedMode=check(view,"Advanced: reproducible manual seed",prefs.getBoolean("rtc.manualSeed",false));
        EditText seed=field(view,"Advanced seed",prefs.getString("rtc.seed","1"));
        label(view,"Graphics and audio blasts target data as the game runs. If a blast crashes, lower the intensity.");
        LinearLayout domainSettings=new LinearLayout(this);domainSettings.setOrientation(LinearLayout.VERTICAL);view.addView(domainSettings);
        List<CheckBox> enabled=new ArrayList<>();List<EditText> starts=new ArrayList<>(),ends=new ArrayList<>(),exclusions=new ArrayList<>();
        for(int i=0;i<DOMAIN_IDS.length;i++){
            String id=DOMAIN_IDS[i];label(domainSettings,"── "+DOMAIN_NAMES[i]+" ──");
            CheckBox domainEnabled=check(domainSettings,"Enable domain",!id.equals("rom")&&prefs.getBoolean("rtc."+id+".enabled",id.equals("rdram")));domainEnabled.setEnabled(!id.equals("rom"));enabled.add(domainEnabled);
            starts.add(field(domainSettings,"Start address (hex)",prefs.getString("rtc."+id+".start","0")));
            ends.add(field(domainSettings,"End address (hex, inclusive; blank = whole domain)",prefs.getString("rtc."+id+".end","")));
            exclusions.add(field(domainSettings,"Excluded hex ranges, e.g. 0-1F,100-10F",prefs.getString("rtc."+id+".exclude","")));
            if(id.equals("rom"))label(domainSettings,"Cartridge ROM is read-only in this build; inspect or export its normalized .z64 contents.");
            if(id.equals("sram"))label(domainSettings,"Includes EEPROM, SRAM, FlashRAM and controller paks in one native save-memory buffer.");
        }
        domainSettings.setVisibility(targetChoice.getSelectedItemPosition()==0?View.VISIBLE:View.GONE);
        targetChoice.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> parent,View item,int position,long id){domainSettings.setVisibility(position==0?View.VISIBLE:View.GONE);}public void onNothingSelected(android.widget.AdapterView<?> parent){}});
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("RTC live memory corruption").setView(scrolling(view)).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        trackDialog(dialog);dialog.getButton(MenuPanel.BUTTON_POSITIVE).setOnClickListener(v->{
            try{
                int units=Integer.parseInt(intensity.getText().toString().trim()),frames=Integer.parseInt(interval.getText().toString().trim());
                if(units<1||units>100000||frames<1)throw new IllegalArgumentException("Intensity must be 1–100000 and interval must be positive.");
                SharedPreferences.Editor save=prefs.edit().putString("rtc.target",TARGET_IDS[targetChoice.getSelectedItemPosition()]).putString("rtc.engine",ENGINE_IDS[engineChoice.getSelectedItemPosition()]).putInt("rtc.intensity",units).putBoolean("rtc.auto",auto.isChecked()).putInt("rtc.interval",frames).putBoolean("rtc.manualSeed",seedMode.isChecked()).putString("rtc.seed",seed.getText().toString().trim());
                if(targetChoice.getSelectedItemPosition()==0)for(int i=0;i<DOMAIN_IDS.length;i++){
                    String start=starts.get(i).getText().toString().trim(),end=ends.get(i).getText().toString().trim(),excluded=exclusions.get(i).getText().toString().trim();
                    long a=parseHex(start),b=end.isEmpty()?-1:parseHex(end);if(b>=0&&b<a)throw new IllegalArgumentException("Domain end must be at or after start.");parseExclusions(excluded);
                    String prefix="rtc."+DOMAIN_IDS[i]+".";save.putBoolean(prefix+"enabled",enabled.get(i).isChecked()).putString(prefix+"start",start).putString(prefix+"end",end).putString(prefix+"exclude",excluded);
                }
                save.apply();applyRtc();dialog.dismiss();
            }catch(Exception e){showError("RTC settings",e.getMessage());}
        });
    }
    private long parseHex(String text){String value=text.trim();if(value.startsWith("0x")||value.startsWith("0X"))value=value.substring(2);if(value.isEmpty())return 0;long n=Long.parseLong(value,16);if(n<0||n>0x7FFFFFFFL)throw new IllegalArgumentException("Address is outside the supported range.");return n;}
    private JSONArray parseExclusions(String text)throws Exception{
        JSONArray a=new JSONArray();if(text.trim().isEmpty())return a;
        for(String item:text.split(",")){String[]pair=item.trim().split("-");if(pair.length>2)throw new IllegalArgumentException("Use hex exclusions such as 0-1F,100-10F.");long start=parseHex(pair[0]),end=pair.length==2?parseHex(pair[1]):start;if(end<start)throw new IllegalArgumentException("Exclusion end precedes start.");a.put(new JSONArray().put(start).put(end));}return a;
    }
    private void applyRtc(){
        try{
            JSONObject o=new JSONObject();o.put("target",prefs.getString("rtc.target","ram")).put("engine",prefs.getString("rtc.engine","bitflip")).put("intensity",prefs.getInt("rtc.intensity",16)).put("auto",prefs.getBoolean("rtc.auto",false)).put("interval",prefs.getInt("rtc.interval",60)).put("manualSeed",prefs.getBoolean("rtc.manualSeed",false)).put("seed",prefs.getString("rtc.seed","1"));
            JSONArray domains=new JSONArray();for(String id:DOMAIN_IDS){String p="rtc."+id+".";String end=prefs.getString(p+"end","");JSONObject domain=new JSONObject().put("id",id).put("enabled",!id.equals("rom")&&prefs.getBoolean(p+"enabled",id.equals("rdram"))).put("start",parseHex(prefs.getString(p+"start","0"))).put("end",end.isEmpty()?0xFFFFFFFFL:parseHex(end)).put("exclusions",parseExclusions(prefs.getString(p+"exclude","")));domains.put(domain);}o.put("domains",domains);command("rtc_config",o,this::successful);
        }catch(Exception e){showError("RTC settings",e.toString());}
    }
    private void showHistory(){command("history",null,text->{if(!successful(text))return;LinearLayout view=column();label(view,"Native blast history records domain, address, old/new values, engine, blast number and generated seed.");TextView data=label(view,pretty(text));data.setTextIsSelectable(true);button(view,"Export Blast History",()->exportFile("history","BadN64-blast-history.json"));
        EditText blast=field(view,"Advanced: replay recorded blast number","");CheckBox match=check(view,"Require previous values to match",true);button(view,"Replay recorded corruption",()->{try{long number=Long.parseLong(blast.getText().toString().trim());if(number<1)throw new IllegalArgumentException("Enter a positive blast number from this history.");JSONObject options=json("blast",number);options.put("requirePrevious",match.isChecked());command("replay",options,t->{successful(t);});}catch(Exception e){showError("Replay blast",e.getMessage());}});
        trackDialog(new MenuPanel.Builder(this).setTitle("Blast History").setView(scrolling(view)).setPositiveButton("Close",null).create());});}
    private void showHarvester(){
        LinearLayout view=column();label(view,"Clean state → blast → run → keep or discard → restore → next. All emulation and capture use the native core.");
        harvestStatus=label(view,lastStatus.optString("message","Capture a clean native state to begin."));
        EditText frames=field(view,"Run length in emulated frames",Integer.toString(prefs.getInt("harvest.frames",180)));
        Result done=t->{successful(t);};
        button(view,"Capture clean state / Start",()->harvestCommand("harvester_start",frames,done));
        button(view,"Blast and run / Next",()->harvestCommand("harvester_next",frames,t->{if(successful(t))closeMenus();}));
        button(view,"View Current Result",this::closeMenus);
        button(view,"Keep result",()->command("harvester_keep",null,done));
        button(view,"Discard result / restore clean state",()->command("harvester_discard",null,done));
        button(view,"Stop harvester",()->command("harvester_stop",null,done));
        button(view,"Export last kept result",()->exportFile("harvest","BadN64-harvest.bnh"));
        button(view,"Import kept results",()->pick("harvest"));
        trackDialog(new MenuPanel.Builder(this).setTitle("Glitch Harvester").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void harvestCommand(String action,EditText frames,Result done){try{int n=Integer.parseInt(frames.getText().toString().trim());if(n<1||n>3600)throw new IllegalArgumentException("Run length must be 1–3600 frames.");prefs.edit().putInt("harvest.frames",n).apply();command(action,json("runFrames",n),done);}catch(Exception e){showError("Glitch Harvester",e.getMessage());}}
    private void showStates(){
        LinearLayout view=column();label(view,"Manual save slots are separate from the RAM rewind ring.");
        button(view,"Quick Save",()->command("quick_save",null,t->{successful(t);}));
        button(view,"Quick Load",()->command("quick_load",null,t->{successful(t);}));
        for(int slot=1;slot<=4;slot++){final int selected=slot;LinearLayout row=new LinearLayout(this);Button save=MenuPanel.row(this,"Save slot "+slot),load=MenuPanel.row(this,"Load slot "+slot);save.setOnClickListener(v->command("save_slot",json("slot",selected),this::successful));load.setOnClickListener(v->command("load_slot",json("slot",selected),this::successful));row.addView(save,new LinearLayout.LayoutParams(0,-2,1));row.addView(load,new LinearLayout.LayoutParams(0,-2,1));view.addView(row);MenuPanel.addDivider(this,view);}
        int[] seconds={0,15,30,60,120};int selected=indexOf(new String[]{"0","15","30","60","120"},Integer.toString(prefs.getInt("rewind.seconds",0)));
        Spinner preset=spinner(view,"Rewind duration",new String[]{"Off (best speed)","15 seconds","30 seconds","60 seconds","120 seconds"},selected);
        EditText interval=field(view,"Keyframe interval in emulated frames",Integer.toString(prefs.getInt("rewind.interval",10)));
        label(view,"Rewind stores full N64 states and uses extra CPU and memory. Keep it Off for the best speed; manual save slots still work.");
        label(view,"When enabled, hold the reverse-triangle button to rewind. Release to continue from the restored state.");
        button(view,"Rewind Speed / Audio",this::showSpeedSettings);
        button(view,"Apply rewind settings",()->{try{int n=Integer.parseInt(interval.getText().toString().trim());if(n<1||n>120)throw new IllegalArgumentException("Snapshot interval must be 1–120 frames.");prefs.edit().putInt("rewind.seconds",seconds[preset.getSelectedItemPosition()]).putInt("rewind.interval",n).apply();applyRewind();}catch(Exception e){showError("Rewind settings",e.getMessage());}});
        button(view,"Export state",()->exportFile("state","BadN64-state.bn64"));button(view,"Import state",()->pick("state"));
        trackDialog(new MenuPanel.Builder(this).setTitle("Save states and rewind").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void applyRewind(){JSONObject data=json("seconds",prefs.getInt("rewind.seconds",0));try{data.put("intervalFrames",prefs.getInt("rewind.interval",10));}catch(Exception ignored){}command("rewind_config",data,this::successful);}
    private void showControls(){
        LinearLayout view=column();SharedPreferences c=controlPrefs();
        label(view,"Nintendo 64: analog stick, D-pad, A / B, four C buttons, L / R / Z and Start.");
        CheckBox hidden=check(view,"Hide touch controls",c.getBoolean("hidden",false));
        CheckBox vibration=check(view,"Vibration",prefs.getBoolean("vibration",true));
        CheckBox sound=check(view,"Sound",prefs.getBoolean("audio",true));
        SeekBar size=slider(view,"Control size %",180,(int)(c.getFloat("size",1)*100));
        SeekBar opacity=slider(view,"Control opacity %",100,(int)(c.getFloat("opacity",.65f)*100));
        Spinner orientation=spinner(view,"Orientation",new String[]{"Landscape","Portrait","Automatic"},indexOf(new String[]{"landscape","portrait","auto"},prefs.getString("orientation","landscape")));
        Spinner aspect=spinner(view,"Display aspect ratio",new String[]{"Original 4:3","Square pixels"},indexOf(new String[]{"4:3","pixel"},prefs.getString("display.aspect","4:3")));
        Spinner video=spinner(view,"Video mode",new String[]{"Fast","Accurate"},indexOf(new String[]{"fast","accurate"},prefs.getString("display.videoMode","fast")));
        label(view,"Fast gives quicker video output. Accurate adds normal N64 smoothing.");
        label(view,"Video mode applies the next time you load a game.");
        button(view,"Move touch controls",()->{c.edit().putFloat("size",Math.max(.55f,size.getProgress()/100f)).putFloat("opacity",Math.max(.1f,opacity.getProgress()/100f)).apply();controls.reload();editingControls=true;controls.setEditing(true);editDone.setVisibility(View.VISIBLE);dispatchPause();closeMenus();});
        button(view,"Reset control positions",()->{c.edit().remove("padX").remove("padY").remove("stickX").remove("stickY").remove("buttonsX").remove("buttonsY").remove("systemX").remove("systemY").apply();controls.reload();});
        button(view,"Key/Gamepad Input Setup",this::showGamepads);
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("On-screen Input Setup").setView(scrolling(view)).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        trackDialog(dialog);dialog.getButton(MenuPanel.BUTTON_POSITIVE).setOnClickListener(v->{
            c.edit().putBoolean("hidden",hidden.isChecked()).putFloat("size",Math.max(.55f,size.getProgress()/100f)).putFloat("opacity",Math.max(.1f,opacity.getProgress()/100f)).apply();
            String o=new String[]{"landscape","portrait","auto"}[orientation.getSelectedItemPosition()];prefs.edit().putBoolean("vibration",vibration.isChecked()).putBoolean("audio",sound.isChecked()).putString("orientation",o).putString("display.aspect",new String[]{"4:3","pixel"}[aspect.getSelectedItemPosition()]).putString("display.videoMode",new String[]{"fast","accurate"}[video.getSelectedItemPosition()]).apply();
            controls.reload();dispatchAudio();applyDisplay();applyOrientation(o);dialog.dismiss();
        });
    }
    private void finishControlEdit(){editingControls=false;controls.setEditing(false);controls.reload();editDone.setVisibility(View.GONE);dispatchPause();}
    private String gamepadNames(){List<String> names=new ArrayList<>();for(int id:InputDevice.getDeviceIds()){InputDevice d=InputDevice.getDevice(id);if(d!=null&&(d.supportsSource(InputDevice.SOURCE_GAMEPAD)||d.supportsSource(InputDevice.SOURCE_JOYSTICK)))names.add(d.getName());}return names.isEmpty()?"none":String.join(", ",names);}
    private void applyOrientation(String value){setRequestedOrientation(value.equals("portrait")?ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT:value.equals("auto")?ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR:ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);}
    private void showInspector(){
        LinearLayout view=column();label(view,"Inspect live Nintendo 64 memory. Addresses are byte offsets within each domain; bytes are shown in N64 big-endian order.");
        Spinner domain=spinner(view,"Memory domain",DOMAIN_NAMES,0);EditText address=field(view,"Start address (hex)","0");
        TextView data=label(view,"");data.setTypeface(android.graphics.Typeface.MONOSPACE);data.setTextIsSelectable(true);
        button(view,"Read 256 bytes",()->{try{
            int start=(int)parseHex(address.getText().toString());String id=DOMAIN_IDS[domain.getSelectedItemPosition()];long generation=contentSession.current();
            io.execute(()->{try{
                if(!isCurrentContent(generation)||engine==0||contentChanging)return;
                byte[] bytes=NativeBridge.readMemory(engine,id,start,256);StringBuilder out=new StringBuilder();
                for(int i=0;i<bytes.length;i++){if(i%16==0)out.append(String.format(Locale.US,"%n%06X: ",start+i));out.append(String.format(Locale.US,"%02X ",bytes[i]&255));}
                main.post(()->{if(isCurrentContent(generation)&&!contentChanging)data.setText(out.toString());});
            }catch(Throwable e){main.post(()->{if(isCurrentContent(generation))showError("Memory inspector",e.toString());});}});
        }catch(Exception e){showError("Memory inspector",e.getMessage());}});
        button(view,"Domain metadata / native resources",()->{
            long generation=contentSession.current();
            io.execute(()->{if(!isCurrentContent(generation)||engine==0||contentChanging)return;String text=NativeBridge.domains(engine);main.post(()->{if(isCurrentContent(generation)&&!contentChanging)data.setText("Domains\n"+pretty(text)+"\n\nNative resources\n"+pretty(lastStatus.toString()));});});
        });
        trackDialog(new MenuPanel.Builder(this).setTitle("N64 Memory Inspector").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private String pretty(String text){try{return new JSONObject(text).toString(2);}catch(Exception e){try{return new JSONArray(text).toString(2);}catch(Exception ignored){return text;}}}
    private void showImportExport(){
        LinearLayout view=column();button(view,"Export native save state",()->exportFile("state","BadN64-state.bn64"));button(view,"Import native save state",()->pick("state"));
        button(view,"Export cartridge saves / controller paks",()->exportFile("sram","BadN64-save-memory.srm"));button(view,"Import cartridge saves / controller paks",()->pick("sram"));
        button(view,"Export cartridge ROM (.z64)",()->exportFile("rom","BadN64-cartridge.z64"));
        button(view,"Export Blast History",()->exportFile("history","BadN64-blast-history.json"));button(view,"Export harvested results",()->exportFile("harvest","BadN64-harvest.bnh"));button(view,"Import harvested results",()->pick("harvest"));
        label(view,"Export always creates a new document. BadN64 never opens the original ROM for writing.");
        trackDialog(new MenuPanel.Builder(this).setTitle("Import / export").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void pick(String kind){
        if(destroyed)return;
        if(!kind.equals("rom")&&(!loaded||contentChanging)){showError("No content loaded","Open Nintendo 64 content first.");return;}
        pendingImport=kind;pendingImportGeneration=contentSession.current();
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(intent,PICK_DOCUMENT);}catch(Exception e){pendingImport=null;pendingImportGeneration=-1;showError("Open document",e.toString());}
    }
    private void exportFile(String kind,String filename){
        if(!loaded||contentChanging){showError("No content loaded","Open Nintendo 64 content first.");return;}
        long generation=contentSession.current();
        io.execute(()->{try{
            if(!isCurrentContent(generation)||engine==0)return;
            byte[] bytes=kind.equals("state")?NativeBridge.exportState(engine):NativeBridge.exportData(engine,kind);
            if(bytes==null||bytes.length==0)throw new IllegalStateException("No "+kind+" data is available.");
            main.post(()->{
                if(!isCurrentContent(generation)||contentChanging)return;
                pendingExport=bytes;pendingExportGeneration=generation;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,filename);
                try{startActivityForResult(intent,EXPORT_DOCUMENT);}catch(Exception e){pendingExport=null;pendingExportGeneration=-1;showError("Export",e.toString());}
            });
        }catch(Throwable e){main.post(()->{if(isCurrentContent(generation))showError("Export",e.toString());});}});
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null){
            if(request==PICK_DOCUMENT){pendingImport=null;pendingImportGeneration=-1;}
            if(request==EXPORT_DOCUMENT){pendingExport=null;pendingExportGeneration=-1;}
            if(request==PICK_ROM_FOLDER)pendingFolderGeneration=-1;
            return;
        }
        Uri uri=data.getData();
        if(request==PICK_ROM_FOLDER){
            long generation=pendingFolderGeneration;pendingFolderGeneration=-1;
            if(!isCurrentContent(generation))return;
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);if(!DocumentsContract.isTreeUri(uri))throw new IllegalArgumentException("The selected location is not a document folder.");prefs.edit().putString("library.tree",uri.toString()).apply();libraryPath.clear();libraryPath.add(DocumentsContract.buildDocumentUriUsingTree(uri,DocumentsContract.getTreeDocumentId(uri)));showLibraryFolder();}
            catch(Exception e){showError("ROM Folder",e.getMessage()==null?e.toString():e.getMessage());}
            return;
        }
        if(request==PICK_DOCUMENT){
            String kind=pendingImport;long generation=pendingImportGeneration;pendingImport=null;pendingImportGeneration=-1;
            // An old or unclaimed picker result must never be applied to a different cartridge.
            if(kind==null||!isCurrentContent(generation))return;
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            if(kind.equals("rom")){openRomDocument(uri,null);return;}
            io.execute(()->{try{
                if(!isCurrentContent(generation)||engine==0)return;
                byte[] bytes;try(InputStream input=getContentResolver().openInputStream(uri)){if(input==null)throw new IllegalStateException("The selected document could not be opened.");bytes=readLimited(input,MAX_DOCUMENT,generation);}
                if(!isCurrentContent(generation))return;
                String error=kind.equals("state")?NativeBridge.importState(engine,bytes):NativeBridge.importData(engine,kind,bytes);
                main.post(()->{if(isCurrentContent(generation)&&error!=null&&!error.isEmpty())showError("Import",error);});
            }catch(Throwable e){main.post(()->{if(isCurrentContent(generation))showError("Open document",e.getMessage()==null?e.toString():e.getMessage());});}});
        }else if(request==EXPORT_DOCUMENT){
            byte[] bytes=pendingExport;long generation=pendingExportGeneration;pendingExport=null;pendingExportGeneration=-1;
            if(bytes==null||!isCurrentContent(generation))return;
            io.execute(()->{try{
                if(!isCurrentContent(generation))return;
                try(OutputStream output=getContentResolver().openOutputStream(uri,"w")){if(output==null)throw new IllegalStateException("Could not create the export document.");output.write(bytes);}
            }catch(Exception e){main.post(()->{if(isCurrentContent(generation))showError("Export",e.toString());});}});
        }
    }
    private void loadRom(byte[] bytes,String name,Uri source,String entry,long generation){
        if(!isCurrentContent(generation)||engine==0)return;
        String error=NativeBridge.loadRom(engine,bytes,name);
        main.post(()->{
            if(!isCurrentContent(generation))return;
            contentChanging=false;
            if(error!=null&&!error.isEmpty()){dispatchPause();showError("Load ROM",error);return;}
            loaded=true;romName=name;lastError="";lastStatus=json("quickStateAvailable",false);prefs.edit().putBoolean("rtc.auto",false).apply();recordRecent(source,name,entry);
            closeMenus();applyRtc();applyRewind();applySpeed();applyDisplay();dispatchPause();dispatchAudio();updateMenuPresentation();
        });
    }
    private String documentName(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "Nintendo 64 ROM";}
    private byte[] readLimited(InputStream in,int limit)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]buffer=new byte[16384];int n,total=0;while((n=in.read(buffer))!=-1){total+=n;if(total>limit)throw new IllegalArgumentException("This document exceeds the 64 MiB safety limit.");out.write(buffer,0,n);}return out.toByteArray();}
    private byte[] readLimited(InputStream in,int limit,long generation)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]buffer=new byte[16384];int n,total=0;while(true){if(!isCurrentContent(generation))throw new java.util.concurrent.CancellationException("Content request superseded.");n=in.read(buffer);if(n==-1)break;total+=n;if(total>limit)throw new IllegalArgumentException("This document exceeds the 64 MiB safety limit.");out.write(buffer,0,n);}return out.toByteArray();}
    private List<String> zipRomNames(byte[] bytes)throws Exception{List<String>names=new ArrayList<>();try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;while((e=zip.getNextEntry())!=null){String n=e.getName().toLowerCase(Locale.ROOT);if(!e.isDirectory()&&(n.endsWith(".z64")||n.endsWith(".n64")||n.endsWith(".v64")))names.add(e.getName());if(names.size()>100)break;}}return names;}
    private byte[] zipRom(byte[]bytes,String entry,long generation)throws Exception{try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;while((e=zip.getNextEntry())!=null){if(!isCurrentContent(generation))throw new java.util.concurrent.CancellationException("Content request superseded.");if(e.getName().equals(entry))return readLimited(zip,MAX_DOCUMENT,generation);}}throw new IllegalArgumentException("ROM entry was not found in the ZIP.");}
    private void chooseZip(byte[] archive,List<String> names,Uri source,long generation){
        if(!isCurrentContent(generation))return;
        boolean[] selected={false};
        MenuPanel chooser=new MenuPanel.Builder(this).setTitle("Select ROM from ZIP").setKeepOpen(true).setItems(names.toArray(new String[0]),(dialog,index)->{
            if(!isCurrentContent(generation))return;
            selected[0]=true;dialog.dismiss();
            io.execute(()->{try{
                if(!isCurrentContent(generation))return;
                String name=names.get(index);loadRom(zipRom(archive,name,generation),name,source,name,generation);
            }catch(Throwable e){main.post(()->{if(isCurrentContent(generation)){contentChanging=false;dispatchPause();showError("Load ZIP ROM",e.toString());}});}});
        }).setNegativeButton("Cancel",null).create();
        trackDialog(chooser,()->{if(!selected[0]&&isCurrentContent(generation)){contentChanging=false;dispatchPause();updateBlastAvailability();}});
    }
    private void vibrate(){if(!prefs.getBoolean("vibration",true)||vibrator==null||!vibrator.hasVibrator())return;try{vibrator.vibrate(VibrationEffect.createOneShot(12,VibrationEffect.DEFAULT_AMPLITUDE));}catch(Exception ignored){}}
    private void sendButtons(){
        int mask=touchMask;
        for(Set<Integer> keys:padKeys.values())for(int key:keys)mask|=keyBit(key);
        for(int axes:padAxes.values())mask|=axes;
        if(dialogs>0||editingControls||contentChanging||!resumed)mask=0;
        if(mask==sentMask)return;
        sentMask=mask;int buttons=mask;long generation=contentSession.current();
        if(engineReady&&!destroyed)io.execute(()->{if(engine!=0&&isCurrentContent(generation))NativeBridge.setButtons(engine,buttons);});
    }
    private void sendStick(){
        int x=touchStickX,y=touchStickY;long strength=(long)x*x+(long)y*y;
        for(int[] stick:padSticks.values()){
            long candidate=(long)stick[0]*stick[0]+(long)stick[1]*stick[1];
            if(candidate>strength){x=stick[0];y=stick[1];strength=candidate;}
        }
        int keyboardX=0,keyboardY=0;
        for(Set<Integer> keys:padKeys.values()){
            if(keys.contains(KeyEvent.KEYCODE_A))keyboardX-=32767;
            if(keys.contains(KeyEvent.KEYCODE_D))keyboardX+=32767;
            if(keys.contains(KeyEvent.KEYCODE_W))keyboardY-=32767;
            if(keys.contains(KeyEvent.KEYCODE_S))keyboardY+=32767;
        }
        keyboardX=Math.max(-32767,Math.min(32767,keyboardX));keyboardY=Math.max(-32767,Math.min(32767,keyboardY));
        if(keyboardX!=0&&keyboardY!=0){keyboardX=Math.round(keyboardX*.70710678f);keyboardY=Math.round(keyboardY*.70710678f);}
        if((long)keyboardX*keyboardX+(long)keyboardY*keyboardY>strength){x=keyboardX;y=keyboardY;}
        if(dialogs>0||editingControls||contentChanging||!resumed){x=0;y=0;}
        if(x==sentStickX&&y==sentStickY)return;
        sentStickX=x;sentStickY=y;int stickX=x,stickY=y;long generation=contentSession.current();
        if(engineReady&&!destroyed)io.execute(()->{if(engine!=0&&isCurrentContent(generation))NativeBridge.setStick(engine,stickX,stickY);});
    }
    private void sendRewind(){boolean held=touchRewind;for(Set<Integer>keys:rewindKeys.values())held|=!keys.isEmpty();for(boolean value:rewindAxes.values())held|=value;if(dialogs>0||editingControls||contentChanging||!resumed)held=false;if(held==sentRewind)return;sentRewind=held;updateBlastAvailability();command("rewind",json("held",held),null);}
    private void sendFastForward(){boolean held=touchFastForward;for(Set<Integer>keys:fastForwardKeys.values())held|=!keys.isEmpty();for(boolean value:fastForwardAxes.values())held|=value;if(dialogs>0||editingControls||contentChanging||!resumed)held=false;if(held==sentFastForward)return;sentFastForward=held;command("fast_forward",json("held",held),null);}
    private void releaseHeldInputs(){controls.release();padKeys.clear();padAxes.clear();padSticks.clear();rewindKeys.clear();rewindAxes.clear();fastForwardKeys.clear();fastForwardAxes.clear();touchMask=0;touchStickX=0;touchStickY=0;touchRewind=false;touchFastForward=false;sendButtons();sendStick();sendRewind();sendFastForward();}
    private boolean analogKey(int key){return key==KeyEvent.KEYCODE_W||key==KeyEvent.KEYCODE_A||key==KeyEvent.KEYCODE_S||key==KeyEvent.KEYCODE_D;}
    private int keyBit(int key){
        switch(key){
            case KeyEvent.KEYCODE_DPAD_UP:return ControlsView.UP;
            case KeyEvent.KEYCODE_DPAD_DOWN:return ControlsView.DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT:return ControlsView.LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT:return ControlsView.RIGHT;
            case KeyEvent.KEYCODE_BUTTON_A:case KeyEvent.KEYCODE_Z:return ControlsView.A;
            case KeyEvent.KEYCODE_BUTTON_B:case KeyEvent.KEYCODE_X:return ControlsView.B;
            case KeyEvent.KEYCODE_BUTTON_X:case KeyEvent.KEYCODE_J:return ControlsView.C_LEFT;
            case KeyEvent.KEYCODE_BUTTON_Y:case KeyEvent.KEYCODE_I:return ControlsView.C_UP;
            case KeyEvent.KEYCODE_BUTTON_C:case KeyEvent.KEYCODE_L:return ControlsView.C_RIGHT;
            case KeyEvent.KEYCODE_BUTTON_Z:case KeyEvent.KEYCODE_K:return ControlsView.C_DOWN;
            case KeyEvent.KEYCODE_BUTTON_L1:case KeyEvent.KEYCODE_Q:return ControlsView.L;
            case KeyEvent.KEYCODE_BUTTON_R1:case KeyEvent.KEYCODE_E:return ControlsView.R;
            case KeyEvent.KEYCODE_BUTTON_L2:case KeyEvent.KEYCODE_SHIFT_LEFT:case KeyEvent.KEYCODE_SHIFT_RIGHT:return ControlsView.Z;
            case KeyEvent.KEYCODE_BUTTON_START:case KeyEvent.KEYCODE_ENTER:return ControlsView.START;
            default:return 0;
        }
    }
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(e.getKeyCode()==KeyEvent.KEYCODE_BACK){if(e.getAction()==KeyEvent.ACTION_UP)handleBack();return true;}
        if(dialogs>0||editingControls)return super.dispatchKeyEvent(e);
        if(e.getKeyCode()==KeyEvent.KEYCODE_BUTTON_SELECT||e.getKeyCode()==KeyEvent.KEYCODE_R){Set<Integer>keys=rewindKeys.computeIfAbsent(e.getDeviceId(),id->new HashSet<>());if(e.getAction()==KeyEvent.ACTION_DOWN)keys.add(e.getKeyCode());else if(e.getAction()==KeyEvent.ACTION_UP)keys.remove(e.getKeyCode());sendRewind();return true;}
        if(e.getKeyCode()==KeyEvent.KEYCODE_BUTTON_R2||e.getKeyCode()==KeyEvent.KEYCODE_F){Set<Integer>keys=fastForwardKeys.computeIfAbsent(e.getDeviceId(),id->new HashSet<>());if(e.getAction()==KeyEvent.ACTION_DOWN)keys.add(e.getKeyCode());else if(e.getAction()==KeyEvent.ACTION_UP)keys.remove(e.getKeyCode());sendFastForward();return true;}
        if(keyBit(e.getKeyCode())!=0||analogKey(e.getKeyCode())){Set<Integer>keys=padKeys.computeIfAbsent(e.getDeviceId(),id->new HashSet<>());if(e.getAction()==KeyEvent.ACTION_DOWN)keys.add(e.getKeyCode());else if(e.getAction()==KeyEvent.ACTION_UP)keys.remove(e.getKeyCode());sendButtons();sendStick();return true;}
        return super.dispatchKeyEvent(e);
    }
    private float axis(MotionEvent e,int axis){float value=e.getAxisValue(axis);InputDevice d=e.getDevice();InputDevice.MotionRange range=d==null?null:d.getMotionRange(axis,e.getSource());float flat=range==null?.15f:Math.max(.15f,range.getFlat());return Math.abs(value)>flat?Math.max(-1,Math.min(1,value)):0;}
    private int rightAxis(MotionEvent e,int primary,int fallback){InputDevice device=e.getDevice();return device!=null&&device.getMotionRange(primary,e.getSource())!=null?primary:fallback;}
    @Override public boolean onGenericMotionEvent(MotionEvent e){
        if((e.getSource()&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK&&e.getAction()==MotionEvent.ACTION_MOVE){
            float x=axis(e,MotionEvent.AXIS_X),y=axis(e,MotionEvent.AXIS_Y),hatX=axis(e,MotionEvent.AXIS_HAT_X),hatY=axis(e,MotionEvent.AXIS_HAT_Y);
            float cX=axis(e,rightAxis(e,MotionEvent.AXIS_Z,MotionEvent.AXIS_RX)),cY=axis(e,rightAxis(e,MotionEvent.AXIS_RZ,MotionEvent.AXIS_RY));int mask=0;
            if(hatX<-.35f)mask|=ControlsView.LEFT;else if(hatX>.35f)mask|=ControlsView.RIGHT;
            if(hatY<-.35f)mask|=ControlsView.UP;else if(hatY>.35f)mask|=ControlsView.DOWN;
            if(cX<-.35f)mask|=ControlsView.C_LEFT;else if(cX>.35f)mask|=ControlsView.C_RIGHT;
            if(cY<-.35f)mask|=ControlsView.C_UP;else if(cY>.35f)mask|=ControlsView.C_DOWN;
            if(axis(e,MotionEvent.AXIS_LTRIGGER)>.5f)mask|=ControlsView.Z;
            padAxes.put(e.getDeviceId(),mask);padSticks.put(e.getDeviceId(),new int[]{Math.round(x*32767),Math.round(y*32767)});
            fastForwardAxes.put(e.getDeviceId(),axis(e,MotionEvent.AXIS_RTRIGGER)>.5f);sendButtons();sendStick();sendFastForward();return true;
        }return super.onGenericMotionEvent(e);
    }
    @Override public void onInputDeviceAdded(int id){}
    @Override public void onInputDeviceChanged(int id){}
    @Override public void onInputDeviceRemoved(int id){padKeys.remove(id);padAxes.remove(id);padSticks.remove(id);rewindKeys.remove(id);rewindAxes.remove(id);fastForwardKeys.remove(id);fastForwardAxes.remove(id);sendButtons();sendStick();sendRewind();sendFastForward();}
    private void immersive(){
        boolean fullscreen=dialogs==0&&(loaded||editingControls);
        if(fullscreen)getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c=getWindow().getInsetsController();if(c!=null){if(fullscreen)c.hide(WindowInsets.Type.systemBars());else c.show(WindowInsets.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
        }else{
            int flags=View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            if(fullscreen)flags|=View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
        if(root!=null)root.requestApplyInsets();
    }
    @Override protected void onResume(){super.onResume();resumed=true;hasAudioFocus=audioManager.requestAudioFocus(focusRequest)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;dispatchPause();dispatchAudio();immersive();}
    @Override protected void onPause(){resumed=false;releaseHeldInputs();dispatchPause();dispatchAudio();audioManager.abandonAudioFocusRequest(focusRequest);super.onPause();}
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);controls.reload();immersive();}
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)immersive();else if(controls!=null)releaseHeldInputs();}
    @Override public void onBackPressed(){handleBack();}
    @Override protected void onDestroy(){requestContentStop();destroyed=true;contentSession.begin();engineReady=false;main.removeCallbacksAndMessages(null);inputManager.unregisterInputDeviceListener(this);if(Build.VERSION.SDK_INT>=33&&backCallback!=null)getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);io.execute(()->{if(engine!=0){NativeBridge.destroy(engine);engine=0;}});io.shutdown();super.onDestroy();}
    private int dp(float value){return (int)(getResources().getDisplayMetrics().density*value+.5f);}
}
