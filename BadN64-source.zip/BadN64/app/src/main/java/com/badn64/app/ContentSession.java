package com.badn64.app;

import java.util.concurrent.atomic.AtomicLong;

/** Invalidates pending cartridge work when another Open or Close is requested. */
final class ContentSession {
    private final AtomicLong generation=new AtomicLong();
    long begin(){return generation.incrementAndGet();}
    long current(){return generation.get();}
    boolean isCurrent(long request){return generation.get()==request;}
}
