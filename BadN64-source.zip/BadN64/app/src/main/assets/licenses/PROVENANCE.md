# BadN64 source provenance

BadN64 continues the native menu, RTC and state/rewind design from BadGenesis:
https://github.com/Pappoliver681/BadGenesis

N64 core: https://github.com/libretro/parallel-n64

Pinned commit: `862071a8b786224905a763e8b15bdcaf75739341`

Pinned root tree: `b9ad8f8f6d00277e84f2ba63228712e0d7e9bf9d`

`tools/fetch-core.py` obtains the exact source, verifies every tracked file and reconstructs the pinned Git tree. A complete archived checkout also verifies without Git metadata. The pinned source has no submodules. `tools/build-core.sh` builds an isolated copy for Android arm64-v8a. Upstream copyright and license headers are preserved.

Runtime: pure MIPS interpreter, synchronous Angrylion software renderer and cxd4 RSP. BadN64's native worker owns libretro execution and logical live-memory corruption. RDRAM's byte adapter translates host word-swapped memory. Save memory is writable; the canonical ROM and original document are read-only. No browser emulator is used.

BadN64 supplements core serialization with save-memory, framebuffer, frontend audio phase and RTC metadata. The public serializer omits Angrylion's private hidden bits/TMEM/tile state and cxd4's private vector/pipeline state. Restored in-flight RDP/RSP operations may show graphics glitches. Exact game execution after state restore has not been verified.

Licenses retained in the pinned source:

- `mupen64plus-core/LICENSES`: Mupen64Plus GPLv2 and component notices.
- `mupen64plus-rsp-cxd4/COPYING`: CC0 1.0 Universal.
- `mupen64plus-rsp-hle/LICENSES`: upstream terms including GNU GPLv2 text.
- Individual copyright and license headers throughout the source.

The build stages notices under `assets/licenses/`. Complete corresponding source must accompany binary distribution. Standalone RTC/adapter tests do not establish N64 game compatibility or Android speed.
