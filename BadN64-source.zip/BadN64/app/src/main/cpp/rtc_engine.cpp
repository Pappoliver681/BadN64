#include "rtc_engine.h"

#include <algorithm>
#include <cerrno>
#include <fcntl.h>
#include <iomanip>
#include <random>
#include <sstream>
#include <stdexcept>
#include <unordered_set>
#include <unistd.h>

namespace badn64 {
namespace {

uint64_t freshEntropy() {
    // Android's kernel entropy source is independent of emulator timing and
    // display refresh. Never substitute a fixed seed or clock-only seed.
    const int fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (fd < 0) throw std::runtime_error("Cannot open the system random source.");
    uint64_t value = 0;
    auto* bytes = reinterpret_cast<uint8_t*>(&value);
    size_t done = 0;
    while (done < sizeof(value)) {
        const ssize_t count = read(fd, bytes + done, sizeof(value) - done);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) {
            close(fd);
            throw std::runtime_error("Cannot read the system random source.");
        }
        done += static_cast<size_t>(count);
    }
    close(fd);
    return value;
}

// std::mt19937_64 is specified by C++; the rejection sampler below avoids
// implementation-specific uniform_int_distribution mappings and modulo bias.
class Random {
public:
    explicit Random(uint64_t seed) : engine_(seed) {}
    uint64_t next() { return engine_(); }
    uint64_t bounded(uint64_t bound) {
        if (!bound) throw std::logic_error("Empty random selection.");
        const uint64_t threshold = -bound % bound;
        uint64_t value;
        do { value = next(); } while (value < threshold);
        return value % bound;
    }
private:
    std::mt19937_64 engine_;
};

uint32_t mutationWidth(MutationEngine engine) {
    if (engine == MutationEngine::Word32BE || engine == MutationEngine::MipsNop) return 4;
    if (engine == MutationEngine::Word16BE) return 2;
    return 1;
}

std::string jsonString(const std::string& value) {
    std::ostringstream out;
    out << '"';
    for (const unsigned char c : value) {
        switch (c) {
        case '"': out << "\\\""; break;
        case '\\': out << "\\\\"; break;
        case '\b': out << "\\b"; break;
        case '\f': out << "\\f"; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        default:
            if (c < 0x20) out << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                              << static_cast<unsigned>(c) << std::dec;
            else out << c;
        }
    }
    out << '"';
    return out.str();
}

std::string seedString(uint64_t seed) {
    std::ostringstream out;
    out << "0x" << std::hex << std::setw(16) << std::setfill('0') << seed;
    return out.str();
}

void writeRecordJson(std::ostream& out, const BlastRecord& record, bool includeUnits) {
    out << "{\"number\":" << record.number << ",\"frame\":" << record.frame
        << ",\"seed\":" << jsonString(seedString(record.seed))
        << ",\"random\":" << (record.random ? "true" : "false")
        << ",\"automatic\":" << (record.automatic ? "true" : "false")
        << ",\"active\":" << (record.active ? "true" : "false")
        << ",\"engine\":" << jsonString(mutationEngineId(record.engine))
        << ",\"operations\":" << record.operations
        << ",\"writes\":" << record.units.size() << ",\"domains\":[";
    bool separator = false;
    for (const auto& domain : record.domains) {
        if (separator) out << ',';
        separator = true;
        out << jsonString(domain);
    }
    out << ']';
    if (includeUnits) {
        out << ",\"units\":[";
        separator = false;
        for (const auto& unit : record.units) {
            if (separator) out << ',';
            separator = true;
            out << "{\"domain\":" << jsonString(unit.domain)
                << ",\"address\":" << unit.address
                << ",\"previous\":" << static_cast<unsigned>(unit.previous)
                << ",\"value\":" << static_cast<unsigned>(unit.value)
                << ",\"engine\":" << jsonString(mutationEngineId(unit.engine))
                << ",\"blast\":" << unit.blast << '}';
        }
        out << ']';
    }
    out << '}';
}

bool nopDomain(const std::string& id) { return id == "rdram" || id == "imem" || id == "rom"; }

} // namespace

const char* mutationEngineId(MutationEngine engine) {
    switch (engine) {
    case MutationEngine::BitFlip: return "bitflip";
    case MutationEngine::RandomByte: return "random";
    case MutationEngine::Add: return "add";
    case MutationEngine::Subtract: return "sub";
    case MutationEngine::Tilt: return "tilt";
    case MutationEngine::Zero: return "zero";
    case MutationEngine::FF: return "ff";
    case MutationEngine::Swap: return "swap";
    case MutationEngine::Word16BE: return "word16";
    case MutationEngine::Word32BE: return "word32";
    case MutationEngine::MipsNop: return "mips_nop";
    }
    return "bitflip";
}

bool parseMutationEngine(const std::string& id, MutationEngine& engine) {
    const MutationEngine engines[] = { MutationEngine::BitFlip, MutationEngine::RandomByte,
        MutationEngine::Add, MutationEngine::Subtract, MutationEngine::Tilt,
        MutationEngine::Zero, MutationEngine::FF, MutationEngine::Swap,
        MutationEngine::Word16BE, MutationEngine::Word32BE, MutationEngine::MipsNop };
    for (const auto candidate : engines) {
        if (id == mutationEngineId(candidate)) { engine = candidate; return true; }
    }
    if (id == "randombyte") { engine = MutationEngine::RandomByte; return true; }
    if (id == "subtract") { engine = MutationEngine::Subtract; return true; }
    if (id == "word16be" || id == "be16") { engine = MutationEngine::Word16BE; return true; }
    if (id == "word32be" || id == "be32") { engine = MutationEngine::Word32BE; return true; }
    return false;
}

RtcEngine::RtcEngine() {
    DomainConfig ram;
    ram.enabled = true;
    config_.emplace("rdram", ram);
    beginSession();
}

void RtcEngine::beginSession() {
    session_ = freshEntropy();
    if (!session_) session_ = 1;
    history_.clear();
    blastNumber_ = 0;
    frame_ = 0;
    autoEnabled_ = false;
    nextAutoFrame_ = autoInterval_;
    lastRandomSeed_ = 0;
    lastMessage_ = "RTC session ready.";
}

void RtcEngine::setDomains(std::vector<MemoryDomain> domains) {
    std::unordered_set<std::string> ids;
    for (const auto& domain : domains) {
        if (domain.id.empty() || !ids.insert(domain.id).second)
            throw std::invalid_argument("Memory domain IDs must be unique and nonempty.");
        if (domain.size && (!domain.read8 || (domain.writable && !domain.write8)))
            throw std::invalid_argument("Memory domains require live read/write callbacks.");
    }
    domains_ = std::move(domains);
}

void RtcEngine::setDomainConfig(const std::string& id, const DomainConfig& config) {
    if (id.empty()) throw std::invalid_argument("Missing memory domain ID.");
    if (config.end < config.start) throw std::invalid_argument("Address end precedes start.");
    for (const auto& exclusion : config.exclusions)
        if (exclusion.end < exclusion.start) throw std::invalid_argument("Invalid exclusion range.");
    config_[id] = config;
}

DomainConfig RtcEngine::domainConfig(const std::string& id) const {
    const auto found = config_.find(id);
    return found == config_.end() ? DomainConfig{} : found->second;
}

bool RtcEngine::setEngine(const std::string& id) {
    MutationEngine engine;
    if (!parseMutationEngine(id, engine)) {
        lastMessage_ = "Unknown corruption engine: " + id;
        return false;
    }
    engine_ = engine;
    return true;
}

void RtcEngine::setIntensity(uint32_t intensity) {
    intensity_ = std::max(1U, std::min(4096U, intensity));
}

void RtcEngine::setManualSeed(bool enabled, uint64_t seed) {
    manualSeed_ = enabled;
    seed_ = seed;
}

void RtcEngine::setAutoBlast(bool enabled, uint32_t intervalFrames) {
    autoEnabled_ = enabled;
    autoInterval_ = std::max(1U, intervalFrames);
    nextAutoFrame_ = frame_ + autoInterval_;
}

MemoryDomain* RtcEngine::findDomain(const std::string& id) {
    for (auto& domain : domains_) if (domain.id == id) return &domain;
    return nullptr;
}

const MemoryDomain* RtcEngine::findDomain(const std::string& id) const {
    for (const auto& domain : domains_) if (domain.id == id) return &domain;
    return nullptr;
}

std::vector<RtcEngine::LegalSpan> RtcEngine::legalSpans(const MemoryDomain& domain,
        const DomainConfig& config, uint32_t width) const {
    std::vector<LegalSpan> result;
    if (!domain.size || !domain.writable || !config.enabled || !width) return result;
    const uint64_t low = config.start;
    const uint64_t high = std::min<uint64_t>(config.end, domain.size - 1);
    if (low > high) return result;
    std::vector<AddressRange> excluded = config.exclusions;
    std::sort(excluded.begin(), excluded.end(), [](const AddressRange& a, const AddressRange& b) {
        return a.start < b.start;
    });
    auto add = [&](uint64_t first, uint64_t last) {
        if (first > last || last - first + 1 < width) return;
        first = ((first + width - 1) / width) * width;
        if (first > last || last - first + 1 < width) return;
        const uint64_t count = (last - width + 1 - first) / width + 1;
        result.push_back({static_cast<uint32_t>(first), count});
    };
    uint64_t next = low;
    for (const auto& exclusion : excluded) {
        if (exclusion.end < next || exclusion.start > high) continue;
        if (exclusion.start > next) add(next, exclusion.start - 1ULL);
        next = std::max<uint64_t>(next, static_cast<uint64_t>(exclusion.end) + 1);
        if (next > high) break;
    }
    if (next <= high) add(next, high);
    return result;
}

BlastResult RtcEngine::blast(bool automatic) {
    BlastRecord record;
    record.number = blastNumber_ + 1;
    record.frame = frame_;
    record.engine = engine_;
    record.automatic = automatic;
    record.random = !manualSeed_;
    const uint32_t width = mutationWidth(engine_);
    std::vector<EligibleDomain> eligible;
    for (auto& domain : domains_) {
        if (engine_ == MutationEngine::MipsNop && !nopDomain(domain.id)) continue;
        auto spans = legalSpans(domain, domainConfig(domain.id), width);
        uint64_t count = 0;
        for (const auto& span : spans) count += span.count;
        if (count) {
            eligible.push_back({&domain, std::move(spans), count});
            record.domains.push_back(domain.id);
        }
    }
    if (eligible.empty()) {
        lastMessage_ = engine_ == MutationEngine::MipsNop
            ? "MIPS NOP requires an enabled RDRAM, RSP IMEM or ROM working-copy range with a full aligned instruction."
            : "No writable addresses remain in the selected domains, ranges and exclusions.";
        return {false, 0, 0, 0, lastMessage_};
    }
    try {
        if (manualSeed_) record.seed = seed_;
        else {
            do { record.seed = freshEntropy(); } while (record.seed == lastRandomSeed_);
            lastRandomSeed_ = record.seed;
        }
        Random random(record.seed);
        record.units.reserve(static_cast<size_t>(intensity_) * std::max(width, 2U));
        auto pick = [&](const EligibleDomain& selected) {
            uint64_t index = random.bounded(selected.count);
            for (const auto& span : selected.spans) {
                if (index < span.count)
                    return static_cast<uint32_t>(span.first + index * width);
                index -= span.count;
            }
            throw std::logic_error("Invalid legal address selection.");
        };
        auto write = [&](MemoryDomain& domain, uint32_t address, uint8_t value) {
            if (address >= domain.size) throw std::logic_error("RTC address escaped its live domain.");
            const uint8_t previous = domain.read8(address);
            // Record first so even a throwing adapter can be rolled back.
            record.units.push_back({domain.id, address, previous, value, engine_, record.number});
            domain.write8(address, value);
            // Some hardware domains discard unimplemented bits.
            // History/replay must record the accepted live value.
            record.units.back().value = domain.read8(address);
        };
        for (uint32_t operation = 0; operation < intensity_; ++operation) {
            const auto& selected = eligible[static_cast<size_t>(random.bounded(eligible.size()))];
            auto& domain = *selected.domain;
            const uint32_t address = pick(selected);
            const uint8_t previous = domain.read8(address);
            uint8_t value = previous;
            switch (engine_) {
            case MutationEngine::BitFlip:
                value = static_cast<uint8_t>(previous ^ (1U << random.bounded(8))); break;
            case MutationEngine::RandomByte:
                value = static_cast<uint8_t>(random.bounded(256)); break;
            case MutationEngine::Add:
                value = static_cast<uint8_t>(previous + 1 + random.bounded(31)); break;
            case MutationEngine::Subtract:
                value = static_cast<uint8_t>(previous - 1 - random.bounded(31)); break;
            case MutationEngine::Tilt: {
                const int delta = static_cast<int>(1 + random.bounded(4));
                value = static_cast<uint8_t>(previous + (random.bounded(2) ? delta : -delta));
                break;
            }
            case MutationEngine::Zero: value = 0; break;
            case MutationEngine::FF: value = 255; break;
            case MutationEngine::Swap: {
                const uint32_t other = pick(selected);
                const uint8_t otherValue = domain.read8(other);
                write(domain, address, otherValue);
                write(domain, other, previous);
                ++record.operations;
                continue;
            }
            case MutationEngine::Word16BE: {
                const uint16_t word = static_cast<uint16_t>(random.bounded(65536));
                write(domain, address, static_cast<uint8_t>(word >> 8));
                write(domain, address + 1, static_cast<uint8_t>(word));
                ++record.operations;
                continue;
            }
            case MutationEngine::Word32BE:
            case MutationEngine::MipsNop: {
                // sll $zero, $zero, 0 is the four-byte MIPS NOP instruction.
                const uint32_t word = engine_ == MutationEngine::MipsNop
                    ? 0 : static_cast<uint32_t>(random.next());
                for (uint32_t byte = 0; byte < 4; ++byte)
                    write(domain, address + byte, static_cast<uint8_t>(word >> (24 - byte * 8)));
                ++record.operations;
                continue;
            }
            }
            write(domain, address, value);
            ++record.operations;
        }
        return remember(std::move(record));
    } catch (const std::exception& error) {
        for (auto it = record.units.rbegin(); it != record.units.rend(); ++it) {
            auto* domain = findDomain(it->domain);
            if (domain && it->address < domain->size) {
                try { domain->write8(it->address, it->previous); } catch (...) { }
            }
        }
        lastMessage_ = std::string("Blast failed: ") + error.what();
        return {false, 0, 0, 0, lastMessage_};
    }
}

BlastResult RtcEngine::remember(BlastRecord record) {
    blastNumber_ = record.number;
    const BlastResult result{true, record.number, record.operations,
        static_cast<uint32_t>(record.units.size()),
        std::string(record.automatic ? "Auto Blast #" : "Blast #") + std::to_string(record.number)
        + " at emulated frame " + std::to_string(record.frame) + ": "
        + std::to_string(record.operations) + " mutations, " + std::to_string(record.units.size()) + " byte writes."};
    lastMessage_ = result.message;
    history_.push_back(std::move(record));
    pruneHistory();
    return result;
}

void RtcEngine::pruneHistory() {
    // Bounded independent of frame rate. Large histories cannot progressively
    // consume RAM forever when Auto Blast runs every emulated frame.
    constexpr size_t maximumRecords = 128;
    constexpr size_t maximumByteUnits = 131072;
    size_t units = 0;
    for (const auto& record : history_) units += record.units.size();
    size_t discard = 0;
    while (history_.size() - discard > maximumRecords
           || (units > maximumByteUnits && history_.size() - discard > 1)) {
        units -= history_[discard].units.size();
        ++discard;
    }
    if (discard) history_.erase(history_.begin(), history_.begin() + discard);
}

BlastResult RtcEngine::undoLastBlast() {
    for (auto record = history_.rbegin(); record != history_.rend(); ++record) {
        if (!record->active) continue;
        for (const auto& unit : record->units) {
            const auto* domain = findDomain(unit.domain);
            if (!domain || !domain->writable || unit.address >= domain->size) {
                lastMessage_ = "Undo is unavailable because its live memory domain changed.";
                return {false, 0, 0, 0, lastMessage_};
            }
        }
        for (auto unit = record->units.rbegin(); unit != record->units.rend(); ++unit)
            findDomain(unit->domain)->write8(unit->address, unit->previous);
        record->active = false;
        lastMessage_ = "Undid Blast #" + std::to_string(record->number) + ".";
        return {true, record->number, record->operations,
            static_cast<uint32_t>(record->units.size()), lastMessage_};
    }
    lastMessage_ = "No active blast remains to undo.";
    return {false, 0, 0, 0, lastMessage_};
}

BlastResult RtcEngine::onEmulatedFrame(uint64_t frame) {
    frame_ = frame;
    if (!autoEnabled_ || frame < nextAutoFrame_) return {};
    nextAutoFrame_ = frame + autoInterval_;
    return blast(true);
}

BlastResult RtcEngine::applyRecorded(const BlastRecord& source, bool requirePrevious) {
    if (source.units.empty() || source.units.size() > 4096U * 4U) {
        lastMessage_ = "The recorded blast has no writes or exceeds the maximum blast size.";
        return {false, 0, 0, 0, lastMessage_};
    }
    // Validate the whole import before touching any emulator memory. Duplicate
    // writes to one byte are checked against their sequential intermediate
    // values, which is essential for swaps and repeated-address blasts.
    std::unordered_map<std::string, uint8_t> simulated;
    for (const auto& unit : source.units) {
        const auto* domain = findDomain(unit.domain);
        if (!domain || !domain->writable || unit.address >= domain->size
            || (unit.engine == MutationEngine::MipsNop && !nopDomain(unit.domain))) {
            lastMessage_ = "Recorded corruption contains an invalid live-memory address.";
            return {false, 0, 0, 0, lastMessage_};
        }
        if (requirePrevious) {
            const auto key = unit.domain + ':' + std::to_string(unit.address);
            const auto found = simulated.find(key);
            const uint8_t current = found == simulated.end() ? domain->read8(unit.address) : found->second;
            if (current != unit.previous) {
                lastMessage_ = "Recorded corruption does not match this clean memory state.";
                return {false, 0, 0, 0, lastMessage_};
            }
            simulated[key] = unit.value;
        }
    }
    BlastRecord record = source;
    record.number = blastNumber_ + 1;
    record.frame = frame_;
    record.automatic = false;
    record.random = false;
    record.active = true;
    record.units.clear();
    record.domains.clear();
    try {
        record.units.reserve(source.units.size());
        for (const auto& unit : source.units) {
            auto* domain = findDomain(unit.domain);
            if (std::find(record.domains.begin(), record.domains.end(), unit.domain) == record.domains.end())
                record.domains.push_back(unit.domain);
            record.units.push_back({unit.domain, unit.address, domain->read8(unit.address),
                                    unit.value, unit.engine, record.number});
            domain->write8(unit.address, unit.value);
            record.units.back().value = domain->read8(unit.address);
        }
        return remember(std::move(record));
    } catch (const std::exception& error) {
        for (auto unit = record.units.rbegin(); unit != record.units.rend(); ++unit) {
            try { findDomain(unit->domain)->write8(unit->address, unit->previous); } catch (...) { }
        }
        lastMessage_ = std::string("Replay failed: ") + error.what();
        return {false, 0, 0, 0, lastMessage_};
    }
}

BlastResult RtcEngine::replay(uint64_t blastNumber, bool requirePrevious) {
    for (const auto& record : history_)
        if (record.number == blastNumber) {
            const BlastRecord copy = record; // remember() may reallocate history.
            return applyRecorded(copy, requirePrevious);
        }
    lastMessage_ = "The requested blast is no longer in history.";
    return {false, 0, 0, 0, lastMessage_};
}

RtcCheckpoint RtcEngine::checkpoint() const {
    RtcCheckpoint result;
    result.session = session_;
    result.frame = frame_;
    result.blastCursor = blastNumber_;
    for (const auto& record : history_) if (record.active) result.activeBlasts.push_back(record.number);
    return result;
}

void RtcEngine::onRestore(const RtcCheckpoint& checkpoint) {
    frame_ = checkpoint.frame;
    std::unordered_set<uint64_t> active(checkpoint.activeBlasts.begin(), checkpoint.activeBlasts.end());
    for (auto& record : history_)
        record.active = checkpoint.session == session_ && record.number <= checkpoint.blastCursor
            && record.frame <= checkpoint.frame && active.count(record.number) != 0;
    nextAutoFrame_ = frame_ + autoInterval_;
    lastMessage_ = "Native state restored at emulated frame " + std::to_string(frame_) + ".";
}

void RtcEngine::onRestore(uint64_t frame, uint64_t blastCursor) {
    frame_ = frame;
    for (auto& record : history_)
        if (record.number > blastCursor || record.frame > frame) record.active = false;
    nextAutoFrame_ = frame_ + autoInterval_;
    lastMessage_ = "Native state restored at emulated frame " + std::to_string(frame_) + ".";
}

std::string RtcEngine::domainsJson() const {
    std::ostringstream out;
    out << '[';
    bool separator = false;
    for (const auto& domain : domains_) {
        if (separator) out << ',';
        separator = true;
        out << "{\"id\":" << jsonString(domain.id) << ",\"name\":" << jsonString(domain.name)
            << ",\"size\":" << domain.size << ",\"writable\":" << (domain.writable ? "true" : "false")
            << ",\"persistent\":" << (domain.persistent ? "true" : "false")
            << ",\"endianness\":" << jsonString(domain.bigEndian ? "big" : "byte")
            << ",\"enabled\":" << (domainConfig(domain.id).enabled ? "true" : "false") << '}';
    }
    out << ']';
    return out.str();
}

std::string RtcEngine::configJson() const {
    std::ostringstream out;
    out << "{\"engine\":" << jsonString(mutationEngineId(engine_))
        << ",\"intensity\":" << intensity_ << ",\"manualSeed\":" << (manualSeed_ ? "true" : "false")
        << ",\"seed\":" << jsonString(seedString(seed_))
        << ",\"autoBlast\":" << (autoEnabled_ ? "true" : "false")
        << ",\"autoInterval\":" << autoInterval_ << ",\"domains\":[";
    bool separator = false;
    for (const auto& domain : domains_) {
        if (separator) out << ',';
        separator = true;
        const auto config = domainConfig(domain.id);
        out << "{\"id\":" << jsonString(domain.id) << ",\"enabled\":" << (config.enabled ? "true" : "false")
            << ",\"start\":" << config.start << ",\"end\":" << config.end << ",\"exclusions\":[";
        bool excludedSeparator = false;
        for (const auto& exclusion : config.exclusions) {
            if (excludedSeparator) out << ',';
            excludedSeparator = true;
            out << '[' << exclusion.start << ',' << exclusion.end << ']';
        }
        out << "]}";
    }
    out << "]}";
    return out.str();
}

std::string RtcEngine::historyJson(bool includeUnits) const {
    std::ostringstream out;
    out << '[';
    bool separator = false;
    for (const auto& record : history_) {
        if (separator) out << ',';
        separator = true;
        writeRecordJson(out, record, includeUnits);
    }
    out << ']';
    return out.str();
}

std::string RtcEngine::recordJson(uint64_t blastNumber) const {
    for (const auto& record : history_)
        if (record.number == blastNumber) {
            std::ostringstream out;
            writeRecordJson(out, record, true);
            return out.str();
        }
    return "null";
}

std::string RtcEngine::statusJson() const {
    std::ostringstream out;
    out << "{\"frame\":" << frame_ << ",\"blastCursor\":" << blastNumber_
        << ",\"autoBlast\":" << (autoEnabled_ ? "true" : "false")
        << ",\"autoInterval\":" << autoInterval_
        << ",\"engine\":" << jsonString(mutationEngineId(engine_))
        << ",\"intensity\":" << intensity_ << ",\"message\":" << jsonString(lastMessage_) << '}';
    return out.str();
}

} // namespace badn64
