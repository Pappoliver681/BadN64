#pragma once
#include "rtc_engine.h"
#include <algorithm>

namespace badn64 {
// Walk the actual low-level command stream before the renderer reads it.
// Commands retain their opcodes and lengths; geometry and color payloads
// remain genuine emulated RAM mutations, recorded at physical addresses.
inline std::vector<TargetRange> graphicsTargetRanges(const MemoryDomain& domain,
                                                     uint32_t start, uint32_t length) {
    std::vector<TargetRange> ranges;
    if (!domain.read8 || start >= domain.size) return ranges;
    const uint64_t end = uint64_t(start) + std::min<uint64_t>(length, domain.size - start);
    static constexpr unsigned sizes[64] = {
        8,8,8,8,8,8,8,8,32,48,96,112,96,112,160,176,
        8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,
        8,8,8,8,16,16,8,8,8,8,8,8,8,8,8,8,
        8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8
    };
    for (uint64_t at = start; at + 8 <= end;) {
        const unsigned op = domain.read8(static_cast<uint32_t>(at)) & 63u;
        const unsigned size = sizes[op];
        if (at + size > end) break;
        if (op >= 8 && op <= 15)
            ranges.push_back({domain.id, static_cast<uint32_t>(at + 8), static_cast<uint32_t>(at + 31)});
        else if (op == 0x24 || op == 0x25 || op == 0x36)
            ranges.push_back({domain.id, static_cast<uint32_t>(at + 1), static_cast<uint32_t>(at + 7)});
        else if (op >= 0x37 && op <= 0x3b)
            ranges.push_back({domain.id, static_cast<uint32_t>(at + 4), static_cast<uint32_t>(at + 7)});
        at += size;
    }
    return ranges;
}

inline std::vector<TargetRange> audioTargetRanges(const MemoryDomain& domain,
                                                 uint32_t start, uint32_t length) {
    if (start >= domain.size) return {};
    const uint32_t available = std::min(length, domain.size - start);
    if (!available) return {};
    return {{domain.id, start, start + available - 1}};
}
}
