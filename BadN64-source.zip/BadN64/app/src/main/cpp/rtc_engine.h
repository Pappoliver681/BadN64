#pragma once

#include <cstdint>
#include <functional>
#include <limits>
#include <string>
#include <unordered_map>
#include <vector>

namespace badn64 {

// All offsets are logical byte offsets. The core adapter owns physical byte
// swapping, instruction-cache invalidation and save-memory tracking. Call only on the
// emulator worker, while that worker owns the core; never from an Android UI
// thread. No savestate is created or reloaded by the corruption engine.
struct MemoryDomain {
    std::string id;
    std::string name;
    void* base = nullptr;
    uint32_t size = 0;
    bool writable = true;
    bool persistent = false;
    bool bigEndian = false;
    std::function<uint8_t(uint32_t)> read8;
    std::function<void(uint32_t, uint8_t)> write8;
};

struct AddressRange {
    uint32_t start = 0;
    uint32_t end = std::numeric_limits<uint32_t>::max(); // Inclusive.
};

struct DomainConfig {
    bool enabled = false;
    uint32_t start = 0;
    uint32_t end = std::numeric_limits<uint32_t>::max(); // Inclusive.
    std::vector<AddressRange> exclusions;
};

enum class MutationEngine {
    BitFlip, RandomByte, Add, Subtract, Tilt, Zero, FF, Swap,
    Word16BE, Word32BE, MipsNop
};

const char* mutationEngineId(MutationEngine engine);
bool parseMutationEngine(const std::string& id, MutationEngine& engine);

struct CorruptionUnit {
    std::string domain;
    uint32_t address = 0;
    uint8_t previous = 0;
    uint8_t value = 0;
    MutationEngine engine = MutationEngine::BitFlip;
    uint64_t blast = 0;
};

struct BlastRecord {
    uint64_t number = 0;
    uint64_t frame = 0;
    uint64_t seed = 0;
    bool random = true;
    bool automatic = false;
    bool active = true;
    MutationEngine engine = MutationEngine::BitFlip;
    uint32_t operations = 0;
    std::vector<std::string> domains;
    std::vector<CorruptionUnit> units;
};

struct BlastResult {
    bool applied = false;
    uint64_t number = 0;
    uint32_t operations = 0;
    uint32_t writes = 0;
    std::string message;
};

// A rewind/state snapshot keeps this metadata beside the full native core
// state. activeBlasts is required to also restore snapshots taken before Undo.
struct RtcCheckpoint {
    uint64_t session = 0;
    uint64_t frame = 0;
    uint64_t blastCursor = 0;
    std::vector<uint64_t> activeBlasts;
};

class RtcEngine {
public:
    RtcEngine();

    // Loading another ROM must begin a new session. Settings remain available,
    // but no undo record from an old ROM can affect its new live memory.
    void beginSession();
    void setDomains(std::vector<MemoryDomain> domains);
    const std::vector<MemoryDomain>& domains() const { return domains_; }
    void setDomainConfig(const std::string& id, const DomainConfig& config);
    DomainConfig domainConfig(const std::string& id) const;
    bool setEngine(const std::string& id);
    void setEngine(MutationEngine engine) { engine_ = engine; }
    void setIntensity(uint32_t intensity);
    void setManualSeed(bool enabled, uint64_t seed = 0);
    void setAutoBlast(bool enabled, uint32_t intervalFrames = 60);
    bool autoBlastEnabled() const { return autoEnabled_; }
    uint32_t autoBlastInterval() const { return autoInterval_; }
    bool autoDue(uint64_t frame) const { return autoEnabled_ && frame >= nextAutoFrame_; }
    void setFrame(uint64_t frame) { frame_ = frame; }
    uint64_t frame() const { return frame_; }

    BlastResult blast(bool automatic = false);
    BlastResult undoLastBlast();
    // Invoke exactly once after every emulated frame, never at display refresh.
    BlastResult onEmulatedFrame(uint64_t frame);
    // Replay writes from a kept blast against live memory. All addresses are
    // validated before any write. Optional previous-value matching prevents
    // applying the result to an unrelated clean state.
    BlastResult applyRecorded(const BlastRecord& source, bool requirePrevious = false);
    BlastResult replay(uint64_t blastNumber, bool requirePrevious = false);

    RtcCheckpoint checkpoint() const;
    void onRestore(const RtcCheckpoint& checkpoint);
    // For old snapshots without exact metadata: deactivate future undo records.
    void onRestore(uint64_t frame, uint64_t blastCursor);
    const std::vector<BlastRecord>& history() const { return history_; }

    std::string domainsJson() const;
    std::string configJson() const;
    std::string historyJson(bool includeUnits = false) const;
    std::string recordJson(uint64_t blastNumber) const;
    std::string statusJson() const;
    const std::string& lastMessage() const { return lastMessage_; }

private:
    struct LegalSpan { uint32_t first; uint64_t count; };
    struct EligibleDomain {
        MemoryDomain* domain;
        std::vector<LegalSpan> spans;
        uint64_t count;
    };
    MemoryDomain* findDomain(const std::string& id);
    const MemoryDomain* findDomain(const std::string& id) const;
    std::vector<LegalSpan> legalSpans(const MemoryDomain& domain,
                                    const DomainConfig& config, uint32_t width) const;
    BlastResult remember(BlastRecord record);
    void pruneHistory();

    std::vector<MemoryDomain> domains_;
    std::unordered_map<std::string, DomainConfig> config_;
    std::vector<BlastRecord> history_;
    MutationEngine engine_ = MutationEngine::BitFlip;
    uint32_t intensity_ = 24;
    bool manualSeed_ = false;
    uint64_t seed_ = 0;
    bool autoEnabled_ = false;
    uint32_t autoInterval_ = 60;
    uint64_t nextAutoFrame_ = 60;
    uint64_t frame_ = 0;
    uint64_t session_ = 0;
    uint64_t blastNumber_ = 0;
    uint64_t lastRandomSeed_ = 0;
    std::string lastMessage_;
};

} // namespace badn64
