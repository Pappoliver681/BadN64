#pragma once
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <map>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace badn64 {
// Small bounded parser for native menu command payloads. JSON is an interface
// format only; neither emulation nor memory corruption runs through JavaScript.
struct Json {
    enum Type { Null, Boolean, Number, String, Array, Object } type = Null;
    bool boolean = false;
    double number = 0;
    std::string string;
    std::vector<Json> array;
    std::map<std::string, Json> object;
    const Json& operator[](const std::string& key) const {
        static const Json empty;
        auto i = object.find(key); return i == object.end() ? empty : i->second;
    }
    bool has(const std::string& key) const { return object.count(key) != 0; }
    bool flag(bool fallback = false) const { return type == Boolean ? boolean : fallback; }
    int64_t integer(int64_t fallback = 0) const {
        if (type == String) {
            char* end = nullptr; auto n = std::strtoll(string.c_str(), &end, 0);
            return end && end != string.c_str() && !*end ? n : fallback;
        }
        if (type != Number || !std::isfinite(number) || number < double(std::numeric_limits<int64_t>::min()) || number >= -double(std::numeric_limits<int64_t>::min())) return fallback;
        return static_cast<int64_t>(number);
    }
    std::string text(const std::string& fallback = {}) const { return type == String ? string : fallback; }
    static Json parse(const std::string& source) {
        if (source.empty()) return Json{};
        if (source.size() > 1024 * 1024) throw std::runtime_error("Command is too large");
        size_t pos = 0; Json value = parseValue(source, pos, 0);
        white(source, pos); if (pos != source.size()) throw std::runtime_error("Invalid JSON command");
        return value;
    }
    static std::string quote(const std::string& value) {
        const char* digits = "0123456789abcdef"; std::string out = "\"";
        for (unsigned char c : value) {
            if (c == '"' || c == '\\') { out += '\\'; out += c; }
            else if (c < 32) { out += "\\u00"; out += digits[c >> 4]; out += digits[c & 15]; }
            else out += c;
        }
        return out + '"';
    }
private:
    static void white(const std::string& s, size_t& p) { while (p < s.size() && std::isspace(static_cast<unsigned char>(s[p]))) ++p; }
    static char take(const std::string& s, size_t& p) { if (p == s.size()) throw std::runtime_error("Incomplete JSON command"); return s[p++]; }
    static std::string parseString(const std::string& s, size_t& p) {
        if (take(s, p) != '"') throw std::runtime_error("Expected JSON string");
        std::string out;
        for (;;) {
            char c = take(s, p); if (c == '"') return out;
            if (static_cast<unsigned char>(c) < 32) throw std::runtime_error("Invalid JSON string");
            if (c != '\\') { out += c; continue; }
            c = take(s, p);
            switch (c) {
                case '"': case '\\': case '/': out += c; break;
                case 'b': out += '\b'; break; case 'f': out += '\f'; break;
                case 'n': out += '\n'; break; case 'r': out += '\r'; break; case 't': out += '\t'; break;
                case 'u': {
                    unsigned code = 0;
                    for (int i = 0; i < 4; ++i) {
                        char h = take(s, p); code <<= 4;
                        if (h >= '0' && h <= '9') code |= h - '0';
                        else if (h >= 'a' && h <= 'f') code |= h - 'a' + 10;
                        else if (h >= 'A' && h <= 'F') code |= h - 'A' + 10;
                        else throw std::runtime_error("Invalid Unicode escape");
                    }
                    if (code < 128) out += static_cast<char>(code);
                    else if (code < 2048) { out += static_cast<char>(0xc0 | code >> 6); out += static_cast<char>(0x80 | code & 63); }
                    else { out += static_cast<char>(0xe0 | code >> 12); out += static_cast<char>(0x80 | (code >> 6) & 63); out += static_cast<char>(0x80 | code & 63); }
                    break;
                }
                default: throw std::runtime_error("Invalid JSON escape");
            }
        }
    }
    static Json parseValue(const std::string& s, size_t& p, unsigned depth) {
        if (depth > 16) throw std::runtime_error("JSON command nesting is too deep");
        white(s, p); if (p == s.size()) throw std::runtime_error("Incomplete JSON command");
        Json value; char c = s[p];
        if (c == '"') { value.type = String; value.string = parseString(s, p); return value; }
        if (c == '[' || c == '{') {
            value.type = c == '[' ? Array : Object; ++p; white(s, p);
            char end = c == '[' ? ']' : '}';
            if (p < s.size() && s[p] == end) { ++p; return value; }
            for (;;) {
                white(s, p);
                if (value.type == Object) {
                    std::string key = parseString(s, p); white(s, p);
                    if (take(s, p) != ':') throw std::runtime_error("Expected JSON colon");
                    value.object[key] = parseValue(s, p, depth + 1);
                } else value.array.push_back(parseValue(s, p, depth + 1));
                white(s, p); char separator = take(s, p);
                if (separator == end) return value;
                if (separator != ',') throw std::runtime_error("Expected JSON separator");
            }
        }
        for (const std::string literal : {"true", "false", "null"}) {
            if (s.compare(p, literal.size(), literal) == 0) {
                p += literal.size(); value.type = literal == "null" ? Null : Boolean;
                value.boolean = literal == "true"; return value;
            }
        }
        size_t begin = p; if (s[p] == '-') ++p;
        while (p < s.size() && std::isdigit(static_cast<unsigned char>(s[p]))) ++p;
        if (p < s.size() && s[p] == '.') { ++p; while (p < s.size() && std::isdigit(static_cast<unsigned char>(s[p]))) ++p; }
        if (p < s.size() && (s[p] == 'e' || s[p] == 'E')) { ++p; if (p < s.size() && (s[p] == '+' || s[p] == '-')) ++p; while (p < s.size() && std::isdigit(static_cast<unsigned char>(s[p]))) ++p; }
        std::string token = s.substr(begin, p - begin); char* parsedEnd = nullptr;
        value.number = std::strtod(token.c_str(), &parsedEnd);
        if (token.empty() || !parsedEnd || *parsedEnd || !std::isfinite(value.number)) throw std::runtime_error("Invalid JSON number");
        value.type = Number; return value;
    }
};
}
