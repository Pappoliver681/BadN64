#pragma once
#include "rtc_engine.h"
#include <atomic>
#include <algorithm>
#include <condition_variable>
#include <chrono>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <stdexcept>
#include <thread>
#include <vector>

#ifdef __ANDROID__
#include <aaudio/AAudio.h>
#include <android/native_window.h>
#else
struct ANativeWindow;
struct AAudioStream;
#endif

namespace badn64 {
class NativeBackend {
public:
    explicit NativeBackend(std::string filesDirectory);
    ~NativeBackend();
    void requestStop();
    NativeBackend(const NativeBackend&) = delete;
    NativeBackend& operator=(const NativeBackend&) = delete;
    std::string loadRom(std::vector<uint8_t> bytes, std::string name);
    void attachSurface(ANativeWindow* window);
    void setButtons(uint16_t buttons) { heldButtons_.store(buttons, std::memory_order_relaxed); }
    void setStick(int x, int y) {
        heldStickX_.store(static_cast<int16_t>(std::max(-32767, std::min(32767, x))), std::memory_order_relaxed);
        heldStickY_.store(static_cast<int16_t>(std::max(-32767, std::min(32767, y))), std::memory_order_relaxed);
    }
    std::string command(std::string action, std::string json);
    std::string status();
    std::string domains();
    std::vector<uint8_t> exportState();
    std::string importState(std::vector<uint8_t> state);
    std::vector<uint8_t> exportData(std::string kind);
    std::string importData(std::string kind, std::vector<uint8_t> data);
    std::vector<uint8_t> readMemory(std::string domain, uint32_t start, uint32_t length);

    // libretro callbacks are exclusively used by the single native core worker.
    bool environment(unsigned command, void* data);
    void video(const void* pixels, unsigned width, unsigned height, size_t pitch);
    size_t audio(const int16_t* samples, size_t frames);
    int16_t input(unsigned port, unsigned device, unsigned index, unsigned id);
    void coreBuffer(unsigned kind, unsigned memoryId, uint32_t start, uint32_t length);
    int audioCallback(void* samples, int32_t frames);
    void audioError(int error);

private:
    // A RAM-only reverse delta reconstructs the preceding COMPLETE native
    // state. Manual saves use the BN64001Z container.
    struct Snapshot {
        uint64_t frame = 0;
        std::vector<uint8_t> bytes, keyframe;
    };
    struct PcmSegment {
        uint64_t frame = 0, firstSample = 0;
        std::vector<int16_t> samples; // Actual core PCM, interleaved L/R.
    };
    template<class Function> auto onWorker(Function function) -> decltype(function()) {
        using Result = decltype(function());
        if (std::this_thread::get_id() == worker_.get_id()) return function();
        auto task = std::make_shared<std::packaged_task<Result()>>(std::move(function));
        auto result = task->get_future();
        { std::lock_guard<std::mutex> guard(commandMutex_);
          if (stopping_.load()) throw std::runtime_error("The emulator has stopped");
          commands_.emplace_back([task] { (*task)(); }); }
        commandReady_.notify_one();
        if (result.wait_for(std::chrono::seconds(10)) != std::future_status::ready)
            throw std::runtime_error("The native core did not respond. Reopen BadN64 and restore recovery.");
        return result.get();
    }
    void workerLoop(std::promise<void> ready);
    void presentationLoop();
    void closeRomOnWorker();
    uint64_t requestStopGeneration();
    void configureDomains();
    void writeDomainByte(const std::string& domain, uint32_t address, uint8_t value);
    void captureRecovery(bool disk, bool automatic = false);
    void armTarget(bool automatic);
    void flushCodeWrites();
    std::string rtcConfigJson() const;
    std::string commandOnWorker(const std::string& action, const std::string& json);
    std::string statusOnWorker() const;
    std::vector<uint8_t> snapshot();
    void snapshotRaw(std::vector<uint8_t>& output);
    std::vector<uint8_t> compressState(const std::vector<uint8_t>& raw);
    std::string restore(const std::vector<uint8_t>& data, bool rewind);
    std::string restoreRaw(const std::vector<uint8_t>& raw, bool rewind);
    void captureRewind(const std::vector<uint8_t>* raw = nullptr);
    std::vector<uint8_t> reverseDelta(const std::vector<uint8_t>& previous, const std::vector<uint8_t>& next);
    void applyReverseDelta(const std::vector<uint8_t>& delta);
    size_t rewindAllocatedBytes() const;
    void clearRewind();
    void trimRewind();
    void recordRewindAudio(const int16_t* samples, size_t frames);
    void writeAudio(const int16_t* samples, size_t frames);
    void rewindTick();
    void endRewind();
    void persistSram();
    void loadSram();
    void openAudio();
    void closeAudio();
    void flushAudio(bool resetResampler = true);
    std::string statePath(unsigned slot) const;
    std::string recoveryPath() const;

    std::string filesDirectory_, romName_, romKey_, error_, message_;
    std::thread worker_, presentation_;
    std::atomic<bool> stopping_{false}, audioMuted_{true}, audioReopen_{false};
    std::mutex commandMutex_;
    std::condition_variable commandReady_;
    std::deque<std::function<void()>> commands_;
    std::atomic<uint16_t> heldButtons_{0};
    std::atomic<int16_t> heldStickX_{0}, heldStickY_{0};
    std::atomic<uint64_t> contentGeneration_{0};
    std::atomic<uint64_t> activeGeneration_{0};
    // Order atomic stop delivery with the fresh-load stop reset. This mutex
    // is never held while executing guest CPU/RSP/RDP instructions.
    std::mutex stopMutex_;
    bool loaded_ = false, paused_ = false, uiPaused_ = false, rewinding_ = false, audioEnabled_ = true;
    bool clockReset_ = true, harvester_ = false, harvestRunning_ = false;
    bool fastForwardHeld_ = false, rewindAudio_ = true, benchmarking_ = false;
    bool targetPending_ = false, pendingAutomatic_ = false, rdramDirty_ = false;
    std::string rtcTarget_ = "ram";
    std::string pendingVideoMode_ = "fast", sessionVideoMode_ = "fast";
    uint64_t targetRequestedFrame_ = 0;
    uint64_t frame_ = 0, harvestEndFrame_ = 0, renderedFrames_ = 0, lastRecoveryDiskFrame_ = 0;
    uint32_t harvestRunFrames_ = 60, rewindSeconds_ = 0, snapshotInterval_ = 10;
    double fps_ = 59.9227, sampleRate_ = 44100, measuredFps_ = 0, frameMilliseconds_ = 0;
    double fastForwardMultiplier_ = 2, rewindMultiplier_ = 2;
    double rewindPositionFrames_ = 0, rewindPcmCursor_ = -1, rewindOutputCarry_ = 0;
    unsigned pixelFormat_ = 2;
    std::vector<uint8_t> originalRom_, normalizedOriginal_, quickState_, harvesterClean_, lastKeptState_, recoveryState_;
    RtcEngine rtc_;
    std::deque<Snapshot> rewind_;
    std::deque<PcmSegment> rewindPcm_;
    size_t rewindBytes_ = 0;
    size_t rewindPcmBytes_ = 0;
    size_t rewindKeyframeBytes_ = 0, rewindStateIndex_ = 0, rewindPcmIndex_ = 0;
    std::vector<uint8_t> rewindRaw_, rewindScratch_, rewindDeltaScratch_;
    double rewindCaptureMs_ = 0, rewindCaptureMaxMs_ = 0, rewindRestoreMs_ = 0, rewindRestoreMaxMs_ = 0;
    uint64_t rewindFrameRestores_ = 0;
    uint64_t pcmTimelineSamples_ = 0, reverseOutputFrames_ = 0;
    std::vector<int16_t> audioScratch_;
    const size_t rewindByteLimit_ = 96 * 1024 * 1024;

    mutable std::mutex videoMutex_;
    std::condition_variable videoReady_;
    ANativeWindow* window_ = nullptr;
    std::vector<uint32_t> latestPixels_;
    std::vector<uint32_t> videoScratch_;
    unsigned videoWidth_ = 0, videoHeight_ = 0;
    uint64_t videoGeneration_ = 0;
    std::atomic<uint64_t> presentationCount_{0};
    std::atomic<int> renderError_{0};
    std::atomic<bool> fourThreeAspect_{true};

    static constexpr uint32_t audioCapacity_ = 32768;
    std::vector<int16_t> audioRing_ = std::vector<int16_t>(audioCapacity_ * 2);
    std::atomic<uint64_t> audioWrite_{0}, audioRead_{0}, audioUnderruns_{0}, audioOverruns_{0};
    std::atomic<bool> audioFlush_{false};
    std::atomic<bool> audioPrimed_{false};
    std::atomic<bool> reverseAudioOutput_{false};
    AAudioStream* audioStream_ = nullptr;
    int32_t outputSampleRate_ = 44100;
    double resamplePosition_ = 0;
    int16_t resamplePrevious_[2] = {0, 0};
};
}
